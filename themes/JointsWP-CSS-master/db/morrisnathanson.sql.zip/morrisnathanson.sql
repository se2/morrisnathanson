-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 20, 2018 at 12:45 AM
-- Server version: 5.6.38
-- PHP Version: 5.6.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `morrisnathanson`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_commentmeta`
--

DROP TABLE IF EXISTS `wp_commentmeta`;
CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `comment_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `wp_comments`
--

DROP TABLE IF EXISTS `wp_comments`;
CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) UNSIGNED NOT NULL,
  `comment_post_ID` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_comments`
--

INSERT INTO `wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2018-04-06 20:47:38', '2018-04-06 20:47:38', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href=\"https://gravatar.com\">Gravatar</a>.', 0, 'post-trashed', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_duplicator_packages`
--

DROP TABLE IF EXISTS `wp_duplicator_packages`;
CREATE TABLE `wp_duplicator_packages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(250) NOT NULL,
  `hash` varchar(50) NOT NULL,
  `status` int(11) NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `owner` varchar(60) NOT NULL,
  `package` mediumblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_duplicator_packages`
--

INSERT INTO `wp_duplicator_packages` (`id`, `name`, `hash`, `status`, `created`, `owner`, `package`) VALUES
(1, '20180413_morrisnathansonart', 'a11f1f9cea524f8f5261180413194412', 20, '2018-04-13 19:44:17', 'admin', 0x4f3a31313a224455505f5061636b616765223a32333a7b733a373a2243726561746564223b733a31393a22323031382d30342d31332031393a34343a3132223b733a373a2256657273696f6e223b733a363a22312e322e3334223b733a393a2256657273696f6e5750223b733a353a22342e392e35223b733a393a2256657273696f6e4442223b733a363a22352e362e3234223b733a31303a2256657273696f6e504850223b733a363a22352e352e3234223b733a393a2256657273696f6e4f53223b733a363a2244617277696e223b733a323a224944223b693a313b733a343a224e616d65223b733a32373a2232303138303431335f6d6f727269736e617468616e736f6e617274223b733a343a2248617368223b733a33323a226131316631663963656135323466386635323631313830343133313934343132223b733a383a224e616d6548617368223b733a36303a2232303138303431335f6d6f727269736e617468616e736f6e6172745f6131316631663963656135323466386635323631313830343133313934343132223b733a343a2254797065223b693a303b733a353a224e6f746573223b733a303a22223b733a393a2253746f726550617468223b733a37313a222f55736572732f696d6163322f446f63756d656e74732f57656273697465732f6d6f727269736e617468616e736f6e2e6465762e63632f77702d736e617073686f74732f746d70223b733a383a2253746f726555524c223b733a34333a22687474703a2f2f6d6f727269736e617468616e736f6e2e6465762e63632f77702d736e617073686f74732f223b733a383a225363616e46696c65223b733a37303a2232303138303431335f6d6f727269736e617468616e736f6e6172745f61313166316639636561353234663866353236313138303431333139343431325f7363616e2e6a736f6e223b733a373a2252756e74696d65223b4e3b733a373a2245786553697a65223b4e3b733a373a225a697053697a65223b4e3b733a363a22537461747573223b4e3b733a363a22575055736572223b733a353a2261646d696e223b733a373a2241726368697665223b4f3a31313a224455505f41726368697665223a31393a7b733a31303a2246696c74657244697273223b733a303a22223b733a31313a2246696c74657246696c6573223b733a303a22223b733a31303a2246696c74657245787473223b733a303a22223b733a31333a2246696c74657244697273416c6c223b613a303a7b7d733a31343a2246696c74657246696c6573416c6c223b613a303a7b7d733a31333a2246696c74657245787473416c6c223b613a303a7b7d733a383a2246696c7465724f6e223b693a303b733a31323a224578706f72744f6e6c794442223b693a303b733a343a2246696c65223b733a37323a2232303138303431335f6d6f727269736e617468616e736f6e6172745f61313166316639636561353234663866353236313138303431333139343431325f617263686976652e7a6970223b733a363a22466f726d6174223b733a333a225a4950223b733a373a225061636b446972223b733a35343a222f55736572732f696d6163322f446f63756d656e74732f57656273697465732f6d6f727269736e617468616e736f6e2e6465762e6363223b733a343a2253697a65223b693a303b733a343a2244697273223b613a303a7b7d733a353a2246696c6573223b613a303a7b7d733a31303a2246696c746572496e666f223b4f3a32333a224455505f417263686976655f46696c7465725f496e666f223a383a7b733a343a2244697273223b4f3a33343a224455505f417263686976655f46696c7465725f53636f70655f4469726563746f7279223a343a7b733a373a225761726e696e67223b613a303a7b7d733a31303a22556e7265616461626c65223b613a303a7b7d733a343a22436f7265223b613a303a7b7d733a383a22496e7374616e6365223b613a303a7b7d7d733a353a2246696c6573223b4f3a32393a224455505f417263686976655f46696c7465725f53636f70655f46696c65223a353a7b733a343a2253697a65223b613a303a7b7d733a373a225761726e696e67223b613a303a7b7d733a31303a22556e7265616461626c65223b613a303a7b7d733a343a22436f7265223b613a303a7b7d733a383a22496e7374616e6365223b613a303a7b7d7d733a343a2245787473223b4f3a32393a224455505f417263686976655f46696c7465725f53636f70655f42617365223a323a7b733a343a22436f7265223b613a303a7b7d733a383a22496e7374616e6365223b613a303a7b7d7d733a393a2255446972436f756e74223b693a303b733a31303a225546696c65436f756e74223b693a303b733a393a2255457874436f756e74223b693a303b733a383a225472656553697a65223b613a303a7b7d733a31313a22547265655761726e696e67223b613a303a7b7d7d733a31343a225265637572736976654c696e6b73223b613a303a7b7d733a31303a22002a005061636b616765223b4f3a31313a224455505f5061636b616765223a32333a7b733a373a2243726561746564223b733a31393a22323031382d30342d31332031393a34343a3132223b733a373a2256657273696f6e223b733a363a22312e322e3334223b733a393a2256657273696f6e5750223b733a353a22342e392e35223b733a393a2256657273696f6e4442223b733a363a22352e362e3234223b733a31303a2256657273696f6e504850223b733a363a22352e352e3234223b733a393a2256657273696f6e4f53223b733a363a2244617277696e223b733a323a224944223b4e3b733a343a224e616d65223b733a32373a2232303138303431335f6d6f727269736e617468616e736f6e617274223b733a343a2248617368223b733a33323a226131316631663963656135323466386635323631313830343133313934343132223b733a383a224e616d6548617368223b733a36303a2232303138303431335f6d6f727269736e617468616e736f6e6172745f6131316631663963656135323466386635323631313830343133313934343132223b733a343a2254797065223b693a303b733a353a224e6f746573223b733a303a22223b733a393a2253746f726550617468223b733a37313a222f55736572732f696d6163322f446f63756d656e74732f57656273697465732f6d6f727269736e617468616e736f6e2e6465762e63632f77702d736e617073686f74732f746d70223b733a383a2253746f726555524c223b733a34333a22687474703a2f2f6d6f727269736e617468616e736f6e2e6465762e63632f77702d736e617073686f74732f223b733a383a225363616e46696c65223b4e3b733a373a2252756e74696d65223b4e3b733a373a2245786553697a65223b4e3b733a373a225a697053697a65223b4e3b733a363a22537461747573223b4e3b733a363a22575055736572223b4e3b733a373a2241726368697665223b723a32323b733a393a22496e7374616c6c6572223b4f3a31333a224455505f496e7374616c6c6572223a373a7b733a343a2246696c65223b733a37343a2232303138303431335f6d6f727269736e617468616e736f6e6172745f61313166316639636561353234663866353236313138303431333139343431325f696e7374616c6c65722e706870223b733a343a2253697a65223b693a303b733a31303a224f7074734442486f7374223b733a303a22223b733a31303a224f7074734442506f7274223b733a303a22223b733a31303a224f70747344424e616d65223b733a303a22223b733a31303a224f707473444255736572223b733a303a22223b733a31303a22002a005061636b616765223b723a35383b7d733a383a224461746162617365223b4f3a31323a224455505f4461746162617365223a31333a7b733a343a2254797065223b733a353a224d7953514c223b733a343a2253697a65223b4e3b733a343a2246696c65223b733a37333a2232303138303431335f6d6f727269736e617468616e736f6e6172745f61313166316639636561353234663866353236313138303431333139343431325f64617461626173652e73716c223b733a343a2250617468223b4e3b733a31323a2246696c7465725461626c6573223b733a303a22223b733a383a2246696c7465724f6e223b693a303b733a343a224e616d65223b4e3b733a31303a22436f6d70617469626c65223b733a303a22223b733a383a22436f6d6d656e7473223b733a31393a22536f7572636520646973747269627574696f6e223b733a31303a22002a005061636b616765223b723a313b733a32353a22004455505f446174616261736500646253746f726550617468223b4e3b733a32333a22004455505f446174616261736500454f464d61726b6572223b733a303a22223b733a32363a22004455505f4461746162617365006e6574776f726b466c757368223b623a303b7d7d733a32393a22004455505f4172636869766500746d7046696c74657244697273416c6c223b613a303a7b7d733a32343a22004455505f41726368697665007770436f72655061746873223b613a363a7b693a303b733a36333a222f55736572732f696d6163322f446f63756d656e74732f57656273697465732f6d6f727269736e617468616e736f6e2e6465762e63632f77702d61646d696e223b693a313b733a37333a222f55736572732f696d6163322f446f63756d656e74732f57656273697465732f6d6f727269736e617468616e736f6e2e6465762e63632f77702d636f6e74656e742f75706c6f616473223b693a323b733a37353a222f55736572732f696d6163322f446f63756d656e74732f57656273697465732f6d6f727269736e617468616e736f6e2e6465762e63632f77702d636f6e74656e742f6c616e677561676573223b693a333b733a37333a222f55736572732f696d6163322f446f63756d656e74732f57656273697465732f6d6f727269736e617468616e736f6e2e6465762e63632f77702d636f6e74656e742f706c7567696e73223b693a343b733a37323a222f55736572732f696d6163322f446f63756d656e74732f57656273697465732f6d6f727269736e617468616e736f6e2e6465762e63632f77702d636f6e74656e742f7468656d6573223b693a353b733a36363a222f55736572732f696d6163322f446f63756d656e74732f57656273697465732f6d6f727269736e617468616e736f6e2e6465762e63632f77702d696e636c75646573223b7d7d733a393a22496e7374616c6c6572223b723a38303b733a383a224461746162617365223b723a38383b7d);

-- --------------------------------------------------------

--
-- Table structure for table `wp_links`
--

DROP TABLE IF EXISTS `wp_links`;
CREATE TABLE `wp_links` (
  `link_id` bigint(20) UNSIGNED NOT NULL,
  `link_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `wp_options`
--

DROP TABLE IF EXISTS `wp_options`;
CREATE TABLE `wp_options` (
  `option_id` bigint(20) UNSIGNED NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_options`
--

INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://morrisnathanson.dev.cc', 'yes'),
(2, 'home', 'http://morrisnathanson.dev.cc', 'yes'),
(3, 'blogname', 'Morris Nathanson Art', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'dan@delindesign.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'closed', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '', 'yes'),
(22, 'posts_per_page', '20', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:243:{s:24:\"^wc-auth/v([1]{1})/(.*)?\";s:63:\"index.php?wc-auth-version=$matches[1]&wc-auth-route=$matches[2]\";s:22:\"^wc-api/v([1-3]{1})/?$\";s:51:\"index.php?wc-api-version=$matches[1]&wc-api-route=/\";s:24:\"^wc-api/v([1-3]{1})(.*)?\";s:61:\"index.php?wc-api-version=$matches[1]&wc-api-route=$matches[2]\";s:15:\"news-article/?$\";s:32:\"index.php?post_type=news-article\";s:45:\"news-article/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?post_type=news-article&feed=$matches[1]\";s:40:\"news-article/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?post_type=news-article&feed=$matches[1]\";s:32:\"news-article/page/([0-9]{1,})/?$\";s:50:\"index.php?post_type=news-article&paged=$matches[1]\";s:8:\"story/?$\";s:25:\"index.php?post_type=story\";s:38:\"story/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?post_type=story&feed=$matches[1]\";s:33:\"story/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?post_type=story&feed=$matches[1]\";s:25:\"story/page/([0-9]{1,})/?$\";s:43:\"index.php?post_type=story&paged=$matches[1]\";s:10:\"gallery/?$\";s:27:\"index.php?post_type=gallery\";s:40:\"gallery/feed/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=gallery&feed=$matches[1]\";s:35:\"gallery/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=gallery&feed=$matches[1]\";s:27:\"gallery/page/([0-9]{1,})/?$\";s:45:\"index.php?post_type=gallery&paged=$matches[1]\";s:7:\"shop/?$\";s:27:\"index.php?post_type=product\";s:37:\"shop/feed/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=product&feed=$matches[1]\";s:32:\"shop/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=product&feed=$matches[1]\";s:24:\"shop/page/([0-9]{1,})/?$\";s:45:\"index.php?post_type=product&paged=$matches[1]\";s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:32:\"category/(.+?)/wc-api(/(.*))?/?$\";s:54:\"index.php?category_name=$matches[1]&wc-api=$matches[3]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:29:\"tag/([^/]+)/wc-api(/(.*))?/?$\";s:44:\"index.php?tag=$matches[1]&wc-api=$matches[3]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:40:\"news-article/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:50:\"news-article/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:70:\"news-article/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:65:\"news-article/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:65:\"news-article/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:46:\"news-article/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:29:\"news-article/([^/]+)/embed/?$\";s:45:\"index.php?news-article=$matches[1]&embed=true\";s:33:\"news-article/([^/]+)/trackback/?$\";s:39:\"index.php?news-article=$matches[1]&tb=1\";s:53:\"news-article/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:51:\"index.php?news-article=$matches[1]&feed=$matches[2]\";s:48:\"news-article/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:51:\"index.php?news-article=$matches[1]&feed=$matches[2]\";s:41:\"news-article/([^/]+)/page/?([0-9]{1,})/?$\";s:52:\"index.php?news-article=$matches[1]&paged=$matches[2]\";s:48:\"news-article/([^/]+)/comment-page-([0-9]{1,})/?$\";s:52:\"index.php?news-article=$matches[1]&cpage=$matches[2]\";s:38:\"news-article/([^/]+)/wc-api(/(.*))?/?$\";s:53:\"index.php?news-article=$matches[1]&wc-api=$matches[3]\";s:44:\"news-article/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:55:\"news-article/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:37:\"news-article/([^/]+)(?:/([0-9]+))?/?$\";s:51:\"index.php?news-article=$matches[1]&page=$matches[2]\";s:29:\"news-article/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:39:\"news-article/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:59:\"news-article/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:54:\"news-article/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:54:\"news-article/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:35:\"news-article/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:33:\"story/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:43:\"story/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:63:\"story/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:58:\"story/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:58:\"story/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:39:\"story/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:22:\"story/([^/]+)/embed/?$\";s:38:\"index.php?story=$matches[1]&embed=true\";s:26:\"story/([^/]+)/trackback/?$\";s:32:\"index.php?story=$matches[1]&tb=1\";s:46:\"story/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?story=$matches[1]&feed=$matches[2]\";s:41:\"story/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?story=$matches[1]&feed=$matches[2]\";s:34:\"story/([^/]+)/page/?([0-9]{1,})/?$\";s:45:\"index.php?story=$matches[1]&paged=$matches[2]\";s:41:\"story/([^/]+)/comment-page-([0-9]{1,})/?$\";s:45:\"index.php?story=$matches[1]&cpage=$matches[2]\";s:31:\"story/([^/]+)/wc-api(/(.*))?/?$\";s:46:\"index.php?story=$matches[1]&wc-api=$matches[3]\";s:37:\"story/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:48:\"story/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:30:\"story/([^/]+)(?:/([0-9]+))?/?$\";s:44:\"index.php?story=$matches[1]&page=$matches[2]\";s:22:\"story/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:32:\"story/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:52:\"story/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:47:\"story/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:47:\"story/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:28:\"story/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:35:\"gallery/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:45:\"gallery/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:65:\"gallery/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"gallery/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"gallery/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:41:\"gallery/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:24:\"gallery/([^/]+)/embed/?$\";s:40:\"index.php?gallery=$matches[1]&embed=true\";s:28:\"gallery/([^/]+)/trackback/?$\";s:34:\"index.php?gallery=$matches[1]&tb=1\";s:48:\"gallery/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?gallery=$matches[1]&feed=$matches[2]\";s:43:\"gallery/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?gallery=$matches[1]&feed=$matches[2]\";s:36:\"gallery/([^/]+)/page/?([0-9]{1,})/?$\";s:47:\"index.php?gallery=$matches[1]&paged=$matches[2]\";s:43:\"gallery/([^/]+)/comment-page-([0-9]{1,})/?$\";s:47:\"index.php?gallery=$matches[1]&cpage=$matches[2]\";s:33:\"gallery/([^/]+)/wc-api(/(.*))?/?$\";s:48:\"index.php?gallery=$matches[1]&wc-api=$matches[3]\";s:39:\"gallery/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:50:\"gallery/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:32:\"gallery/([^/]+)(?:/([0-9]+))?/?$\";s:46:\"index.php?gallery=$matches[1]&page=$matches[2]\";s:24:\"gallery/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:34:\"gallery/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:54:\"gallery/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"gallery/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"gallery/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:30:\"gallery/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:55:\"product-category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_cat=$matches[1]&feed=$matches[2]\";s:50:\"product-category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_cat=$matches[1]&feed=$matches[2]\";s:31:\"product-category/(.+?)/embed/?$\";s:44:\"index.php?product_cat=$matches[1]&embed=true\";s:43:\"product-category/(.+?)/page/?([0-9]{1,})/?$\";s:51:\"index.php?product_cat=$matches[1]&paged=$matches[2]\";s:25:\"product-category/(.+?)/?$\";s:33:\"index.php?product_cat=$matches[1]\";s:52:\"product-tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_tag=$matches[1]&feed=$matches[2]\";s:47:\"product-tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_tag=$matches[1]&feed=$matches[2]\";s:28:\"product-tag/([^/]+)/embed/?$\";s:44:\"index.php?product_tag=$matches[1]&embed=true\";s:40:\"product-tag/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?product_tag=$matches[1]&paged=$matches[2]\";s:22:\"product-tag/([^/]+)/?$\";s:33:\"index.php?product_tag=$matches[1]\";s:35:\"product/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:45:\"product/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:65:\"product/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"product/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"product/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:41:\"product/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:24:\"product/([^/]+)/embed/?$\";s:40:\"index.php?product=$matches[1]&embed=true\";s:28:\"product/([^/]+)/trackback/?$\";s:34:\"index.php?product=$matches[1]&tb=1\";s:48:\"product/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?product=$matches[1]&feed=$matches[2]\";s:43:\"product/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?product=$matches[1]&feed=$matches[2]\";s:36:\"product/([^/]+)/page/?([0-9]{1,})/?$\";s:47:\"index.php?product=$matches[1]&paged=$matches[2]\";s:43:\"product/([^/]+)/comment-page-([0-9]{1,})/?$\";s:47:\"index.php?product=$matches[1]&cpage=$matches[2]\";s:33:\"product/([^/]+)/wc-api(/(.*))?/?$\";s:48:\"index.php?product=$matches[1]&wc-api=$matches[3]\";s:39:\"product/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:50:\"product/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:32:\"product/([^/]+)(?:/([0-9]+))?/?$\";s:46:\"index.php?product=$matches[1]&page=$matches[2]\";s:24:\"product/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:34:\"product/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:54:\"product/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"product/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"product/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:30:\"product/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:55:\"story-category/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:53:\"index.php?story-category=$matches[1]&feed=$matches[2]\";s:50:\"story-category/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:53:\"index.php?story-category=$matches[1]&feed=$matches[2]\";s:31:\"story-category/([^/]+)/embed/?$\";s:47:\"index.php?story-category=$matches[1]&embed=true\";s:43:\"story-category/([^/]+)/page/?([0-9]{1,})/?$\";s:54:\"index.php?story-category=$matches[1]&paged=$matches[2]\";s:25:\"story-category/([^/]+)/?$\";s:36:\"index.php?story-category=$matches[1]\";s:57:\"gallery-category/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:55:\"index.php?gallery-category=$matches[1]&feed=$matches[2]\";s:52:\"gallery-category/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:55:\"index.php?gallery-category=$matches[1]&feed=$matches[2]\";s:33:\"gallery-category/([^/]+)/embed/?$\";s:49:\"index.php?gallery-category=$matches[1]&embed=true\";s:45:\"gallery-category/([^/]+)/page/?([0-9]{1,})/?$\";s:56:\"index.php?gallery-category=$matches[1]&paged=$matches[2]\";s:27:\"gallery-category/([^/]+)/?$\";s:38:\"index.php?gallery-category=$matches[1]\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:38:\"index.php?&page_id=5&cpage=$matches[1]\";s:17:\"wc-api(/(.*))?/?$\";s:29:\"index.php?&wc-api=$matches[2]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:26:\"comments/wc-api(/(.*))?/?$\";s:29:\"index.php?&wc-api=$matches[2]\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:29:\"search/(.+)/wc-api(/(.*))?/?$\";s:42:\"index.php?s=$matches[1]&wc-api=$matches[3]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:32:\"author/([^/]+)/wc-api(/(.*))?/?$\";s:52:\"index.php?author_name=$matches[1]&wc-api=$matches[3]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:54:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/wc-api(/(.*))?/?$\";s:82:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&wc-api=$matches[5]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:41:\"([0-9]{4})/([0-9]{1,2})/wc-api(/(.*))?/?$\";s:66:\"index.php?year=$matches[1]&monthnum=$matches[2]&wc-api=$matches[4]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:28:\"([0-9]{4})/wc-api(/(.*))?/?$\";s:45:\"index.php?year=$matches[1]&wc-api=$matches[3]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:25:\"(.?.+?)/wc-api(/(.*))?/?$\";s:49:\"index.php?pagename=$matches[1]&wc-api=$matches[3]\";s:28:\"(.?.+?)/order-pay(/(.*))?/?$\";s:52:\"index.php?pagename=$matches[1]&order-pay=$matches[3]\";s:33:\"(.?.+?)/order-received(/(.*))?/?$\";s:57:\"index.php?pagename=$matches[1]&order-received=$matches[3]\";s:25:\"(.?.+?)/orders(/(.*))?/?$\";s:49:\"index.php?pagename=$matches[1]&orders=$matches[3]\";s:29:\"(.?.+?)/view-order(/(.*))?/?$\";s:53:\"index.php?pagename=$matches[1]&view-order=$matches[3]\";s:28:\"(.?.+?)/downloads(/(.*))?/?$\";s:52:\"index.php?pagename=$matches[1]&downloads=$matches[3]\";s:31:\"(.?.+?)/edit-account(/(.*))?/?$\";s:55:\"index.php?pagename=$matches[1]&edit-account=$matches[3]\";s:31:\"(.?.+?)/edit-address(/(.*))?/?$\";s:55:\"index.php?pagename=$matches[1]&edit-address=$matches[3]\";s:34:\"(.?.+?)/payment-methods(/(.*))?/?$\";s:58:\"index.php?pagename=$matches[1]&payment-methods=$matches[3]\";s:32:\"(.?.+?)/lost-password(/(.*))?/?$\";s:56:\"index.php?pagename=$matches[1]&lost-password=$matches[3]\";s:34:\"(.?.+?)/customer-logout(/(.*))?/?$\";s:58:\"index.php?pagename=$matches[1]&customer-logout=$matches[3]\";s:37:\"(.?.+?)/add-payment-method(/(.*))?/?$\";s:61:\"index.php?pagename=$matches[1]&add-payment-method=$matches[3]\";s:40:\"(.?.+?)/delete-payment-method(/(.*))?/?$\";s:64:\"index.php?pagename=$matches[1]&delete-payment-method=$matches[3]\";s:45:\"(.?.+?)/set-default-payment-method(/(.*))?/?$\";s:69:\"index.php?pagename=$matches[1]&set-default-payment-method=$matches[3]\";s:31:\".?.+?/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:42:\".?.+?/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:27:\"[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\"[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\"[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"([^/]+)/embed/?$\";s:37:\"index.php?name=$matches[1]&embed=true\";s:20:\"([^/]+)/trackback/?$\";s:31:\"index.php?name=$matches[1]&tb=1\";s:40:\"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:35:\"([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:28:\"([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&paged=$matches[2]\";s:35:\"([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&cpage=$matches[2]\";s:25:\"([^/]+)/wc-api(/(.*))?/?$\";s:45:\"index.php?name=$matches[1]&wc-api=$matches[3]\";s:31:\"[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:42:\"[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:24:\"([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?name=$matches[1]&page=$matches[2]\";s:16:\"[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:26:\"[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:46:\"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:22:\"[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:11:{i:0;s:34:\"advanced-custom-fields-pro/acf.php\";i:1;s:39:\"column-shortcodes/column-shortcodes.php\";i:2;s:36:\"contact-form-7/wp-contact-form-7.php\";i:3;s:25:\"duplicator/duplicator.php\";i:4;s:41:\"fluid-video-embeds/fluid-video-embeds.php\";i:5;s:19:\"jetpack/jetpack.php\";i:6;s:23:\"ml-slider/ml-slider.php\";i:7;s:53:\"responsive-lightbox-lite/responsive-lightbox-lite.php\";i:8;s:91:\"woocommerce-gateway-paypal-express-checkout/woocommerce-gateway-paypal-express-checkout.php\";i:9;s:45:\"woocommerce-services/woocommerce-services.php\";i:10;s:27:\"woocommerce/woocommerce.php\";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', 'a:2:{i:0;s:102:\"/Users/imac2/Documents/Websites/morrisnathanson.dev.cc/wp-content/themes/JointsWP-CSS-master/style.css\";i:1;s:0:\"\";}', 'no'),
(40, 'template', 'JointsWP-CSS-master', 'yes'),
(41, 'stylesheet', 'JointsWP-CSS-master', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '0', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', '', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(79, 'widget_text', 'a:0:{}', 'yes'),
(80, 'widget_rss', 'a:0:{}', 'yes'),
(81, 'uninstall_plugins', 'a:2:{s:45:\"woocommerce-services/woocommerce-services.php\";a:2:{i:0;s:17:\"WC_Connect_Loader\";i:1;s:16:\"plugin_uninstall\";}s:29:\"slick-slider/slick-slider.php\";a:2:{i:0;s:17:\"Slick_Slider_Main\";i:1;s:9:\"uninstall\";}}', 'no'),
(82, 'timezone_string', 'America/New_York', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '5', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '38590', 'yes'),
(92, 'wp_user_roles', 'a:7:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:114:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}s:8:\"customer\";a:2:{s:4:\"name\";s:8:\"Customer\";s:12:\"capabilities\";a:1:{s:4:\"read\";b:1;}}s:12:\"shop_manager\";a:2:{s:4:\"name\";s:12:\"Shop manager\";s:12:\"capabilities\";a:92:{s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:4:\"read\";b:1;s:18:\"read_private_pages\";b:1;s:18:\"read_private_posts\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_posts\";b:1;s:10:\"edit_pages\";b:1;s:20:\"edit_published_posts\";b:1;s:20:\"edit_published_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"edit_private_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:17:\"edit_others_pages\";b:1;s:13:\"publish_posts\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_posts\";b:1;s:12:\"delete_pages\";b:1;s:20:\"delete_private_pages\";b:1;s:20:\"delete_private_posts\";b:1;s:22:\"delete_published_pages\";b:1;s:22:\"delete_published_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:19:\"delete_others_pages\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:17:\"moderate_comments\";b:1;s:12:\"upload_files\";b:1;s:6:\"export\";b:1;s:6:\"import\";b:1;s:10:\"list_users\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;}}}', 'yes'),
(93, 'fresh_site', '0', 'yes'),
(94, 'widget_search', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(95, 'widget_recent-posts', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(96, 'widget_recent-comments', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(97, 'widget_archives', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(98, 'widget_meta', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(99, 'sidebars_widgets', 'a:10:{s:19:\"wp_inactive_widgets\";a:11:{i:0;s:10:\"nav_menu-8\";i:1;s:10:\"nav_menu-9\";i:2;s:11:\"nav_menu-10\";i:3;s:11:\"nav_menu-11\";i:4;s:11:\"nav_menu-12\";i:5;s:10:\"nav_menu-2\";i:6;s:10:\"nav_menu-3\";i:7;s:10:\"nav_menu-4\";i:8;s:10:\"nav_menu-5\";i:9;s:10:\"nav_menu-6\";i:10;s:10:\"nav_menu-7\";}s:16:\"footer-sidebar-1\";a:1:{i:0;s:11:\"nav_menu-13\";}s:16:\"footer-sidebar-2\";a:1:{i:0;s:11:\"nav_menu-14\";}s:16:\"footer-sidebar-3\";a:1:{i:0;s:11:\"nav_menu-15\";}s:16:\"footer-sidebar-4\";a:1:{i:0;s:11:\"nav_menu-16\";}s:16:\"footer-sidebar-5\";a:1:{i:0;s:11:\"nav_menu-18\";}s:16:\"footer-sidebar-6\";a:0:{}s:8:\"sidebar1\";a:0:{}s:9:\"offcanvas\";a:0:{}s:13:\"array_version\";i:3;}', 'yes'),
(100, 'widget_pages', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(101, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(102, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(103, 'widget_media_image', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(104, 'widget_media_gallery', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(105, 'widget_media_video', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(106, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(107, 'widget_nav_menu', 'a:17:{i:2;a:2:{s:5:\"title\";s:7:\"Gallery\";s:8:\"nav_menu\";i:28;}i:3;a:1:{s:8:\"nav_menu\";i:28;}i:4;a:1:{s:8:\"nav_menu\";i:29;}i:5;a:1:{s:8:\"nav_menu\";i:30;}i:6;a:1:{s:8:\"nav_menu\";i:31;}i:7;a:1:{s:8:\"nav_menu\";i:32;}i:8;a:1:{s:8:\"nav_menu\";i:28;}i:9;a:1:{s:8:\"nav_menu\";i:29;}i:10;a:1:{s:8:\"nav_menu\";i:30;}i:11;a:1:{s:8:\"nav_menu\";i:31;}i:12;a:1:{s:8:\"nav_menu\";i:32;}i:13;a:1:{s:8:\"nav_menu\";i:28;}i:14;a:1:{s:8:\"nav_menu\";i:29;}i:15;a:1:{s:8:\"nav_menu\";i:30;}i:16;a:1:{s:8:\"nav_menu\";i:31;}i:18;a:1:{s:8:\"nav_menu\";i:32;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(108, 'widget_custom_html', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(109, 'cron', 'a:10:{i:1524201660;a:1:{s:32:\"woocommerce_cancel_unpaid_orders\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1524202450;a:1:{s:20:\"jetpack_clean_nonces\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1524210778;a:1:{s:28:\"woocommerce_cleanup_sessions\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1524214059;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1524253978;a:1:{s:30:\"woocommerce_tracker_send_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1524257270;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1524257816;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1524283200;a:1:{s:27:\"woocommerce_scheduled_sales\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1525132800;a:1:{s:25:\"woocommerce_geoip_updater\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:7:\"monthly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:2635200;}}}s:7:\"version\";i:2;}', 'yes'),
(110, 'theme_mods_twentyseventeen', 'a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1523047705;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}}', 'yes'),
(121, '_site_transient_update_core', 'O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.9.5.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.9.5.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-4.9.5-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-4.9.5-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"4.9.5\";s:7:\"version\";s:5:\"4.9.5\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.7\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1524172479;s:15:\"version_checked\";s:5:\"4.9.5\";s:12:\"translations\";a:0:{}}', 'no'),
(122, '_site_transient_update_themes', 'O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1524172483;s:7:\"checked\";a:1:{s:19:\"JointsWP-CSS-master\";s:3:\"5.0\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}', 'no'),
(124, 'auto_core_update_notified', 'a:4:{s:4:\"type\";s:7:\"success\";s:5:\"email\";s:19:\"dan@delindesign.com\";s:7:\"version\";s:5:\"4.9.5\";s:9:\"timestamp\";i:1523047666;}', 'no'),
(134, 'can_compress_scripts', '1', 'no'),
(143, 'current_theme', 'JointsWP - CSS', 'yes'),
(144, 'theme_mods_JointsWP-CSS-master', 'a:3:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:8:\"main-nav\";i:27;}s:18:\"custom_css_post_id\";i:-1;}', 'yes'),
(145, 'theme_switched', '', 'yes'),
(148, 'recently_activated', 'a:0:{}', 'yes'),
(153, 'acf_version', '5.6.10', 'yes'),
(171, 'acf_pro_license', 'YToyOntzOjM6ImtleSI7czo3NjoiYjNKa1pYSmZhV1E5TVRBeE1ETTFmSFI1Y0dVOVpHVjJaV3h2Y0dWeWZHUmhkR1U5TWpBeE55MHdNeTB3TWlBeU1EbzFOam94TWc9PSI7czozOiJ1cmwiO3M6Mjk6Imh0dHA6Ly9tb3JyaXNuYXRoYW5zb24uZGV2LmNjIjt9', 'yes'),
(181, 'woocommerce_store_address', '163 Exchange Street', 'yes'),
(182, 'woocommerce_store_address_2', '', 'yes'),
(183, 'woocommerce_store_city', 'Pawtucket', 'yes'),
(184, 'woocommerce_default_country', 'US:RI', 'yes'),
(185, 'woocommerce_store_postcode', 'RI, 02893', 'yes'),
(186, 'woocommerce_allowed_countries', 'all', 'yes'),
(187, 'woocommerce_all_except_countries', '', 'yes'),
(188, 'woocommerce_specific_allowed_countries', '', 'yes'),
(189, 'woocommerce_ship_to_countries', '', 'yes'),
(190, 'woocommerce_specific_ship_to_countries', '', 'yes'),
(191, 'woocommerce_default_customer_address', 'geolocation', 'yes'),
(192, 'woocommerce_calc_taxes', 'no', 'yes'),
(193, 'woocommerce_currency', 'USD', 'yes'),
(194, 'woocommerce_currency_pos', 'left', 'yes'),
(195, 'woocommerce_price_thousand_sep', ',', 'yes'),
(196, 'woocommerce_price_decimal_sep', '.', 'yes'),
(197, 'woocommerce_price_num_decimals', '2', 'yes'),
(198, 'woocommerce_shop_page_id', '34', 'yes'),
(199, 'woocommerce_cart_redirect_after_add', 'no', 'yes'),
(200, 'woocommerce_enable_ajax_add_to_cart', 'yes', 'yes'),
(201, 'woocommerce_weight_unit', 'oz', 'yes'),
(202, 'woocommerce_dimension_unit', 'in', 'yes'),
(203, 'woocommerce_enable_reviews', 'yes', 'yes'),
(204, 'woocommerce_review_rating_verification_label', 'yes', 'no'),
(205, 'woocommerce_review_rating_verification_required', 'no', 'no'),
(206, 'woocommerce_enable_review_rating', 'yes', 'yes'),
(207, 'woocommerce_review_rating_required', 'yes', 'no'),
(208, 'woocommerce_manage_stock', 'yes', 'yes'),
(209, 'woocommerce_hold_stock_minutes', '60', 'no'),
(210, 'woocommerce_notify_low_stock', 'yes', 'no'),
(211, 'woocommerce_notify_no_stock', 'yes', 'no'),
(212, 'woocommerce_stock_email_recipient', 'dan@delindesign.com', 'no'),
(213, 'woocommerce_notify_low_stock_amount', '2', 'no'),
(214, 'woocommerce_notify_no_stock_amount', '0', 'yes'),
(215, 'woocommerce_hide_out_of_stock_items', 'no', 'yes'),
(216, 'woocommerce_stock_format', '', 'yes'),
(217, 'woocommerce_file_download_method', 'force', 'no'),
(218, 'woocommerce_downloads_require_login', 'no', 'no'),
(219, 'woocommerce_downloads_grant_access_after_payment', 'yes', 'no'),
(220, 'woocommerce_prices_include_tax', 'no', 'yes'),
(221, 'woocommerce_tax_based_on', 'shipping', 'yes'),
(222, 'woocommerce_shipping_tax_class', 'inherit', 'yes'),
(223, 'woocommerce_tax_round_at_subtotal', 'no', 'yes'),
(224, 'woocommerce_tax_classes', 'Reduced rate\nZero rate', 'yes'),
(225, 'woocommerce_tax_display_shop', 'excl', 'yes'),
(226, 'woocommerce_tax_display_cart', 'excl', 'no'),
(227, 'woocommerce_price_display_suffix', '', 'yes'),
(228, 'woocommerce_tax_total_display', 'itemized', 'no'),
(229, 'woocommerce_enable_shipping_calc', 'yes', 'no'),
(230, 'woocommerce_shipping_cost_requires_address', 'no', 'no'),
(231, 'woocommerce_ship_to_destination', 'billing', 'no'),
(232, 'woocommerce_shipping_debug_mode', 'no', 'no'),
(233, 'woocommerce_enable_coupons', 'no', 'yes'),
(234, 'woocommerce_calc_discounts_sequentially', 'no', 'no'),
(235, 'woocommerce_enable_guest_checkout', 'yes', 'no'),
(236, 'woocommerce_force_ssl_checkout', 'no', 'yes'),
(237, 'woocommerce_unforce_ssl_checkout', 'no', 'yes'),
(238, 'woocommerce_cart_page_id', '35', 'yes'),
(239, 'woocommerce_checkout_page_id', '36', 'yes'),
(240, 'woocommerce_terms_page_id', '', 'no'),
(241, 'woocommerce_checkout_pay_endpoint', 'order-pay', 'yes'),
(242, 'woocommerce_checkout_order_received_endpoint', 'order-received', 'yes'),
(243, 'woocommerce_myaccount_add_payment_method_endpoint', 'add-payment-method', 'yes'),
(244, 'woocommerce_myaccount_delete_payment_method_endpoint', 'delete-payment-method', 'yes'),
(245, 'woocommerce_myaccount_set_default_payment_method_endpoint', 'set-default-payment-method', 'yes'),
(246, 'woocommerce_myaccount_page_id', '37', 'yes'),
(247, 'woocommerce_enable_signup_and_login_from_checkout', 'yes', 'no'),
(248, 'woocommerce_enable_myaccount_registration', 'no', 'no'),
(249, 'woocommerce_enable_checkout_login_reminder', 'yes', 'no'),
(250, 'woocommerce_registration_generate_username', 'yes', 'no'),
(251, 'woocommerce_registration_generate_password', 'no', 'no'),
(252, 'woocommerce_myaccount_orders_endpoint', 'orders', 'yes'),
(253, 'woocommerce_myaccount_view_order_endpoint', 'view-order', 'yes'),
(254, 'woocommerce_myaccount_downloads_endpoint', 'downloads', 'yes'),
(255, 'woocommerce_myaccount_edit_account_endpoint', 'edit-account', 'yes'),
(256, 'woocommerce_myaccount_edit_address_endpoint', 'edit-address', 'yes'),
(257, 'woocommerce_myaccount_payment_methods_endpoint', 'payment-methods', 'yes'),
(258, 'woocommerce_myaccount_lost_password_endpoint', 'lost-password', 'yes'),
(259, 'woocommerce_logout_endpoint', 'customer-logout', 'yes'),
(260, 'woocommerce_email_from_name', 'Morris Nathanson Art', 'no'),
(261, 'woocommerce_email_from_address', 'dan@delindesign.com', 'no'),
(262, 'woocommerce_email_header_image', '', 'no'),
(263, 'woocommerce_email_footer_text', '{site_title}', 'no'),
(264, 'woocommerce_email_base_color', '#96588a', 'no'),
(265, 'woocommerce_email_background_color', '#f7f7f7', 'no'),
(266, 'woocommerce_email_body_background_color', '#ffffff', 'no'),
(267, 'woocommerce_email_text_color', '#3c3c3c', 'no'),
(268, 'woocommerce_api_enabled', 'yes', 'yes'),
(269, 'woocommerce_permalinks', 'a:5:{s:12:\"product_base\";s:8:\"/product\";s:13:\"category_base\";s:16:\"product-category\";s:8:\"tag_base\";s:11:\"product-tag\";s:14:\"attribute_base\";s:0:\"\";s:22:\"use_verbose_page_rules\";b:0;}', 'yes'),
(270, 'current_theme_supports_woocommerce', 'yes', 'yes'),
(271, 'woocommerce_queue_flush_rewrite_rules', 'no', 'yes'),
(272, '_transient_wc_attribute_taxonomies', 'a:0:{}', 'yes'),
(274, 'default_product_cat', '15', 'yes'),
(279, 'woocommerce_admin_notices', 'a:0:{}', 'yes');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(280, '_transient_woocommerce_webhook_ids', 'a:0:{}', 'yes'),
(281, 'widget_woocommerce_widget_cart', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(282, 'widget_woocommerce_layered_nav_filters', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(283, 'widget_woocommerce_layered_nav', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(284, 'widget_woocommerce_price_filter', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(285, 'widget_woocommerce_product_categories', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(286, 'widget_woocommerce_product_search', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(287, 'widget_woocommerce_product_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(288, 'widget_woocommerce_products', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(289, 'widget_woocommerce_recently_viewed_products', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(290, 'widget_woocommerce_top_rated_products', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(291, 'widget_woocommerce_recent_reviews', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(292, 'widget_woocommerce_rating_filter', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(294, '_transient_wc_count_comments', 'O:8:\"stdClass\":7:{s:14:\"total_comments\";i:1;s:3:\"all\";i:1;s:8:\"approved\";s:1:\"1\";s:9:\"moderated\";i:0;s:4:\"spam\";i:0;s:5:\"trash\";i:0;s:12:\"post-trashed\";i:0;}', 'yes'),
(295, 'woocommerce_meta_box_errors', 'a:0:{}', 'yes'),
(298, 'woocommerce_product_type', 'physical', 'yes'),
(299, 'woocommerce_allow_tracking', 'no', 'yes'),
(300, 'woocommerce_tracker_last_send', '1523301063', 'yes'),
(305, 'category_children', 'a:0:{}', 'yes'),
(306, 'woocommerce_stripe_settings', 'a:3:{s:7:\"enabled\";s:2:\"no\";s:14:\"create_account\";b:0;s:5:\"email\";b:0;}', 'yes'),
(308, 'woocommerce_ppec_paypal_settings', 'a:33:{s:16:\"reroute_requests\";b:0;s:5:\"email\";s:19:\"dan@delindesign.com\";s:7:\"enabled\";s:3:\"yes\";s:5:\"title\";s:23:\"PayPal Express Checkout\";s:11:\"description\";s:85:\"Pay via PayPal; you can pay with your credit card if you don\'t have a PayPal account.\";s:11:\"environment\";s:4:\"live\";s:12:\"api_username\";s:0:\"\";s:12:\"api_password\";s:0:\"\";s:13:\"api_signature\";s:0:\"\";s:15:\"api_certificate\";s:0:\"\";s:11:\"api_subject\";s:0:\"\";s:20:\"sandbox_api_username\";s:0:\"\";s:20:\"sandbox_api_password\";s:0:\"\";s:21:\"sandbox_api_signature\";s:0:\"\";s:23:\"sandbox_api_certificate\";s:0:\"\";s:19:\"sandbox_api_subject\";s:0:\"\";s:10:\"brand_name\";s:20:\"Morris Nathanson Art\";s:11:\"button_size\";s:5:\"large\";s:21:\"cart_checkout_enabled\";s:3:\"yes\";s:12:\"mark_enabled\";s:2:\"no\";s:14:\"logo_image_url\";s:0:\"\";s:16:\"header_image_url\";s:0:\"\";s:10:\"page_style\";s:0:\"\";s:12:\"landing_page\";s:5:\"Login\";s:14:\"credit_enabled\";s:2:\"no\";s:34:\"checkout_on_single_product_enabled\";s:2:\"no\";s:5:\"debug\";s:2:\"no\";s:14:\"invoice_prefix\";s:3:\"WC-\";s:15:\"require_billing\";s:2:\"no\";s:20:\"require_phone_number\";s:2:\"no\";s:13:\"paymentaction\";s:4:\"sale\";s:16:\"instant_payments\";s:2:\"no\";s:26:\"subtotal_mismatch_behavior\";s:3:\"add\";}', 'yes'),
(309, 'woocommerce_cheque_settings', 'a:1:{s:7:\"enabled\";s:3:\"yes\";}', 'yes'),
(310, 'woocommerce_bacs_settings', 'a:1:{s:7:\"enabled\";s:2:\"no\";}', 'yes'),
(311, 'woocommerce_cod_settings', 'a:1:{s:7:\"enabled\";s:2:\"no\";}', 'yes'),
(312, 'wc_ppec_version', '1.5.3', 'yes'),
(322, 'woocommerce_setup_domestic_live_rates_zone', '1', 'no'),
(323, '_transient_shipping-transient-version', '1523302447', 'yes'),
(324, 'woocommerce_setup_intl_live_rates_zone', '1', 'no'),
(327, 'jetpack_activated', '1', 'yes'),
(330, 'jetpack_activation_source', 'a:2:{i:0;s:7:\"unknown\";i:1;N;}', 'yes'),
(331, 'jetpack_sync_settings_disable', '0', 'yes'),
(332, '_transient_timeout_jetpack_file_data_6.0', '1525808050', 'no'),
(333, '_transient_jetpack_file_data_6.0', 'a:57:{s:32:\"c22c48d7cfe9d38dff2864cfea64636a\";a:15:{s:4:\"name\";s:20:\"Spelling and Grammar\";s:11:\"description\";s:39:\"Check your spelling, style, and grammar\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:1:\"6\";s:20:\"recommendation_order\";s:0:\"\";s:10:\"introduced\";s:3:\"1.1\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:3:\"Yes\";s:13:\"auto_activate\";s:3:\"Yes\";s:11:\"module_tags\";s:7:\"Writing\";s:7:\"feature\";s:7:\"Writing\";s:25:\"additional_search_queries\";s:115:\"after the deadline, afterthedeadline, spell, spellchecker, spelling, grammar, proofreading, style, language, cliche\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"fb5c4814ddc3946a3f22cc838fcb2af3\";a:15:{s:4:\"name\";s:8:\"Carousel\";s:11:\"description\";s:75:\"Display images and galleries in a gorgeous, full-screen browsing experience\";s:14:\"jumpstart_desc\";s:79:\"Brings your photos and images to life as full-size, easily navigable galleries.\";s:4:\"sort\";s:2:\"22\";s:20:\"recommendation_order\";s:2:\"12\";s:10:\"introduced\";s:3:\"1.5\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:2:\"No\";s:13:\"auto_activate\";s:2:\"No\";s:11:\"module_tags\";s:17:\"Photos and Videos\";s:7:\"feature\";s:21:\"Appearance, Jumpstart\";s:25:\"additional_search_queries\";s:80:\"gallery, carousel, diaporama, slideshow, images, lightbox, exif, metadata, image\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"5813eda53235a9a81a69b1f6a4a15db6\";a:15:{s:4:\"name\";s:13:\"Comment Likes\";s:11:\"description\";s:64:\"Increase visitor engagement by adding a Like button to comments.\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:2:\"39\";s:20:\"recommendation_order\";s:2:\"17\";s:10:\"introduced\";s:3:\"5.1\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:3:\"Yes\";s:13:\"auto_activate\";s:2:\"No\";s:11:\"module_tags\";s:6:\"Social\";s:7:\"feature\";s:0:\"\";s:25:\"additional_search_queries\";s:37:\"like widget, like button, like, likes\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"7ef4ca32a1c84fc10ef50c8293cae5df\";a:15:{s:4:\"name\";s:8:\"Comments\";s:11:\"description\";s:80:\"Let readers use WordPress.com, Twitter, Facebook, or Google+ accounts to comment\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:2:\"20\";s:20:\"recommendation_order\";s:0:\"\";s:10:\"introduced\";s:3:\"1.4\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:3:\"Yes\";s:13:\"auto_activate\";s:2:\"No\";s:11:\"module_tags\";s:6:\"Social\";s:7:\"feature\";s:10:\"Engagement\";s:25:\"additional_search_queries\";s:53:\"comments, comment, facebook, twitter, google+, social\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"c5331bfc2648dfeeebe486736d79a72c\";a:15:{s:4:\"name\";s:12:\"Contact Form\";s:11:\"description\";s:57:\"Insert a customizable contact form anywhere on your site.\";s:14:\"jumpstart_desc\";s:111:\"Adds a button to your post and page editors, allowing you to build simple forms to help visitors stay in touch.\";s:4:\"sort\";s:2:\"15\";s:20:\"recommendation_order\";s:2:\"14\";s:10:\"introduced\";s:3:\"1.3\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:2:\"No\";s:13:\"auto_activate\";s:3:\"Yes\";s:11:\"module_tags\";s:5:\"Other\";s:7:\"feature\";s:18:\"Writing, Jumpstart\";s:25:\"additional_search_queries\";s:44:\"contact, form, grunion, feedback, submission\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"707c77d2e8cb0c12d094e5423c8beda8\";a:15:{s:4:\"name\";s:20:\"Custom content types\";s:11:\"description\";s:74:\"Display different types of content on your site with custom content types.\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:2:\"34\";s:20:\"recommendation_order\";s:0:\"\";s:10:\"introduced\";s:3:\"3.1\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:2:\"No\";s:13:\"auto_activate\";s:3:\"Yes\";s:11:\"module_tags\";s:7:\"Writing\";s:7:\"feature\";s:7:\"Writing\";s:25:\"additional_search_queries\";s:72:\"cpt, custom post types, portfolio, portfolios, testimonial, testimonials\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"cd499b1678cfe3aabfc8ca0d3eb7e8b9\";a:15:{s:4:\"name\";s:10:\"Custom CSS\";s:11:\"description\";s:53:\"Tweak your site’s CSS without modifying your theme.\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:1:\"2\";s:20:\"recommendation_order\";s:0:\"\";s:10:\"introduced\";s:3:\"1.7\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:2:\"No\";s:13:\"auto_activate\";s:3:\"Yes\";s:11:\"module_tags\";s:10:\"Appearance\";s:7:\"feature\";s:10:\"Appearance\";s:25:\"additional_search_queries\";s:108:\"css, customize, custom, style, editor, less, sass, preprocessor, font, mobile, appearance, theme, stylesheet\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"7d266d6546645f42cf52a66387699c50\";a:15:{s:4:\"name\";s:0:\"\";s:11:\"description\";s:0:\"\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:0:\"\";s:20:\"recommendation_order\";s:0:\"\";s:10:\"introduced\";s:0:\"\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:0:\"\";s:13:\"auto_activate\";s:0:\"\";s:11:\"module_tags\";s:0:\"\";s:7:\"feature\";s:0:\"\";s:25:\"additional_search_queries\";s:0:\"\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"5d436678d5e010ac6b0f157aa1021554\";a:15:{s:4:\"name\";s:21:\"Enhanced Distribution\";s:11:\"description\";s:27:\"Increase reach and traffic.\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:1:\"5\";s:20:\"recommendation_order\";s:0:\"\";s:10:\"introduced\";s:3:\"1.2\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:3:\"Yes\";s:13:\"auto_activate\";s:6:\"Public\";s:11:\"module_tags\";s:7:\"Writing\";s:7:\"feature\";s:10:\"Engagement\";s:25:\"additional_search_queries\";s:54:\"google, seo, firehose, search, broadcast, broadcasting\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"092b94702bb483a5472578283c2103d6\";a:15:{s:4:\"name\";s:16:\"Google Analytics\";s:11:\"description\";s:56:\"Set up Google Analytics without touching a line of code.\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:2:\"37\";s:20:\"recommendation_order\";s:0:\"\";s:10:\"introduced\";s:3:\"4.5\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:3:\"Yes\";s:13:\"auto_activate\";s:2:\"No\";s:11:\"module_tags\";s:0:\"\";s:7:\"feature\";s:10:\"Engagement\";s:25:\"additional_search_queries\";s:37:\"webmaster, google, analytics, console\";s:12:\"plan_classes\";s:8:\"business\";}s:32:\"6bd77e09440df2b63044cf8cb7963773\";a:15:{s:4:\"name\";s:0:\"\";s:11:\"description\";s:0:\"\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:0:\"\";s:20:\"recommendation_order\";s:0:\"\";s:10:\"introduced\";s:0:\"\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:0:\"\";s:13:\"auto_activate\";s:0:\"\";s:11:\"module_tags\";s:0:\"\";s:7:\"feature\";s:0:\"\";s:25:\"additional_search_queries\";s:0:\"\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"ee1a10e2ef5733ab19eb1eb552d5ecb3\";a:15:{s:4:\"name\";s:19:\"Gravatar Hovercards\";s:11:\"description\";s:58:\"Enable pop-up business cards over commenters’ Gravatars.\";s:14:\"jumpstart_desc\";s:131:\"Let commenters link their profiles to their Gravatar accounts, making it easy for your visitors to learn more about your community.\";s:4:\"sort\";s:2:\"11\";s:20:\"recommendation_order\";s:2:\"13\";s:10:\"introduced\";s:3:\"1.1\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:2:\"No\";s:13:\"auto_activate\";s:3:\"Yes\";s:11:\"module_tags\";s:18:\"Social, Appearance\";s:7:\"feature\";s:21:\"Appearance, Jumpstart\";s:25:\"additional_search_queries\";s:20:\"gravatar, hovercards\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"284c08538b0bdc266315b2cf80b9c044\";a:15:{s:4:\"name\";s:0:\"\";s:11:\"description\";s:0:\"\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:0:\"\";s:20:\"recommendation_order\";s:0:\"\";s:10:\"introduced\";s:0:\"\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:0:\"\";s:13:\"auto_activate\";s:0:\"\";s:11:\"module_tags\";s:0:\"\";s:7:\"feature\";s:0:\"\";s:25:\"additional_search_queries\";s:0:\"\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"0ce5c3ac630dea9f41215e48bb0f52f3\";a:15:{s:4:\"name\";s:15:\"Infinite Scroll\";s:11:\"description\";s:53:\"Automatically load new content when a visitor scrolls\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:2:\"26\";s:20:\"recommendation_order\";s:0:\"\";s:10:\"introduced\";s:3:\"2.0\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:2:\"No\";s:13:\"auto_activate\";s:2:\"No\";s:11:\"module_tags\";s:10:\"Appearance\";s:7:\"feature\";s:10:\"Appearance\";s:25:\"additional_search_queries\";s:33:\"scroll, infinite, infinite scroll\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"87da2858d4f9cadb6a44fdcf32e8d2b5\";a:15:{s:4:\"name\";s:8:\"JSON API\";s:11:\"description\";s:51:\"Allow applications to securely access your content.\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:2:\"19\";s:20:\"recommendation_order\";s:0:\"\";s:10:\"introduced\";s:3:\"1.9\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:3:\"Yes\";s:13:\"auto_activate\";s:6:\"Public\";s:11:\"module_tags\";s:19:\"Writing, Developers\";s:7:\"feature\";s:7:\"General\";s:25:\"additional_search_queries\";s:50:\"api, rest, develop, developers, json, klout, oauth\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"004962cb7cb9ec2b64769ac4df509217\";a:15:{s:4:\"name\";s:14:\"Beautiful Math\";s:11:\"description\";s:57:\"Use LaTeX markup for complex equations and other geekery.\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:2:\"12\";s:20:\"recommendation_order\";s:0:\"\";s:10:\"introduced\";s:3:\"1.1\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:2:\"No\";s:13:\"auto_activate\";s:3:\"Yes\";s:11:\"module_tags\";s:7:\"Writing\";s:7:\"feature\";s:7:\"Writing\";s:25:\"additional_search_queries\";s:47:\"latex, math, equation, equations, formula, code\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"7f408184bee8850d439c01322867e72c\";a:15:{s:4:\"name\";s:11:\"Lazy Images\";s:11:\"description\";s:16:\"Lazy load images\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:2:\"24\";s:20:\"recommendation_order\";s:2:\"14\";s:10:\"introduced\";s:5:\"5.6.0\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:2:\"No\";s:13:\"auto_activate\";s:2:\"No\";s:11:\"module_tags\";s:23:\"Appearance, Recommended\";s:7:\"feature\";s:10:\"Appearance\";s:25:\"additional_search_queries\";s:33:\"mobile, theme, performance, image\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"2ad914b747f382ae918ed3b37077d4a1\";a:15:{s:4:\"name\";s:5:\"Likes\";s:11:\"description\";s:63:\"Give visitors an easy way to show they appreciate your content.\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:2:\"23\";s:20:\"recommendation_order\";s:0:\"\";s:10:\"introduced\";s:3:\"2.2\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:3:\"Yes\";s:13:\"auto_activate\";s:2:\"No\";s:11:\"module_tags\";s:6:\"Social\";s:7:\"feature\";s:10:\"Engagement\";s:25:\"additional_search_queries\";s:26:\"like, likes, wordpress.com\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"b347263e3470979442ebf0514e41e893\";a:15:{s:4:\"name\";s:6:\"Manage\";s:11:\"description\";s:54:\"Manage all of your sites from a centralized dashboard.\";s:14:\"jumpstart_desc\";s:151:\"Helps you remotely manage plugins, turn on automated updates, and more from <a href=\"https://wordpress.com/plugins/\" target=\"_blank\">wordpress.com</a>.\";s:4:\"sort\";s:1:\"1\";s:20:\"recommendation_order\";s:1:\"3\";s:10:\"introduced\";s:3:\"3.4\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:3:\"Yes\";s:13:\"auto_activate\";s:3:\"Yes\";s:11:\"module_tags\";s:35:\"Centralized Management, Recommended\";s:7:\"feature\";s:7:\"General\";s:25:\"additional_search_queries\";s:26:\"manage, management, remote\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"589982245aa6f495b72ab7cf57a1a48e\";a:15:{s:4:\"name\";s:8:\"Markdown\";s:11:\"description\";s:50:\"Write posts or pages in plain-text Markdown syntax\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:2:\"31\";s:20:\"recommendation_order\";s:0:\"\";s:10:\"introduced\";s:3:\"2.8\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:2:\"No\";s:13:\"auto_activate\";s:2:\"No\";s:11:\"module_tags\";s:7:\"Writing\";s:7:\"feature\";s:7:\"Writing\";s:25:\"additional_search_queries\";s:12:\"md, markdown\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"d3bec8e063d637bc285018241b783725\";a:15:{s:4:\"name\";s:21:\"WordPress.com Toolbar\";s:11:\"description\";s:91:\"Replaces the admin bar with a useful toolbar to quickly manage your site via WordPress.com.\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:2:\"38\";s:20:\"recommendation_order\";s:2:\"16\";s:10:\"introduced\";s:3:\"4.8\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:3:\"Yes\";s:13:\"auto_activate\";s:2:\"No\";s:11:\"module_tags\";s:7:\"General\";s:7:\"feature\";s:0:\"\";s:25:\"additional_search_queries\";s:19:\"adminbar, masterbar\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"6ab1c3e749bcfba2dedbaebe6c9fc614\";a:15:{s:4:\"name\";s:12:\"Mobile Theme\";s:11:\"description\";s:31:\"Enable the Jetpack Mobile theme\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:2:\"21\";s:20:\"recommendation_order\";s:2:\"11\";s:10:\"introduced\";s:3:\"1.8\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:2:\"No\";s:13:\"auto_activate\";s:2:\"No\";s:11:\"module_tags\";s:31:\"Appearance, Mobile, Recommended\";s:7:\"feature\";s:10:\"Appearance\";s:25:\"additional_search_queries\";s:24:\"mobile, theme, minileven\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"b7be7da643ec641511839ecc6afb6def\";a:15:{s:4:\"name\";s:0:\"\";s:11:\"description\";s:0:\"\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:0:\"\";s:20:\"recommendation_order\";s:0:\"\";s:10:\"introduced\";s:0:\"\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:0:\"\";s:13:\"auto_activate\";s:0:\"\";s:11:\"module_tags\";s:0:\"\";s:7:\"feature\";s:0:\"\";s:25:\"additional_search_queries\";s:0:\"\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"d54f83ff429a8a37ace796de98459411\";a:15:{s:4:\"name\";s:0:\"\";s:11:\"description\";s:0:\"\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:0:\"\";s:20:\"recommendation_order\";s:0:\"\";s:10:\"introduced\";s:0:\"\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:0:\"\";s:13:\"auto_activate\";s:0:\"\";s:11:\"module_tags\";s:0:\"\";s:7:\"feature\";s:0:\"\";s:25:\"additional_search_queries\";s:0:\"\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"0f8b373fa12c825162c0b0bc20b8bbdd\";a:15:{s:4:\"name\";s:0:\"\";s:11:\"description\";s:0:\"\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:0:\"\";s:20:\"recommendation_order\";s:0:\"\";s:10:\"introduced\";s:0:\"\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:0:\"\";s:13:\"auto_activate\";s:0:\"\";s:11:\"module_tags\";s:0:\"\";s:7:\"feature\";s:0:\"\";s:25:\"additional_search_queries\";s:0:\"\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"5d7b0750cb34a4a72a44fa67790de639\";a:15:{s:4:\"name\";s:0:\"\";s:11:\"description\";s:0:\"\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:0:\"\";s:20:\"recommendation_order\";s:0:\"\";s:10:\"introduced\";s:0:\"\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:0:\"\";s:13:\"auto_activate\";s:0:\"\";s:11:\"module_tags\";s:0:\"\";s:7:\"feature\";s:0:\"\";s:25:\"additional_search_queries\";s:0:\"\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"f07fde8db279ffb0116c727df72c6374\";a:15:{s:4:\"name\";s:7:\"Monitor\";s:11:\"description\";s:61:\"Receive immediate notifications if your site goes down, 24/7.\";s:14:\"jumpstart_desc\";s:61:\"Receive immediate notifications if your site goes down, 24/7.\";s:4:\"sort\";s:2:\"28\";s:20:\"recommendation_order\";s:2:\"10\";s:10:\"introduced\";s:3:\"2.6\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:3:\"Yes\";s:13:\"auto_activate\";s:2:\"No\";s:11:\"module_tags\";s:11:\"Recommended\";s:7:\"feature\";s:19:\"Security, Jumpstart\";s:25:\"additional_search_queries\";s:37:\"monitor, uptime, downtime, monitoring\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"136a5445a49150db75472862f3d3aefb\";a:15:{s:4:\"name\";s:13:\"Notifications\";s:11:\"description\";s:57:\"Receive instant notifications of site comments and likes.\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:2:\"13\";s:20:\"recommendation_order\";s:0:\"\";s:10:\"introduced\";s:3:\"1.9\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:3:\"Yes\";s:13:\"auto_activate\";s:3:\"Yes\";s:11:\"module_tags\";s:5:\"Other\";s:7:\"feature\";s:7:\"General\";s:25:\"additional_search_queries\";s:62:\"notification, notifications, toolbar, adminbar, push, comments\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"395d8ae651afabb54d1e98440674b384\";a:15:{s:4:\"name\";s:0:\"\";s:11:\"description\";s:0:\"\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:0:\"\";s:20:\"recommendation_order\";s:0:\"\";s:10:\"introduced\";s:0:\"\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:0:\"\";s:13:\"auto_activate\";s:0:\"\";s:11:\"module_tags\";s:0:\"\";s:7:\"feature\";s:0:\"\";s:25:\"additional_search_queries\";s:0:\"\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"4484ac68583fbbaab0ef698cdc986950\";a:15:{s:4:\"name\";s:6:\"Photon\";s:11:\"description\";s:29:\"Serve images from our servers\";s:14:\"jumpstart_desc\";s:141:\"Mirrors and serves your images from our free and fast image CDN, improving your site’s performance with no additional load on your servers.\";s:4:\"sort\";s:2:\"25\";s:20:\"recommendation_order\";s:1:\"1\";s:10:\"introduced\";s:3:\"2.0\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:3:\"Yes\";s:13:\"auto_activate\";s:2:\"No\";s:11:\"module_tags\";s:42:\"Photos and Videos, Appearance, Recommended\";s:7:\"feature\";s:34:\"Recommended, Jumpstart, Appearance\";s:25:\"additional_search_queries\";s:38:\"photon, image, cdn, performance, speed\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"6f30193afa5b1360e3fa2676501b5e3a\";a:15:{s:4:\"name\";s:13:\"Post by email\";s:11:\"description\";s:33:\"Publish posts by sending an email\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:2:\"14\";s:20:\"recommendation_order\";s:0:\"\";s:10:\"introduced\";s:3:\"2.0\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:3:\"Yes\";s:13:\"auto_activate\";s:3:\"Yes\";s:11:\"module_tags\";s:7:\"Writing\";s:7:\"feature\";s:7:\"Writing\";s:25:\"additional_search_queries\";s:20:\"post by email, email\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"3e9f8bd3755d92e8e5d06966a957beb8\";a:15:{s:4:\"name\";s:7:\"Protect\";s:11:\"description\";s:41:\"Block suspicious-looking sign in activity\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:1:\"1\";s:20:\"recommendation_order\";s:1:\"4\";s:10:\"introduced\";s:3:\"3.4\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:3:\"Yes\";s:13:\"auto_activate\";s:3:\"Yes\";s:11:\"module_tags\";s:11:\"Recommended\";s:7:\"feature\";s:8:\"Security\";s:25:\"additional_search_queries\";s:65:\"security, secure, protection, botnet, brute force, protect, login\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"0cacc8ab2145ad11cb54d181a98aa550\";a:15:{s:4:\"name\";s:9:\"Publicize\";s:11:\"description\";s:27:\"Automated social marketing.\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:2:\"10\";s:20:\"recommendation_order\";s:1:\"7\";s:10:\"introduced\";s:3:\"2.0\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:3:\"Yes\";s:13:\"auto_activate\";s:3:\"Yes\";s:11:\"module_tags\";s:19:\"Social, Recommended\";s:7:\"feature\";s:10:\"Engagement\";s:25:\"additional_search_queries\";s:107:\"facebook, twitter, google+, googleplus, google, path, tumblr, linkedin, social, tweet, connections, sharing\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"a528c2f803a92c5c2effa67cd33ab33a\";a:15:{s:4:\"name\";s:20:\"Progressive Web Apps\";s:11:\"description\";s:85:\"Speed up and improve the reliability of your site using the latest in web technology.\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:2:\"38\";s:20:\"recommendation_order\";s:2:\"18\";s:10:\"introduced\";s:5:\"5.6.0\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:3:\"Yes\";s:13:\"auto_activate\";s:2:\"No\";s:11:\"module_tags\";s:10:\"Developers\";s:7:\"feature\";s:7:\"Traffic\";s:25:\"additional_search_queries\";s:26:\"manifest, pwa, progressive\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"329b8efce059081d46936ece0c6736b3\";a:15:{s:4:\"name\";s:0:\"\";s:11:\"description\";s:0:\"\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:0:\"\";s:20:\"recommendation_order\";s:0:\"\";s:10:\"introduced\";s:0:\"\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:0:\"\";s:13:\"auto_activate\";s:0:\"\";s:11:\"module_tags\";s:0:\"\";s:7:\"feature\";s:0:\"\";s:25:\"additional_search_queries\";s:0:\"\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"5fdd42d482712fbdaf000b28ea7adce9\";a:15:{s:4:\"name\";s:13:\"Related posts\";s:11:\"description\";s:64:\"Increase page views by showing related content to your visitors.\";s:14:\"jumpstart_desc\";s:113:\"Keep visitors engaged on your blog by highlighting relevant and new content at the bottom of each published post.\";s:4:\"sort\";s:2:\"29\";s:20:\"recommendation_order\";s:1:\"9\";s:10:\"introduced\";s:3:\"2.9\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:3:\"Yes\";s:13:\"auto_activate\";s:2:\"No\";s:11:\"module_tags\";s:11:\"Recommended\";s:7:\"feature\";s:21:\"Engagement, Jumpstart\";s:25:\"additional_search_queries\";s:22:\"related, related posts\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"2c5096ef610018e98a8bcccfbea4471e\";a:15:{s:4:\"name\";s:6:\"Search\";s:11:\"description\";s:41:\"Enhanced search, powered by Elasticsearch\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:2:\"34\";s:20:\"recommendation_order\";s:0:\"\";s:10:\"introduced\";s:3:\"5.0\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:5:\"false\";s:19:\"requires_connection\";s:3:\"Yes\";s:13:\"auto_activate\";s:2:\"No\";s:11:\"module_tags\";s:0:\"\";s:7:\"feature\";s:6:\"Search\";s:25:\"additional_search_queries\";s:6:\"search\";s:12:\"plan_classes\";s:8:\"business\";}s:32:\"0d81dd7df3ad2f245e84fd4fb66bf829\";a:15:{s:4:\"name\";s:9:\"SEO Tools\";s:11:\"description\";s:50:\"Better results on search engines and social media.\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:2:\"35\";s:20:\"recommendation_order\";s:2:\"15\";s:10:\"introduced\";s:3:\"4.4\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:3:\"Yes\";s:13:\"auto_activate\";s:2:\"No\";s:11:\"module_tags\";s:18:\"Social, Appearance\";s:7:\"feature\";s:7:\"Traffic\";s:25:\"additional_search_queries\";s:81:\"search engine optimization, social preview, meta description, custom title format\";s:12:\"plan_classes\";s:17:\"business, premium\";}s:32:\"32aaa676b3b6c9f3ef22430e1e0bca24\";a:15:{s:4:\"name\";s:7:\"Sharing\";s:11:\"description\";s:37:\"Allow visitors to share your content.\";s:14:\"jumpstart_desc\";s:116:\"Twitter, Facebook and Google+ buttons at the bottom of each post, making it easy for visitors to share your content.\";s:4:\"sort\";s:1:\"7\";s:20:\"recommendation_order\";s:1:\"6\";s:10:\"introduced\";s:3:\"1.1\";s:7:\"changed\";s:3:\"1.2\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:2:\"No\";s:13:\"auto_activate\";s:3:\"Yes\";s:11:\"module_tags\";s:19:\"Social, Recommended\";s:7:\"feature\";s:21:\"Engagement, Jumpstart\";s:25:\"additional_search_queries\";s:141:\"share, sharing, sharedaddy, buttons, icons, email, facebook, twitter, google+, linkedin, pinterest, pocket, press this, print, reddit, tumblr\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"948472b453cda59b38bb7c37af889af0\";a:15:{s:4:\"name\";s:16:\"Shortcode Embeds\";s:11:\"description\";s:50:\"Embed media from popular sites without any coding.\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:1:\"3\";s:20:\"recommendation_order\";s:0:\"\";s:10:\"introduced\";s:3:\"1.1\";s:7:\"changed\";s:3:\"1.2\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:2:\"No\";s:13:\"auto_activate\";s:3:\"Yes\";s:11:\"module_tags\";s:46:\"Photos and Videos, Social, Writing, Appearance\";s:7:\"feature\";s:7:\"Writing\";s:25:\"additional_search_queries\";s:236:\"shortcodes, shortcode, embeds, media, bandcamp, dailymotion, facebook, flickr, google calendars, google maps, google+, polldaddy, recipe, recipes, scribd, slideshare, slideshow, slideshows, soundcloud, ted, twitter, vimeo, vine, youtube\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"7d00a6ca0a79fbe893275aaf6ed6ae42\";a:15:{s:4:\"name\";s:16:\"WP.me Shortlinks\";s:11:\"description\";s:54:\"Create short and simple links for all posts and pages.\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:1:\"8\";s:20:\"recommendation_order\";s:0:\"\";s:10:\"introduced\";s:3:\"1.1\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:3:\"Yes\";s:13:\"auto_activate\";s:3:\"Yes\";s:11:\"module_tags\";s:6:\"Social\";s:7:\"feature\";s:7:\"Writing\";s:25:\"additional_search_queries\";s:17:\"shortlinks, wp.me\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"372e711395f23c466e04d4fd07f73099\";a:15:{s:4:\"name\";s:0:\"\";s:11:\"description\";s:0:\"\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:0:\"\";s:20:\"recommendation_order\";s:0:\"\";s:10:\"introduced\";s:0:\"\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:0:\"\";s:13:\"auto_activate\";s:0:\"\";s:11:\"module_tags\";s:0:\"\";s:7:\"feature\";s:0:\"\";s:25:\"additional_search_queries\";s:0:\"\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"2ea687cec293289a2a3e5f0459e79768\";a:15:{s:4:\"name\";s:8:\"Sitemaps\";s:11:\"description\";s:50:\"Make it easy for search engines to find your site.\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:2:\"13\";s:20:\"recommendation_order\";s:0:\"\";s:10:\"introduced\";s:3:\"3.9\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:2:\"No\";s:13:\"auto_activate\";s:6:\"Public\";s:11:\"module_tags\";s:20:\"Recommended, Traffic\";s:7:\"feature\";s:0:\"\";s:25:\"additional_search_queries\";s:39:\"sitemap, traffic, search, site map, seo\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"2fe9dc2c7389d4f0825a0b23bc8b19d1\";a:15:{s:4:\"name\";s:0:\"\";s:11:\"description\";s:0:\"\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:0:\"\";s:20:\"recommendation_order\";s:0:\"\";s:10:\"introduced\";s:0:\"\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:0:\"\";s:13:\"auto_activate\";s:0:\"\";s:11:\"module_tags\";s:0:\"\";s:7:\"feature\";s:0:\"\";s:25:\"additional_search_queries\";s:0:\"\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"e7cf8a7e0f151ccf7cbdc6d8f118f316\";a:15:{s:4:\"name\";s:14:\"Single Sign On\";s:11:\"description\";s:62:\"Allow users to log into this site using WordPress.com accounts\";s:14:\"jumpstart_desc\";s:98:\"Lets you log in to all your Jetpack-enabled sites with one click using your WordPress.com account.\";s:4:\"sort\";s:2:\"30\";s:20:\"recommendation_order\";s:1:\"5\";s:10:\"introduced\";s:3:\"2.6\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:3:\"Yes\";s:13:\"auto_activate\";s:2:\"No\";s:11:\"module_tags\";s:10:\"Developers\";s:7:\"feature\";s:19:\"Security, Jumpstart\";s:25:\"additional_search_queries\";s:34:\"sso, single sign on, login, log in\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"34fb073ed896af853ed48bd5739240cb\";a:15:{s:4:\"name\";s:10:\"Site Stats\";s:11:\"description\";s:44:\"Collect valuable traffic stats and insights.\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:1:\"1\";s:20:\"recommendation_order\";s:1:\"2\";s:10:\"introduced\";s:3:\"1.1\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:3:\"Yes\";s:13:\"auto_activate\";s:3:\"Yes\";s:11:\"module_tags\";s:23:\"Site Stats, Recommended\";s:7:\"feature\";s:10:\"Engagement\";s:25:\"additional_search_queries\";s:54:\"statistics, tracking, analytics, views, traffic, stats\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"8de0dfff24a17cf0fa0011dfc691a3f3\";a:15:{s:4:\"name\";s:13:\"Subscriptions\";s:11:\"description\";s:87:\"Allow users to subscribe to your posts and comments and receive notifications via email\";s:14:\"jumpstart_desc\";s:126:\"Give visitors two easy subscription options — while commenting, or via a separate email subscription widget you can display.\";s:4:\"sort\";s:1:\"9\";s:20:\"recommendation_order\";s:1:\"8\";s:10:\"introduced\";s:3:\"1.2\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:3:\"Yes\";s:13:\"auto_activate\";s:3:\"Yes\";s:11:\"module_tags\";s:6:\"Social\";s:7:\"feature\";s:21:\"Engagement, Jumpstart\";s:25:\"additional_search_queries\";s:74:\"subscriptions, subscription, email, follow, followers, subscribers, signup\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"4744f348db095538d3edcacb0ed99c89\";a:15:{s:4:\"name\";s:0:\"\";s:11:\"description\";s:0:\"\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:0:\"\";s:20:\"recommendation_order\";s:0:\"\";s:10:\"introduced\";s:0:\"\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:0:\"\";s:13:\"auto_activate\";s:0:\"\";s:11:\"module_tags\";s:0:\"\";s:7:\"feature\";s:0:\"\";s:25:\"additional_search_queries\";s:0:\"\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"d89db0d934b39f86065ff58e73594070\";a:15:{s:4:\"name\";s:15:\"Tiled Galleries\";s:11:\"description\";s:61:\"Display image galleries in a variety of elegant arrangements.\";s:14:\"jumpstart_desc\";s:61:\"Display image galleries in a variety of elegant arrangements.\";s:4:\"sort\";s:2:\"24\";s:20:\"recommendation_order\";s:0:\"\";s:10:\"introduced\";s:3:\"2.1\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:2:\"No\";s:13:\"auto_activate\";s:2:\"No\";s:11:\"module_tags\";s:17:\"Photos and Videos\";s:7:\"feature\";s:21:\"Appearance, Jumpstart\";s:25:\"additional_search_queries\";s:43:\"gallery, tiles, tiled, grid, mosaic, images\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"01987a7ba5e19786f2992501add8181a\";a:15:{s:4:\"name\";s:0:\"\";s:11:\"description\";s:0:\"\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:0:\"\";s:20:\"recommendation_order\";s:0:\"\";s:10:\"introduced\";s:0:\"\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:0:\"\";s:13:\"auto_activate\";s:0:\"\";s:11:\"module_tags\";s:0:\"\";s:7:\"feature\";s:0:\"\";s:25:\"additional_search_queries\";s:0:\"\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"20459cc462babfc5a82adf6b34f6e8b1\";a:15:{s:4:\"name\";s:12:\"Data Backups\";s:11:\"description\";s:54:\"Off-site backups, security scans, and automatic fixes.\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:2:\"32\";s:20:\"recommendation_order\";s:0:\"\";s:10:\"introduced\";s:5:\"0:1.2\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:5:\"false\";s:4:\"free\";s:5:\"false\";s:19:\"requires_connection\";s:3:\"Yes\";s:13:\"auto_activate\";s:3:\"Yes\";s:11:\"module_tags\";s:0:\"\";s:7:\"feature\";s:16:\"Security, Health\";s:25:\"additional_search_queries\";s:28:\"vaultpress, backup, security\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"836245eb0a8f0c5272542305a88940c1\";a:15:{s:4:\"name\";s:17:\"Site verification\";s:11:\"description\";s:58:\"Establish your site\'s authenticity with external services.\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:2:\"33\";s:20:\"recommendation_order\";s:0:\"\";s:10:\"introduced\";s:3:\"3.0\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:2:\"No\";s:13:\"auto_activate\";s:3:\"Yes\";s:11:\"module_tags\";s:0:\"\";s:7:\"feature\";s:10:\"Engagement\";s:25:\"additional_search_queries\";s:56:\"webmaster, seo, google, bing, pinterest, search, console\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"e94397a5c47c1be995eff613e65a674f\";a:15:{s:4:\"name\";s:10:\"VideoPress\";s:11:\"description\";s:27:\"Fast, ad-free video hosting\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:2:\"27\";s:20:\"recommendation_order\";s:0:\"\";s:10:\"introduced\";s:3:\"2.5\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:5:\"false\";s:19:\"requires_connection\";s:3:\"Yes\";s:13:\"auto_activate\";s:0:\"\";s:11:\"module_tags\";s:17:\"Photos and Videos\";s:7:\"feature\";s:7:\"Writing\";s:25:\"additional_search_queries\";s:25:\"video, videos, videopress\";s:12:\"plan_classes\";s:17:\"business, premium\";}s:32:\"032cd76e08467c732ccb026efda0c9cd\";a:15:{s:4:\"name\";s:17:\"Widget Visibility\";s:11:\"description\";s:42:\"Control where widgets appear on your site.\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:2:\"17\";s:20:\"recommendation_order\";s:0:\"\";s:10:\"introduced\";s:3:\"2.4\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:2:\"No\";s:13:\"auto_activate\";s:3:\"Yes\";s:11:\"module_tags\";s:10:\"Appearance\";s:7:\"feature\";s:10:\"Appearance\";s:25:\"additional_search_queries\";s:54:\"widget visibility, logic, conditional, widgets, widget\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"9b3e84beedf2e96f1ac5dd6498d2b1aa\";a:15:{s:4:\"name\";s:21:\"Extra Sidebar Widgets\";s:11:\"description\";s:54:\"Add images, Twitter streams, and more to your sidebar.\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:1:\"4\";s:20:\"recommendation_order\";s:0:\"\";s:10:\"introduced\";s:3:\"1.2\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:2:\"No\";s:13:\"auto_activate\";s:3:\"Yes\";s:11:\"module_tags\";s:18:\"Social, Appearance\";s:7:\"feature\";s:10:\"Appearance\";s:25:\"additional_search_queries\";s:65:\"widget, widgets, facebook, gallery, twitter, gravatar, image, rss\";s:12:\"plan_classes\";s:0:\"\";}s:32:\"7724fd9600745cf93e37cc09282e1a37\";a:15:{s:4:\"name\";s:3:\"Ads\";s:11:\"description\";s:60:\"Earn income by allowing Jetpack to display high quality ads.\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:1:\"1\";s:20:\"recommendation_order\";s:0:\"\";s:10:\"introduced\";s:5:\"4.5.0\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:3:\"Yes\";s:13:\"auto_activate\";s:2:\"No\";s:11:\"module_tags\";s:19:\"Traffic, Appearance\";s:7:\"feature\";s:0:\"\";s:25:\"additional_search_queries\";s:26:\"advertising, ad codes, ads\";s:12:\"plan_classes\";s:17:\"premium, business\";}s:32:\"5b8f8e5b5a1887e3c0393cb78d5143a3\";a:15:{s:4:\"name\";s:0:\"\";s:11:\"description\";s:0:\"\";s:14:\"jumpstart_desc\";s:0:\"\";s:4:\"sort\";s:0:\"\";s:20:\"recommendation_order\";s:0:\"\";s:10:\"introduced\";s:0:\"\";s:7:\"changed\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";s:4:\"free\";s:0:\"\";s:19:\"requires_connection\";s:0:\"\";s:13:\"auto_activate\";s:0:\"\";s:11:\"module_tags\";s:0:\"\";s:7:\"feature\";s:0:\"\";s:25:\"additional_search_queries\";s:0:\"\";s:12:\"plan_classes\";s:0:\"\";}}', 'no'),
(334, 'jetpack_available_modules', 'a:1:{s:3:\"6.0\";a:43:{s:18:\"after-the-deadline\";s:3:\"1.1\";s:8:\"carousel\";s:3:\"1.5\";s:13:\"comment-likes\";s:3:\"5.1\";s:8:\"comments\";s:3:\"1.4\";s:12:\"contact-form\";s:3:\"1.3\";s:20:\"custom-content-types\";s:3:\"3.1\";s:10:\"custom-css\";s:3:\"1.7\";s:21:\"enhanced-distribution\";s:3:\"1.2\";s:16:\"google-analytics\";s:3:\"4.5\";s:19:\"gravatar-hovercards\";s:3:\"1.1\";s:15:\"infinite-scroll\";s:3:\"2.0\";s:8:\"json-api\";s:3:\"1.9\";s:5:\"latex\";s:3:\"1.1\";s:11:\"lazy-images\";s:5:\"5.6.0\";s:5:\"likes\";s:3:\"2.2\";s:6:\"manage\";s:3:\"3.4\";s:8:\"markdown\";s:3:\"2.8\";s:9:\"masterbar\";s:3:\"4.8\";s:9:\"minileven\";s:3:\"1.8\";s:7:\"monitor\";s:3:\"2.6\";s:5:\"notes\";s:3:\"1.9\";s:6:\"photon\";s:3:\"2.0\";s:13:\"post-by-email\";s:3:\"2.0\";s:7:\"protect\";s:3:\"3.4\";s:9:\"publicize\";s:3:\"2.0\";s:3:\"pwa\";s:5:\"5.6.0\";s:13:\"related-posts\";s:3:\"2.9\";s:6:\"search\";s:3:\"5.0\";s:9:\"seo-tools\";s:3:\"4.4\";s:10:\"sharedaddy\";s:3:\"1.1\";s:10:\"shortcodes\";s:3:\"1.1\";s:10:\"shortlinks\";s:3:\"1.1\";s:8:\"sitemaps\";s:3:\"3.9\";s:3:\"sso\";s:3:\"2.6\";s:5:\"stats\";s:3:\"1.1\";s:13:\"subscriptions\";s:3:\"1.2\";s:13:\"tiled-gallery\";s:3:\"2.1\";s:10:\"vaultpress\";s:5:\"0:1.2\";s:18:\"verification-tools\";s:3:\"3.0\";s:10:\"videopress\";s:3:\"2.5\";s:17:\"widget-visibility\";s:3:\"2.4\";s:7:\"widgets\";s:3:\"1.2\";s:7:\"wordads\";s:5:\"4.5.0\";}}', 'yes'),
(335, 'jetpack_options', 'a:4:{s:7:\"version\";s:14:\"6.0:1523302450\";s:11:\"old_version\";s:14:\"6.0:1523302450\";s:28:\"fallback_no_verify_ssl_certs\";i:0;s:9:\"time_diff\";i:0;}', 'yes'),
(338, 'do_activate', '0', 'yes'),
(367, 'woocommerce_catalog_columns', '3', 'yes'),
(368, '_transient_timeout_wc_shipping_method_count_1_1523302447', '1525895010', 'no'),
(369, '_transient_wc_shipping_method_count_1_1523302447', '0', 'no'),
(372, 'WPLANG', '', 'yes'),
(373, 'new_admin_email', 'dan@delindesign.com', 'yes'),
(384, '_transient_product_query-transient-version', '1524159068', 'yes'),
(385, '_transient_product-transient-version', '1524159068', 'yes'),
(450, 'slick-slider', 'a:49:{s:18:\"showOnGalleryModal\";s:1:\"1\";s:11:\"showCaption\";s:0:\"\";s:13:\"accessibility\";s:1:\"1\";s:14:\"adaptiveHeight\";s:0:\"\";s:8:\"autoplay\";s:0:\"\";s:13:\"autoplaySpeed\";s:4:\"3000\";s:6:\"arrows\";s:1:\"1\";s:8:\"asNavFor\";s:0:\"\";s:12:\"appendArrows\";s:0:\"\";s:10:\"appendDots\";s:0:\"\";s:9:\"prevArrow\";s:90:\"&lt;button type=&quot;button&quot; class=&quot;slick-prev&quot;&gt;Previous&lt;/button&gt;\";s:9:\"nextArrow\";s:86:\"&lt;button type=&quot;button&quot; class=&quot;slick-next&quot;&gt;Next&lt;/button&gt;\";s:10:\"centerMode\";s:0:\"\";s:13:\"centerPadding\";s:4:\"50px\";s:7:\"cssEase\";s:4:\"ease\";s:12:\"customPaging\";s:0:\"\";s:4:\"dots\";s:0:\"\";s:9:\"dotsClass\";s:10:\"slick-dots\";s:9:\"draggable\";s:1:\"1\";s:4:\"fade\";s:0:\"\";s:13:\"focusOnChange\";s:0:\"\";s:13:\"focusOnSelect\";s:0:\"\";s:6:\"easing\";s:6:\"linear\";s:12:\"edgeFriction\";s:4:\"0.15\";s:8:\"infinite\";s:1:\"1\";s:12:\"initialSlide\";s:1:\"0\";s:8:\"lazyLoad\";s:8:\"ondemand\";s:12:\"pauseOnFocus\";s:1:\"1\";s:12:\"pauseOnHover\";s:1:\"1\";s:16:\"pauseOnDotsHover\";s:0:\"\";s:9:\"respondTo\";s:6:\"window\";s:4:\"rows\";s:1:\"1\";s:5:\"slide\";s:0:\"\";s:12:\"slidesPerRow\";s:1:\"1\";s:12:\"slidesToShow\";s:1:\"1\";s:14:\"slidesToScroll\";s:1:\"1\";s:5:\"speed\";s:3:\"300\";s:5:\"swipe\";s:1:\"1\";s:12:\"swipeToSlide\";s:0:\"\";s:9:\"touchMove\";s:1:\"1\";s:14:\"touchThreshold\";s:1:\"5\";s:6:\"useCSS\";s:1:\"1\";s:12:\"useTransform\";s:0:\"\";s:13:\"variableWidth\";s:0:\"\";s:8:\"vertical\";s:0:\"\";s:15:\"verticalSwiping\";s:0:\"\";s:3:\"rtl\";s:0:\"\";s:14:\"waitForAnimate\";s:1:\"1\";s:6:\"zIndex\";s:4:\"1000\";}', 'yes'),
(455, 'widget_metaslider_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(456, 'ms_hide_all_ads_until', '1524593093', 'yes'),
(457, 'metaslider_systemcheck', 'a:2:{s:16:\"wordPressVersion\";b:0;s:12:\"imageLibrary\";b:0;}', 'no'),
(458, 'ml-slider_children', 'a:0:{}', 'yes'),
(462, 'metaslider_tour_cancelled_on', 'step_preview_slideshow', 'yes'),
(464, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:\"auto_add\";a:1:{i:0;i:27;}}', 'yes'),
(471, 'wpcf7', 'a:2:{s:7:\"version\";s:5:\"5.0.1\";s:13:\"bulk_validate\";a:4:{s:9:\"timestamp\";d:1523372666;s:7:\"version\";s:5:\"5.0.1\";s:11:\"count_valid\";i:1;s:13:\"count_invalid\";i:0;}}', 'yes'),
(482, 'fancybox_enableImg', '', 'yes'),
(483, 'fancybox_enableInline', '1', 'yes'),
(484, 'fancybox_enablePDF', '', 'yes'),
(485, 'fancybox_enableSWF', '', 'yes'),
(486, 'fancybox_enableSVG', '', 'yes'),
(487, 'fancybox_enableYoutube', '', 'yes'),
(488, 'fancybox_enableVimeo', '', 'yes'),
(489, 'fancybox_enableDailymotion', '', 'yes'),
(490, 'fancybox_enableiFrame', '1', 'yes'),
(491, 'fancybox_overlayShow', '1', 'yes'),
(492, 'fancybox_hideOnOverlayClick', '1', 'yes'),
(493, 'fancybox_overlayOpacity', '', 'yes'),
(494, 'fancybox_overlayColor', '', 'yes'),
(495, 'fancybox_overlaySpotlight', '', 'yes'),
(496, 'fancybox_showCloseButton', '1', 'yes'),
(497, 'fancybox_backgroundColor', '', 'yes'),
(498, 'fancybox_textColor', '', 'yes'),
(499, 'fancybox_titleColor', '', 'yes'),
(500, 'fancybox_paddingColor', '', 'yes'),
(501, 'fancybox_borderRadius', '', 'yes'),
(502, 'fancybox_width', '', 'yes'),
(503, 'fancybox_height', '', 'yes'),
(504, 'fancybox_padding', '', 'yes'),
(505, 'fancybox_margin', '20', 'yes'),
(506, 'fancybox_enableEscapeButton', '1', 'yes'),
(507, 'fancybox_speedIn', '', 'yes'),
(508, 'fancybox_speedOut', '', 'yes'),
(509, 'fancybox_autoClick', '1', 'yes'),
(510, 'fancybox_delayClick', '1000', 'yes'),
(511, 'fancybox_minViewportWidth', '', 'yes'),
(512, 'fancybox_compatIE8', '', 'yes'),
(513, 'fancybox_metaData', '', 'yes'),
(514, 'fancybox_autoAttribute', '.jpg .jpeg .png .webp', 'yes'),
(515, 'fancybox_autoAttributeLimit', '', 'yes'),
(516, 'fancybox_classType', '', 'yes'),
(517, 'fancybox_transitionIn', 'elastic', 'yes'),
(518, 'fancybox_easingIn', 'easeOutBack', 'yes'),
(519, 'fancybox_transitionOut', 'elastic', 'yes'),
(520, 'fancybox_easingOut', 'easeInBack', 'yes'),
(521, 'fancybox_opacity', '', 'yes'),
(522, 'fancybox_hideOnContentClick', '', 'yes'),
(523, 'fancybox_titleShow', '1', 'yes'),
(524, 'fancybox_titlePosition', 'over', 'yes'),
(525, 'fancybox_titleFromAlt', '1', 'yes'),
(526, 'fancybox_autoGallery', '1', 'yes'),
(527, 'fancybox_showNavArrows', '1', 'yes'),
(528, 'fancybox_enableKeyboardNav', '1', 'yes'),
(529, 'fancybox_mouseWheel', '1', 'yes'),
(530, 'fancybox_cyclic', '', 'yes'),
(531, 'fancybox_changeSpeed', '', 'yes'),
(532, 'fancybox_changeFade', '', 'yes'),
(533, 'fancybox_autoSelector', 'div.gallery', 'yes'),
(538, 'responsive_lightbox_lite_version', '1.0.0', 'yes'),
(539, 'responsive_lightbox_lite_settings', 'a:8:{s:9:\"galleries\";b:0;s:6:\"videos\";b:1;s:11:\"image_links\";b:0;s:13:\"loading_place\";s:6:\"header\";s:19:\"deactivation_delete\";b:0;s:8:\"selector\";s:8:\"lightbox\";s:20:\"enable_custom_events\";b:0;s:17:\"images_as_gallery\";b:0;}', 'no'),
(924, 'duplicator_settings', 'a:10:{s:7:\"version\";s:6:\"1.2.34\";s:18:\"uninstall_settings\";b:1;s:15:\"uninstall_files\";b:1;s:16:\"uninstall_tables\";b:1;s:13:\"package_debug\";b:0;s:17:\"package_mysqldump\";b:1;s:22:\"package_mysqldump_path\";s:0:\"\";s:24:\"package_phpdump_qrylimit\";s:3:\"100\";s:17:\"package_zip_flush\";b:0;s:20:\"storage_htaccess_off\";b:0;}', 'yes'),
(925, 'duplicator_version_plugin', '1.2.34', 'yes');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(926, 'duplicator_package_active', 'O:11:\"DUP_Package\":23:{s:7:\"Created\";s:19:\"2018-04-13 19:44:12\";s:7:\"Version\";s:6:\"1.2.34\";s:9:\"VersionWP\";s:5:\"4.9.5\";s:9:\"VersionDB\";s:6:\"5.6.24\";s:10:\"VersionPHP\";s:6:\"5.5.24\";s:9:\"VersionOS\";s:6:\"Darwin\";s:2:\"ID\";N;s:4:\"Name\";s:27:\"20180413_morrisnathansonart\";s:4:\"Hash\";s:32:\"a11f1f9cea524f8f5261180413194412\";s:8:\"NameHash\";s:60:\"20180413_morrisnathansonart_a11f1f9cea524f8f5261180413194412\";s:4:\"Type\";i:0;s:5:\"Notes\";s:0:\"\";s:9:\"StorePath\";s:71:\"/Users/imac2/Documents/Websites/morrisnathanson.dev.cc/wp-snapshots/tmp\";s:8:\"StoreURL\";s:43:\"http://morrisnathanson.dev.cc/wp-snapshots/\";s:8:\"ScanFile\";s:70:\"20180413_morrisnathansonart_a11f1f9cea524f8f5261180413194412_scan.json\";s:7:\"Runtime\";N;s:7:\"ExeSize\";N;s:7:\"ZipSize\";N;s:6:\"Status\";N;s:6:\"WPUser\";N;s:7:\"Archive\";O:11:\"DUP_Archive\":19:{s:10:\"FilterDirs\";s:0:\"\";s:11:\"FilterFiles\";s:0:\"\";s:10:\"FilterExts\";s:0:\"\";s:13:\"FilterDirsAll\";a:0:{}s:14:\"FilterFilesAll\";a:0:{}s:13:\"FilterExtsAll\";a:0:{}s:8:\"FilterOn\";i:0;s:12:\"ExportOnlyDB\";i:0;s:4:\"File\";N;s:6:\"Format\";s:3:\"ZIP\";s:7:\"PackDir\";s:54:\"/Users/imac2/Documents/Websites/morrisnathanson.dev.cc\";s:4:\"Size\";i:0;s:4:\"Dirs\";a:0:{}s:5:\"Files\";a:0:{}s:10:\"FilterInfo\";O:23:\"DUP_Archive_Filter_Info\":8:{s:4:\"Dirs\";O:34:\"DUP_Archive_Filter_Scope_Directory\":4:{s:7:\"Warning\";a:0:{}s:10:\"Unreadable\";a:0:{}s:4:\"Core\";a:0:{}s:8:\"Instance\";a:0:{}}s:5:\"Files\";O:29:\"DUP_Archive_Filter_Scope_File\":5:{s:4:\"Size\";a:0:{}s:7:\"Warning\";a:0:{}s:10:\"Unreadable\";a:0:{}s:4:\"Core\";a:0:{}s:8:\"Instance\";a:0:{}}s:4:\"Exts\";O:29:\"DUP_Archive_Filter_Scope_Base\":2:{s:4:\"Core\";a:0:{}s:8:\"Instance\";a:0:{}}s:9:\"UDirCount\";i:0;s:10:\"UFileCount\";i:0;s:9:\"UExtCount\";i:0;s:8:\"TreeSize\";a:0:{}s:11:\"TreeWarning\";a:0:{}}s:14:\"RecursiveLinks\";a:0:{}s:10:\"\0*\0Package\";O:11:\"DUP_Package\":23:{s:7:\"Created\";s:19:\"2018-04-13 19:44:12\";s:7:\"Version\";s:6:\"1.2.34\";s:9:\"VersionWP\";s:5:\"4.9.5\";s:9:\"VersionDB\";s:6:\"5.6.24\";s:10:\"VersionPHP\";s:6:\"5.5.24\";s:9:\"VersionOS\";s:6:\"Darwin\";s:2:\"ID\";N;s:4:\"Name\";s:27:\"20180413_morrisnathansonart\";s:4:\"Hash\";s:32:\"a11f1f9cea524f8f5261180413194412\";s:8:\"NameHash\";s:60:\"20180413_morrisnathansonart_a11f1f9cea524f8f5261180413194412\";s:4:\"Type\";i:0;s:5:\"Notes\";s:0:\"\";s:9:\"StorePath\";s:71:\"/Users/imac2/Documents/Websites/morrisnathanson.dev.cc/wp-snapshots/tmp\";s:8:\"StoreURL\";s:43:\"http://morrisnathanson.dev.cc/wp-snapshots/\";s:8:\"ScanFile\";N;s:7:\"Runtime\";N;s:7:\"ExeSize\";N;s:7:\"ZipSize\";N;s:6:\"Status\";N;s:6:\"WPUser\";N;s:7:\"Archive\";r:22;s:9:\"Installer\";O:13:\"DUP_Installer\":7:{s:4:\"File\";N;s:4:\"Size\";i:0;s:10:\"OptsDBHost\";s:0:\"\";s:10:\"OptsDBPort\";s:0:\"\";s:10:\"OptsDBName\";s:0:\"\";s:10:\"OptsDBUser\";s:0:\"\";s:10:\"\0*\0Package\";r:58;}s:8:\"Database\";O:12:\"DUP_Database\":13:{s:4:\"Type\";s:5:\"MySQL\";s:4:\"Size\";N;s:4:\"File\";N;s:4:\"Path\";N;s:12:\"FilterTables\";s:0:\"\";s:8:\"FilterOn\";i:0;s:4:\"Name\";N;s:10:\"Compatible\";s:0:\"\";s:8:\"Comments\";s:19:\"Source distribution\";s:10:\"\0*\0Package\";r:58;s:25:\"\0DUP_Database\0dbStorePath\";N;s:23:\"\0DUP_Database\0EOFMarker\";s:0:\"\";s:26:\"\0DUP_Database\0networkFlush\";b:0;}}s:29:\"\0DUP_Archive\0tmpFilterDirsAll\";a:0:{}s:24:\"\0DUP_Archive\0wpCorePaths\";a:6:{i:0;s:63:\"/Users/imac2/Documents/Websites/morrisnathanson.dev.cc/wp-admin\";i:1;s:73:\"/Users/imac2/Documents/Websites/morrisnathanson.dev.cc/wp-content/uploads\";i:2;s:75:\"/Users/imac2/Documents/Websites/morrisnathanson.dev.cc/wp-content/languages\";i:3;s:73:\"/Users/imac2/Documents/Websites/morrisnathanson.dev.cc/wp-content/plugins\";i:4;s:72:\"/Users/imac2/Documents/Websites/morrisnathanson.dev.cc/wp-content/themes\";i:5;s:66:\"/Users/imac2/Documents/Websites/morrisnathanson.dev.cc/wp-includes\";}}s:9:\"Installer\";r:80;s:8:\"Database\";r:88;}', 'yes'),
(930, 'woocommerce_version', '3.3.5', 'yes'),
(931, 'woocommerce_db_version', '3.3.5', 'yes'),
(943, '_transient_timeout_jetpack_https_test_message', '1524238024', 'no'),
(944, '_transient_jetpack_https_test_message', '', 'no'),
(945, '_site_transient_timeout_browser_ebe1c806e77963130b79c43f8a872e28', '1524497164', 'no'),
(946, '_site_transient_browser_ebe1c806e77963130b79c43f8a872e28', 'a:10:{s:4:\"name\";s:7:\"Firefox\";s:7:\"version\";s:4:\"60.0\";s:8:\"platform\";s:9:\"Macintosh\";s:10:\"update_url\";s:24:\"https://www.firefox.com/\";s:7:\"img_src\";s:44:\"http://s.w.org/images/browsers/firefox.png?1\";s:11:\"img_src_ssl\";s:45:\"https://s.w.org/images/browsers/firefox.png?1\";s:15:\"current_version\";s:2:\"56\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}', 'no'),
(968, '_site_transient_timeout_browser_466fcf973f0a5f94eef55120bcc54efb', '1524502695', 'no'),
(969, '_site_transient_browser_466fcf973f0a5f94eef55120bcc54efb', 'a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:13:\"65.0.3325.181\";s:8:\"platform\";s:9:\"Macintosh\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}', 'no'),
(970, 'ms_hide_spring2018_ads_until', '7571293109', 'yes'),
(971, 'jetpack_dismissed_connection_banner', '1', 'yes'),
(985, '_transient_timeout_external_ip_address_127.0.0.1', '1524510718', 'no'),
(986, '_transient_external_ip_address_127.0.0.1', '108.34.207.158', 'no'),
(1042, 'gallerry-category_children', 'a:0:{}', 'yes'),
(1056, 'story-category_children', 'a:0:{}', 'yes'),
(1064, '_transient_timeout_external_ip_address_192.168.50.1', '1524606429', 'no'),
(1065, '_transient_external_ip_address_192.168.50.1', '75.133.181.170', 'no'),
(1067, 'jetpack_testimonial', '0', 'yes'),
(1080, '_transient_timeout_plugin_slugs', '1524249215', 'no'),
(1081, '_transient_plugin_slugs', 'a:12:{i:0;s:34:\"advanced-custom-fields-pro/acf.php\";i:1;s:39:\"column-shortcodes/column-shortcodes.php\";i:2;s:36:\"contact-form-7/wp-contact-form-7.php\";i:3;s:25:\"duplicator/duplicator.php\";i:4;s:41:\"fluid-video-embeds/fluid-video-embeds.php\";i:5;s:19:\"jetpack/jetpack.php\";i:6;s:23:\"ml-slider/ml-slider.php\";i:7;s:53:\"responsive-lightbox-lite/responsive-lightbox-lite.php\";i:8;s:29:\"slick-slider/slick-slider.php\";i:9;s:27:\"woocommerce/woocommerce.php\";i:10;s:91:\"woocommerce-gateway-paypal-express-checkout/woocommerce-gateway-paypal-express-checkout.php\";i:11;s:45:\"woocommerce-services/woocommerce-services.php\";}', 'no'),
(1082, 'wc_connect_options', 'a:2:{s:12:\"tos_accepted\";b:1;s:10:\"store_guid\";s:36:\"feeba6f8-2028-48a2-b7d8-379f1033c28f\";}', 'yes'),
(1083, 'wc_gateway_ppce_prompt_to_connect', 'PayPal Express Checkout is almost ready. To get started, <a href=\"http://morrisnathanson.dev.cc/wp-admin/admin.php?page=wc-settings&#038;tab=checkout&#038;section=ppec_paypal\">connect your PayPal account</a>.', 'yes'),
(1088, '_transient_wcc_is_new_label_user', 'yes', 'yes'),
(1089, '_transient_timeout_cpsh_plugin_admin_columns_info', '1524618009', 'no'),
(1090, '_transient_cpsh_plugin_admin_columns_info', 'O:8:\"stdClass\":17:{s:4:\"name\";s:13:\"Admin Columns\";s:4:\"slug\";s:23:\"codepress-admin-columns\";s:7:\"version\";s:5:\"3.1.5\";s:6:\"author\";s:59:\"<a href=\"https://www.admincolumns.com\">AdminColumns.com</a>\";s:14:\"author_profile\";s:40:\"https://profiles.wordpress.org/codepress\";s:6:\"tested\";s:5:\"4.9.5\";s:12:\"requires_php\";b:0;s:6:\"rating\";d:98;s:7:\"ratings\";a:5:{i:5;i:866;i:4;i:38;i:3;i:6;i:2;i:4;i:1;i:5;}s:11:\"num_ratings\";i:919;s:15:\"support_threads\";i:9;s:24:\"support_threads_resolved\";i:7;s:15:\"active_installs\";i:90000;s:13:\"download_link\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.3.1.5.zip\";s:11:\"screenshots\";a:9:{i:1;a:2:{s:3:\"src\";s:76:\"https://ps.w.org/codepress-admin-columns/assets/screenshot-1.gif?rev=1578102\";s:7:\"caption\";s:37:\"Settings page for Post(type) columns.\";}i:2;a:2:{s:3:\"src\";s:76:\"https://ps.w.org/codepress-admin-columns/assets/screenshot-2.png?rev=1578102\";s:7:\"caption\";s:50:\"Posts Screen with the customized sortable columns.\";}i:3;a:2:{s:3:\"src\";s:76:\"https://ps.w.org/codepress-admin-columns/assets/screenshot-3.png?rev=1578102\";s:7:\"caption\";s:44:\"Settings page for the Media Library columns.\";}i:4;a:2:{s:3:\"src\";s:76:\"https://ps.w.org/codepress-admin-columns/assets/screenshot-4.png?rev=1578102\";s:7:\"caption\";s:50:\"Media Screen with the customized sortable columns.\";}i:5;a:2:{s:3:\"src\";s:76:\"https://ps.w.org/codepress-admin-columns/assets/screenshot-5.png?rev=1578102\";s:7:\"caption\";s:32:\"Settings page for Users columns.\";}i:6;a:2:{s:3:\"src\";s:76:\"https://ps.w.org/codepress-admin-columns/assets/screenshot-6.png?rev=1578102\";s:7:\"caption\";s:50:\"Users Screen with the customized sortable columns.\";}i:7;a:2:{s:3:\"src\";s:76:\"https://ps.w.org/codepress-admin-columns/assets/screenshot-7.png?rev=1578102\";s:7:\"caption\";s:70:\"Settings page showing the different displaying types for custom field.\";}i:8;a:2:{s:3:\"src\";s:76:\"https://ps.w.org/codepress-admin-columns/assets/screenshot-8.png?rev=1578102\";s:7:\"caption\";s:32:\"Posts Screen with custom fields.\";}i:9;a:2:{s:3:\"src\";s:76:\"https://ps.w.org/codepress-admin-columns/assets/screenshot-9.png?rev=1578102\";s:7:\"caption\";s:0:\"\";}}s:8:\"versions\";a:85:{s:3:\"1.0\";s:70:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.1.0.zip\";s:3:\"1.1\";s:70:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.1.1.zip\";s:5:\"1.1.3\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.1.1.3.zip\";s:3:\"1.2\";s:70:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.1.2.zip\";s:5:\"1.2.1\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.1.2.1.zip\";s:3:\"1.3\";s:70:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.1.3.zip\";s:5:\"1.3.1\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.1.3.1.zip\";s:3:\"1.4\";s:70:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.1.4.zip\";s:5:\"1.4.1\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.1.4.1.zip\";s:5:\"1.4.2\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.1.4.2.zip\";s:5:\"1.4.3\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.1.4.3.zip\";s:5:\"1.4.4\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.1.4.4.zip\";s:5:\"1.4.5\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.1.4.5.zip\";s:7:\"1.4.5.1\";s:74:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.1.4.5.1.zip\";s:5:\"1.4.6\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.1.4.6.zip\";s:7:\"1.4.6.1\";s:74:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.1.4.6.1.zip\";s:7:\"1.4.6.2\";s:74:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.1.4.6.2.zip\";s:7:\"1.4.6.3\";s:74:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.1.4.6.3.zip\";s:7:\"1.4.6.4\";s:74:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.1.4.6.4.zip\";s:5:\"1.4.7\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.1.4.7.zip\";s:5:\"1.4.8\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.1.4.8.zip\";s:5:\"1.4.9\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.1.4.9.zip\";s:5:\"2.0.0\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.0.0.zip\";s:5:\"2.0.1\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.0.1.zip\";s:5:\"2.0.2\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.0.2.zip\";s:5:\"2.0.3\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.0.3.zip\";s:5:\"2.1.0\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.1.0.zip\";s:5:\"2.1.1\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.1.1.zip\";s:5:\"2.1.2\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.1.2.zip\";s:5:\"2.1.3\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.1.3.zip\";s:5:\"2.1.4\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.1.4.zip\";s:5:\"2.1.5\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.1.5.zip\";s:3:\"2.2\";s:70:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.2.zip\";s:5:\"2.2.1\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.2.1.zip\";s:7:\"2.2.1.1\";s:74:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.2.1.1.zip\";s:5:\"2.2.2\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.2.2.zip\";s:5:\"2.2.3\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.2.3.zip\";s:5:\"2.2.4\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.2.4.zip\";s:5:\"2.2.5\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.2.5.zip\";s:7:\"2.2.5.1\";s:74:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.2.5.1.zip\";s:5:\"2.2.6\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.2.6.zip\";s:7:\"2.2.6.1\";s:74:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.2.6.1.zip\";s:7:\"2.2.6.2\";s:74:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.2.6.2.zip\";s:7:\"2.2.6.3\";s:74:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.2.6.3.zip\";s:7:\"2.2.6.4\";s:74:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.2.6.4.zip\";s:5:\"2.2.7\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.2.7.zip\";s:5:\"2.2.8\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.2.8.zip\";s:7:\"2.2.8.1\";s:74:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.2.8.1.zip\";s:5:\"2.2.9\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.2.9.zip\";s:5:\"2.3.1\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.3.1.zip\";s:5:\"2.3.2\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.3.2.zip\";s:5:\"2.3.3\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.3.3.zip\";s:5:\"2.3.5\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.3.5.zip\";s:3:\"2.4\";s:70:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.4.zip\";s:5:\"2.4.1\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.4.1.zip\";s:6:\"2.4.10\";s:73:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.4.10.zip\";s:5:\"2.4.2\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.4.2.zip\";s:5:\"2.4.3\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.4.3.zip\";s:5:\"2.4.4\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.4.4.zip\";s:5:\"2.4.5\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.4.5.zip\";s:5:\"2.4.6\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.4.6.zip\";s:5:\"2.4.7\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.4.7.zip\";s:5:\"2.4.8\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.4.8.zip\";s:5:\"2.4.9\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.4.9.zip\";s:5:\"2.5.2\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.5.2.zip\";s:5:\"2.5.3\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.5.3.zip\";s:5:\"2.5.4\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.5.4.zip\";s:5:\"2.5.5\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.5.5.zip\";s:5:\"2.5.6\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.5.6.zip\";s:7:\"2.5.6.1\";s:74:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.5.6.1.zip\";s:7:\"2.5.6.2\";s:74:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.5.6.2.zip\";s:7:\"2.5.6.3\";s:74:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.5.6.3.zip\";s:7:\"2.5.6.4\";s:74:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.2.5.6.4.zip\";s:3:\"3.0\";s:70:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.3.0.zip\";s:5:\"3.0.1\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.3.0.1.zip\";s:5:\"3.0.2\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.3.0.2.zip\";s:5:\"3.0.3\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.3.0.3.zip\";s:5:\"3.0.5\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.3.0.5.zip\";s:5:\"3.0.7\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.3.0.7.zip\";s:3:\"3.1\";s:70:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.3.1.zip\";s:5:\"3.1.1\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.3.1.1.zip\";s:5:\"3.1.2\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.3.1.2.zip\";s:5:\"3.1.3\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.3.1.3.zip\";s:5:\"3.1.5\";s:72:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.3.1.5.zip\";s:5:\"trunk\";s:66:\"https://downloads.wordpress.org/plugin/codepress-admin-columns.zip\";}s:12:\"contributors\";a:0:{}}', 'no'),
(1093, 'wc_gateway_ppec_prompt_to_connect_message_dismissed', 'yes', 'yes'),
(1112, 'gallery-category_children', 'a:0:{}', 'yes'),
(1269, 'woocommerce_catalog_rows', '3', 'yes'),
(1282, 'woocommerce_gateway_order', 'a:5:{s:4:\"bacs\";i:0;s:6:\"cheque\";i:1;s:3:\"cod\";i:2;s:6:\"paypal\";i:3;s:11:\"ppec_paypal\";i:4;}', 'yes'),
(1286, '_transient_timeout_jetpack_https_test', '1524238024', 'no'),
(1287, '_transient_jetpack_https_test', '1', 'no'),
(1290, 'product_cat_children', 'a:0:{}', 'yes'),
(1307, '_transient_timeout_wc_related_238', '1524241687', 'no'),
(1308, '_transient_wc_related_238', 'a:1:{s:51:\"limit=3&exclude_ids%5B0%5D=0&exclude_ids%5B1%5D=238\";a:5:{i:0;s:2:\"39\";i:1;s:3:\"235\";i:2;s:3:\"236\";i:3;s:3:\"239\";i:4;s:3:\"240\";}}', 'no'),
(1321, '_transient_timeout_wc_related_39', '1524245470', 'no'),
(1322, '_transient_wc_related_39', 'a:1:{s:50:\"limit=3&exclude_ids%5B0%5D=0&exclude_ids%5B1%5D=39\";a:5:{i:0;s:3:\"235\";i:1;s:3:\"236\";i:2;s:3:\"238\";i:3;s:3:\"239\";i:4;s:3:\"240\";}}', 'no'),
(1323, '_transient_timeout_wc_term_counts', '1526751070', 'no'),
(1324, '_transient_wc_term_counts', 'a:2:{i:23;s:1:\"6\";i:15;s:1:\"3\";}', 'no'),
(1326, '_transient_timeout_wc_related_239', '1524247878', 'no'),
(1327, '_transient_wc_related_239', 'a:1:{s:51:\"limit=3&exclude_ids%5B0%5D=0&exclude_ids%5B1%5D=239\";a:5:{i:0;s:2:\"39\";i:1;s:3:\"235\";i:2;s:3:\"236\";i:3;s:3:\"238\";i:4;s:3:\"240\";}}', 'no'),
(1331, '_transient_timeout_wc_related_236', '1524248363', 'no'),
(1332, '_transient_wc_related_236', 'a:1:{s:51:\"limit=3&exclude_ids%5B0%5D=0&exclude_ids%5B1%5D=236\";a:5:{i:0;s:2:\"39\";i:1;s:3:\"235\";i:2;s:3:\"238\";i:3;s:3:\"239\";i:4;s:3:\"240\";}}', 'no'),
(1333, '_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a', '1524173584', 'no'),
(1334, '_site_transient_poptags_40cd750bba9870f18aada2478b24840a', 'O:8:\"stdClass\":100:{s:6:\"widget\";a:3:{s:4:\"name\";s:6:\"widget\";s:4:\"slug\";s:6:\"widget\";s:5:\"count\";i:4452;}s:11:\"woocommerce\";a:3:{s:4:\"name\";s:11:\"woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:5:\"count\";i:2735;}s:4:\"post\";a:3:{s:4:\"name\";s:4:\"post\";s:4:\"slug\";s:4:\"post\";s:5:\"count\";i:2553;}s:5:\"admin\";a:3:{s:4:\"name\";s:5:\"admin\";s:4:\"slug\";s:5:\"admin\";s:5:\"count\";i:2421;}s:5:\"posts\";a:3:{s:4:\"name\";s:5:\"posts\";s:4:\"slug\";s:5:\"posts\";s:5:\"count\";i:1868;}s:9:\"shortcode\";a:3:{s:4:\"name\";s:9:\"shortcode\";s:4:\"slug\";s:9:\"shortcode\";s:5:\"count\";i:1645;}s:8:\"comments\";a:3:{s:4:\"name\";s:8:\"comments\";s:4:\"slug\";s:8:\"comments\";s:5:\"count\";i:1637;}s:7:\"twitter\";a:3:{s:4:\"name\";s:7:\"twitter\";s:4:\"slug\";s:7:\"twitter\";s:5:\"count\";i:1452;}s:6:\"images\";a:3:{s:4:\"name\";s:6:\"images\";s:4:\"slug\";s:6:\"images\";s:5:\"count\";i:1387;}s:6:\"google\";a:3:{s:4:\"name\";s:6:\"google\";s:4:\"slug\";s:6:\"google\";s:5:\"count\";i:1386;}s:8:\"facebook\";a:3:{s:4:\"name\";s:8:\"facebook\";s:4:\"slug\";s:8:\"facebook\";s:5:\"count\";i:1383;}s:5:\"image\";a:3:{s:4:\"name\";s:5:\"image\";s:4:\"slug\";s:5:\"image\";s:5:\"count\";i:1310;}s:7:\"sidebar\";a:3:{s:4:\"name\";s:7:\"sidebar\";s:4:\"slug\";s:7:\"sidebar\";s:5:\"count\";i:1282;}s:3:\"seo\";a:3:{s:4:\"name\";s:3:\"seo\";s:4:\"slug\";s:3:\"seo\";s:5:\"count\";i:1198;}s:7:\"gallery\";a:3:{s:4:\"name\";s:7:\"gallery\";s:4:\"slug\";s:7:\"gallery\";s:5:\"count\";i:1097;}s:4:\"page\";a:3:{s:4:\"name\";s:4:\"page\";s:4:\"slug\";s:4:\"page\";s:5:\"count\";i:1058;}s:6:\"social\";a:3:{s:4:\"name\";s:6:\"social\";s:4:\"slug\";s:6:\"social\";s:5:\"count\";i:1021;}s:5:\"email\";a:3:{s:4:\"name\";s:5:\"email\";s:4:\"slug\";s:5:\"email\";s:5:\"count\";i:1005;}s:9:\"ecommerce\";a:3:{s:4:\"name\";s:9:\"ecommerce\";s:4:\"slug\";s:9:\"ecommerce\";s:5:\"count\";i:882;}s:5:\"login\";a:3:{s:4:\"name\";s:5:\"login\";s:4:\"slug\";s:5:\"login\";s:5:\"count\";i:874;}s:5:\"links\";a:3:{s:4:\"name\";s:5:\"links\";s:4:\"slug\";s:5:\"links\";s:5:\"count\";i:825;}s:7:\"widgets\";a:3:{s:4:\"name\";s:7:\"widgets\";s:4:\"slug\";s:7:\"widgets\";s:5:\"count\";i:800;}s:5:\"video\";a:3:{s:4:\"name\";s:5:\"video\";s:4:\"slug\";s:5:\"video\";s:5:\"count\";i:799;}s:8:\"security\";a:3:{s:4:\"name\";s:8:\"security\";s:4:\"slug\";s:8:\"security\";s:5:\"count\";i:704;}s:7:\"content\";a:3:{s:4:\"name\";s:7:\"content\";s:4:\"slug\";s:7:\"content\";s:5:\"count\";i:690;}s:3:\"rss\";a:3:{s:4:\"name\";s:3:\"rss\";s:4:\"slug\";s:3:\"rss\";s:5:\"count\";i:683;}s:10:\"buddypress\";a:3:{s:4:\"name\";s:10:\"buddypress\";s:4:\"slug\";s:10:\"buddypress\";s:5:\"count\";i:679;}s:4:\"spam\";a:3:{s:4:\"name\";s:4:\"spam\";s:4:\"slug\";s:4:\"spam\";s:5:\"count\";i:672;}s:6:\"slider\";a:3:{s:4:\"name\";s:6:\"slider\";s:4:\"slug\";s:6:\"slider\";s:5:\"count\";i:654;}s:5:\"pages\";a:3:{s:4:\"name\";s:5:\"pages\";s:4:\"slug\";s:5:\"pages\";s:5:\"count\";i:654;}s:9:\"analytics\";a:3:{s:4:\"name\";s:9:\"analytics\";s:4:\"slug\";s:9:\"analytics\";s:5:\"count\";i:642;}s:6:\"jquery\";a:3:{s:4:\"name\";s:6:\"jquery\";s:4:\"slug\";s:6:\"jquery\";s:5:\"count\";i:639;}s:5:\"media\";a:3:{s:4:\"name\";s:5:\"media\";s:4:\"slug\";s:5:\"media\";s:5:\"count\";i:633;}s:10:\"e-commerce\";a:3:{s:4:\"name\";s:10:\"e-commerce\";s:4:\"slug\";s:10:\"e-commerce\";s:5:\"count\";i:621;}s:4:\"feed\";a:3:{s:4:\"name\";s:4:\"feed\";s:4:\"slug\";s:4:\"feed\";s:5:\"count\";i:610;}s:6:\"search\";a:3:{s:4:\"name\";s:6:\"search\";s:4:\"slug\";s:6:\"search\";s:5:\"count\";i:603;}s:4:\"ajax\";a:3:{s:4:\"name\";s:4:\"ajax\";s:4:\"slug\";s:4:\"ajax\";s:5:\"count\";i:601;}s:4:\"form\";a:3:{s:4:\"name\";s:4:\"form\";s:4:\"slug\";s:4:\"form\";s:5:\"count\";i:593;}s:8:\"category\";a:3:{s:4:\"name\";s:8:\"category\";s:4:\"slug\";s:8:\"category\";s:5:\"count\";i:588;}s:4:\"menu\";a:3:{s:4:\"name\";s:4:\"menu\";s:4:\"slug\";s:4:\"menu\";s:5:\"count\";i:584;}s:5:\"embed\";a:3:{s:4:\"name\";s:5:\"embed\";s:4:\"slug\";s:5:\"embed\";s:5:\"count\";i:562;}s:10:\"javascript\";a:3:{s:4:\"name\";s:10:\"javascript\";s:4:\"slug\";s:10:\"javascript\";s:5:\"count\";i:545;}s:4:\"link\";a:3:{s:4:\"name\";s:4:\"link\";s:4:\"slug\";s:4:\"link\";s:5:\"count\";i:535;}s:3:\"css\";a:3:{s:4:\"name\";s:3:\"css\";s:4:\"slug\";s:3:\"css\";s:5:\"count\";i:531;}s:7:\"youtube\";a:3:{s:4:\"name\";s:7:\"youtube\";s:4:\"slug\";s:7:\"youtube\";s:5:\"count\";i:520;}s:5:\"share\";a:3:{s:4:\"name\";s:5:\"share\";s:4:\"slug\";s:5:\"share\";s:5:\"count\";i:520;}s:7:\"comment\";a:3:{s:4:\"name\";s:7:\"comment\";s:4:\"slug\";s:7:\"comment\";s:5:\"count\";i:511;}s:5:\"theme\";a:3:{s:4:\"name\";s:5:\"theme\";s:4:\"slug\";s:5:\"theme\";s:5:\"count\";i:504;}s:9:\"dashboard\";a:3:{s:4:\"name\";s:9:\"dashboard\";s:4:\"slug\";s:9:\"dashboard\";s:5:\"count\";i:491;}s:6:\"editor\";a:3:{s:4:\"name\";s:6:\"editor\";s:4:\"slug\";s:6:\"editor\";s:5:\"count\";i:490;}s:10:\"responsive\";a:3:{s:4:\"name\";s:10:\"responsive\";s:4:\"slug\";s:10:\"responsive\";s:5:\"count\";i:489;}s:6:\"custom\";a:3:{s:4:\"name\";s:6:\"custom\";s:4:\"slug\";s:6:\"custom\";s:5:\"count\";i:483;}s:10:\"categories\";a:3:{s:4:\"name\";s:10:\"categories\";s:4:\"slug\";s:10:\"categories\";s:5:\"count\";i:479;}s:12:\"contact-form\";a:3:{s:4:\"name\";s:12:\"contact form\";s:4:\"slug\";s:12:\"contact-form\";s:5:\"count\";i:477;}s:3:\"ads\";a:3:{s:4:\"name\";s:3:\"ads\";s:4:\"slug\";s:3:\"ads\";s:5:\"count\";i:469;}s:9:\"affiliate\";a:3:{s:4:\"name\";s:9:\"affiliate\";s:4:\"slug\";s:9:\"affiliate\";s:5:\"count\";i:465;}s:6:\"button\";a:3:{s:4:\"name\";s:6:\"button\";s:4:\"slug\";s:6:\"button\";s:5:\"count\";i:455;}s:4:\"tags\";a:3:{s:4:\"name\";s:4:\"tags\";s:4:\"slug\";s:4:\"tags\";s:5:\"count\";i:454;}s:4:\"user\";a:3:{s:4:\"name\";s:4:\"user\";s:4:\"slug\";s:4:\"user\";s:5:\"count\";i:437;}s:7:\"contact\";a:3:{s:4:\"name\";s:7:\"contact\";s:4:\"slug\";s:7:\"contact\";s:5:\"count\";i:432;}s:6:\"mobile\";a:3:{s:4:\"name\";s:6:\"mobile\";s:4:\"slug\";s:6:\"mobile\";s:5:\"count\";i:425;}s:3:\"api\";a:3:{s:4:\"name\";s:3:\"api\";s:4:\"slug\";s:3:\"api\";s:5:\"count\";i:423;}s:5:\"photo\";a:3:{s:4:\"name\";s:5:\"photo\";s:4:\"slug\";s:5:\"photo\";s:5:\"count\";i:419;}s:5:\"users\";a:3:{s:4:\"name\";s:5:\"users\";s:4:\"slug\";s:5:\"users\";s:5:\"count\";i:415;}s:9:\"slideshow\";a:3:{s:4:\"name\";s:9:\"slideshow\";s:4:\"slug\";s:9:\"slideshow\";s:5:\"count\";i:413;}s:5:\"stats\";a:3:{s:4:\"name\";s:5:\"stats\";s:4:\"slug\";s:5:\"stats\";s:5:\"count\";i:412;}s:6:\"events\";a:3:{s:4:\"name\";s:6:\"events\";s:4:\"slug\";s:6:\"events\";s:5:\"count\";i:405;}s:6:\"photos\";a:3:{s:4:\"name\";s:6:\"photos\";s:4:\"slug\";s:6:\"photos\";s:5:\"count\";i:404;}s:10:\"statistics\";a:3:{s:4:\"name\";s:10:\"statistics\";s:4:\"slug\";s:10:\"statistics\";s:5:\"count\";i:390;}s:7:\"payment\";a:3:{s:4:\"name\";s:7:\"payment\";s:4:\"slug\";s:7:\"payment\";s:5:\"count\";i:388;}s:10:\"navigation\";a:3:{s:4:\"name\";s:10:\"navigation\";s:4:\"slug\";s:10:\"navigation\";s:5:\"count\";i:385;}s:4:\"news\";a:3:{s:4:\"name\";s:4:\"news\";s:4:\"slug\";s:4:\"news\";s:5:\"count\";i:363;}s:8:\"calendar\";a:3:{s:4:\"name\";s:8:\"calendar\";s:4:\"slug\";s:8:\"calendar\";s:5:\"count\";i:362;}s:10:\"shortcodes\";a:3:{s:4:\"name\";s:10:\"shortcodes\";s:4:\"slug\";s:10:\"shortcodes\";s:5:\"count\";i:355;}s:5:\"popup\";a:3:{s:4:\"name\";s:5:\"popup\";s:4:\"slug\";s:5:\"popup\";s:5:\"count\";i:355;}s:9:\"marketing\";a:3:{s:4:\"name\";s:9:\"marketing\";s:4:\"slug\";s:9:\"marketing\";s:5:\"count\";i:347;}s:12:\"social-media\";a:3:{s:4:\"name\";s:12:\"social media\";s:4:\"slug\";s:12:\"social-media\";s:5:\"count\";i:345;}s:4:\"chat\";a:3:{s:4:\"name\";s:4:\"chat\";s:4:\"slug\";s:4:\"chat\";s:5:\"count\";i:343;}s:7:\"plugins\";a:3:{s:4:\"name\";s:7:\"plugins\";s:4:\"slug\";s:7:\"plugins\";s:5:\"count\";i:343;}s:15:\"payment-gateway\";a:3:{s:4:\"name\";s:15:\"payment gateway\";s:4:\"slug\";s:15:\"payment-gateway\";s:5:\"count\";i:339;}s:9:\"multisite\";a:3:{s:4:\"name\";s:9:\"multisite\";s:4:\"slug\";s:9:\"multisite\";s:5:\"count\";i:338;}s:10:\"newsletter\";a:3:{s:4:\"name\";s:10:\"newsletter\";s:4:\"slug\";s:10:\"newsletter\";s:5:\"count\";i:338;}s:4:\"code\";a:3:{s:4:\"name\";s:4:\"code\";s:4:\"slug\";s:4:\"code\";s:5:\"count\";i:337;}s:4:\"list\";a:3:{s:4:\"name\";s:4:\"list\";s:4:\"slug\";s:4:\"list\";s:5:\"count\";i:333;}s:3:\"url\";a:3:{s:4:\"name\";s:3:\"url\";s:4:\"slug\";s:3:\"url\";s:5:\"count\";i:330;}s:4:\"meta\";a:3:{s:4:\"name\";s:4:\"meta\";s:4:\"slug\";s:4:\"meta\";s:5:\"count\";i:329;}s:8:\"redirect\";a:3:{s:4:\"name\";s:8:\"redirect\";s:4:\"slug\";s:8:\"redirect\";s:5:\"count\";i:320;}s:5:\"forms\";a:3:{s:4:\"name\";s:5:\"forms\";s:4:\"slug\";s:5:\"forms\";s:5:\"count\";i:312;}s:6:\"simple\";a:3:{s:4:\"name\";s:6:\"simple\";s:4:\"slug\";s:6:\"simple\";s:5:\"count\";i:304;}s:16:\"custom-post-type\";a:3:{s:4:\"name\";s:16:\"custom post type\";s:4:\"slug\";s:16:\"custom-post-type\";s:5:\"count\";i:303;}s:11:\"advertising\";a:3:{s:4:\"name\";s:11:\"advertising\";s:4:\"slug\";s:11:\"advertising\";s:5:\"count\";i:303;}s:3:\"tag\";a:3:{s:4:\"name\";s:3:\"tag\";s:4:\"slug\";s:3:\"tag\";s:5:\"count\";i:300;}s:7:\"adsense\";a:3:{s:4:\"name\";s:7:\"adsense\";s:4:\"slug\";s:7:\"adsense\";s:5:\"count\";i:296;}s:4:\"html\";a:3:{s:4:\"name\";s:4:\"html\";s:4:\"slug\";s:4:\"html\";s:5:\"count\";i:294;}s:8:\"tracking\";a:3:{s:4:\"name\";s:8:\"tracking\";s:4:\"slug\";s:8:\"tracking\";s:5:\"count\";i:292;}s:12:\"notification\";a:3:{s:4:\"name\";s:12:\"notification\";s:4:\"slug\";s:12:\"notification\";s:5:\"count\";i:292;}s:6:\"author\";a:3:{s:4:\"name\";s:6:\"author\";s:4:\"slug\";s:6:\"author\";s:5:\"count\";i:289;}s:16:\"google-analytics\";a:3:{s:4:\"name\";s:16:\"google analytics\";s:4:\"slug\";s:16:\"google-analytics\";s:5:\"count\";i:289;}s:11:\"performance\";a:3:{s:4:\"name\";s:11:\"performance\";s:4:\"slug\";s:11:\"performance\";s:5:\"count\";i:289;}s:8:\"lightbox\";a:3:{s:4:\"name\";s:8:\"lightbox\";s:4:\"slug\";s:8:\"lightbox\";s:5:\"count\";i:284;}}', 'no'),
(1339, '_transient_timeout__woocommerce_helper_updates', '1524206001', 'no'),
(1340, '_transient__woocommerce_helper_updates', 'a:4:{s:4:\"hash\";s:32:\"d751713988987e9331980363e24189ce\";s:7:\"updated\";i:1524162801;s:8:\"products\";a:0:{}s:6:\"errors\";a:1:{i:0;s:10:\"http-error\";}}', 'no'),
(1342, '_site_transient_update_plugins', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1524172483;s:7:\"checked\";a:12:{s:34:\"advanced-custom-fields-pro/acf.php\";s:6:\"5.6.10\";s:39:\"column-shortcodes/column-shortcodes.php\";s:3:\"1.0\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:5:\"5.0.1\";s:25:\"duplicator/duplicator.php\";s:6:\"1.2.34\";s:41:\"fluid-video-embeds/fluid-video-embeds.php\";s:5:\"1.2.9\";s:19:\"jetpack/jetpack.php\";s:3:\"6.0\";s:23:\"ml-slider/ml-slider.php\";s:5:\"3.7.2\";s:53:\"responsive-lightbox-lite/responsive-lightbox-lite.php\";s:5:\"1.3.2\";s:29:\"slick-slider/slick-slider.php\";s:5:\"0.5.1\";s:27:\"woocommerce/woocommerce.php\";s:5:\"3.3.5\";s:91:\"woocommerce-gateway-paypal-express-checkout/woocommerce-gateway-paypal-express-checkout.php\";s:5:\"1.5.3\";s:45:\"woocommerce-services/woocommerce-services.php\";s:6:\"1.12.3\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:11:{s:39:\"column-shortcodes/column-shortcodes.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:31:\"w.org/plugins/column-shortcodes\";s:4:\"slug\";s:17:\"column-shortcodes\";s:6:\"plugin\";s:39:\"column-shortcodes/column-shortcodes.php\";s:11:\"new_version\";s:3:\"1.0\";s:3:\"url\";s:48:\"https://wordpress.org/plugins/column-shortcodes/\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/plugin/column-shortcodes.1.0.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:70:\"https://ps.w.org/column-shortcodes/assets/icon-256x256.png?rev=1679769\";s:2:\"1x\";s:70:\"https://ps.w.org/column-shortcodes/assets/icon-128x128.png?rev=1679769\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:71:\"https://ps.w.org/column-shortcodes/assets/banner-772x250.png?rev=580886\";}s:11:\"banners_rtl\";a:0:{}}s:36:\"contact-form-7/wp-contact-form-7.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:28:\"w.org/plugins/contact-form-7\";s:4:\"slug\";s:14:\"contact-form-7\";s:6:\"plugin\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:11:\"new_version\";s:5:\"5.0.1\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/contact-form-7/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/contact-form-7.5.0.1.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:66:\"https://ps.w.org/contact-form-7/assets/icon-256x256.png?rev=984007\";s:2:\"1x\";s:66:\"https://ps.w.org/contact-form-7/assets/icon-128x128.png?rev=984007\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/contact-form-7/assets/banner-1544x500.png?rev=860901\";s:2:\"1x\";s:68:\"https://ps.w.org/contact-form-7/assets/banner-772x250.png?rev=880427\";}s:11:\"banners_rtl\";a:0:{}}s:25:\"duplicator/duplicator.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:24:\"w.org/plugins/duplicator\";s:4:\"slug\";s:10:\"duplicator\";s:6:\"plugin\";s:25:\"duplicator/duplicator.php\";s:11:\"new_version\";s:6:\"1.2.34\";s:3:\"url\";s:41:\"https://wordpress.org/plugins/duplicator/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/duplicator.1.2.34.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:63:\"https://ps.w.org/duplicator/assets/icon-256x256.png?rev=1298463\";s:2:\"1x\";s:63:\"https://ps.w.org/duplicator/assets/icon-128x128.png?rev=1298463\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:65:\"https://ps.w.org/duplicator/assets/banner-772x250.png?rev=1645055\";}s:11:\"banners_rtl\";a:0:{}}s:41:\"fluid-video-embeds/fluid-video-embeds.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:32:\"w.org/plugins/fluid-video-embeds\";s:4:\"slug\";s:18:\"fluid-video-embeds\";s:6:\"plugin\";s:41:\"fluid-video-embeds/fluid-video-embeds.php\";s:11:\"new_version\";s:5:\"1.2.9\";s:3:\"url\";s:49:\"https://wordpress.org/plugins/fluid-video-embeds/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/fluid-video-embeds.zip\";s:5:\"icons\";a:1:{s:7:\"default\";s:69:\"https://s.w.org/plugins/geopattern-icon/fluid-video-embeds_746591.svg\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:72:\"https://ps.w.org/fluid-video-embeds/assets/banner-772x250.jpg?rev=596591\";}s:11:\"banners_rtl\";a:0:{}}s:19:\"jetpack/jetpack.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:21:\"w.org/plugins/jetpack\";s:4:\"slug\";s:7:\"jetpack\";s:6:\"plugin\";s:19:\"jetpack/jetpack.php\";s:11:\"new_version\";s:3:\"6.0\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/jetpack/\";s:7:\"package\";s:54:\"https://downloads.wordpress.org/plugin/jetpack.6.0.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:60:\"https://ps.w.org/jetpack/assets/icon-256x256.png?rev=1791404\";s:2:\"1x\";s:52:\"https://ps.w.org/jetpack/assets/icon.svg?rev=1791404\";s:3:\"svg\";s:52:\"https://ps.w.org/jetpack/assets/icon.svg?rev=1791404\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:63:\"https://ps.w.org/jetpack/assets/banner-1544x500.png?rev=1791404\";s:2:\"1x\";s:62:\"https://ps.w.org/jetpack/assets/banner-772x250.png?rev=1791404\";}s:11:\"banners_rtl\";a:0:{}}s:23:\"ml-slider/ml-slider.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:23:\"w.org/plugins/ml-slider\";s:4:\"slug\";s:9:\"ml-slider\";s:6:\"plugin\";s:23:\"ml-slider/ml-slider.php\";s:11:\"new_version\";s:5:\"3.7.2\";s:3:\"url\";s:40:\"https://wordpress.org/plugins/ml-slider/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/plugin/ml-slider.3.7.2.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:62:\"https://ps.w.org/ml-slider/assets/icon-256x256.png?rev=1837669\";s:2:\"1x\";s:54:\"https://ps.w.org/ml-slider/assets/icon.svg?rev=1837669\";s:3:\"svg\";s:54:\"https://ps.w.org/ml-slider/assets/icon.svg?rev=1837669\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:65:\"https://ps.w.org/ml-slider/assets/banner-1544x500.png?rev=1837669\";s:2:\"1x\";s:64:\"https://ps.w.org/ml-slider/assets/banner-772x250.png?rev=1837669\";}s:11:\"banners_rtl\";a:0:{}}s:53:\"responsive-lightbox-lite/responsive-lightbox-lite.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:38:\"w.org/plugins/responsive-lightbox-lite\";s:4:\"slug\";s:24:\"responsive-lightbox-lite\";s:6:\"plugin\";s:53:\"responsive-lightbox-lite/responsive-lightbox-lite.php\";s:11:\"new_version\";s:5:\"1.3.2\";s:3:\"url\";s:55:\"https://wordpress.org/plugins/responsive-lightbox-lite/\";s:7:\"package\";s:73:\"https://downloads.wordpress.org/plugin/responsive-lightbox-lite.1.3.2.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:76:\"https://ps.w.org/responsive-lightbox-lite/assets/icon-128x128.png?rev=983411\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:78:\"https://ps.w.org/responsive-lightbox-lite/assets/banner-772x250.jpg?rev=948858\";}s:11:\"banners_rtl\";a:0:{}}s:29:\"slick-slider/slick-slider.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:26:\"w.org/plugins/slick-slider\";s:4:\"slug\";s:12:\"slick-slider\";s:6:\"plugin\";s:29:\"slick-slider/slick-slider.php\";s:11:\"new_version\";s:5:\"0.5.1\";s:3:\"url\";s:43:\"https://wordpress.org/plugins/slick-slider/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/slick-slider.0.5.1.zip\";s:5:\"icons\";a:2:{s:2:\"1x\";s:57:\"https://ps.w.org/slick-slider/assets/icon.svg?rev=1520493\";s:3:\"svg\";s:57:\"https://ps.w.org/slick-slider/assets/icon.svg?rev=1520493\";}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}}s:27:\"woocommerce/woocommerce.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:25:\"w.org/plugins/woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:6:\"plugin\";s:27:\"woocommerce/woocommerce.php\";s:11:\"new_version\";s:5:\"3.3.5\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/woocommerce/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/woocommerce.3.3.5.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/woocommerce/assets/icon-256x256.png?rev=1440831\";s:2:\"1x\";s:64:\"https://ps.w.org/woocommerce/assets/icon-128x128.png?rev=1440831\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/woocommerce/assets/banner-1544x500.png?rev=1629184\";s:2:\"1x\";s:66:\"https://ps.w.org/woocommerce/assets/banner-772x250.png?rev=1629184\";}s:11:\"banners_rtl\";a:0:{}}s:91:\"woocommerce-gateway-paypal-express-checkout/woocommerce-gateway-paypal-express-checkout.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:57:\"w.org/plugins/woocommerce-gateway-paypal-express-checkout\";s:4:\"slug\";s:43:\"woocommerce-gateway-paypal-express-checkout\";s:6:\"plugin\";s:91:\"woocommerce-gateway-paypal-express-checkout/woocommerce-gateway-paypal-express-checkout.php\";s:11:\"new_version\";s:5:\"1.5.3\";s:3:\"url\";s:74:\"https://wordpress.org/plugins/woocommerce-gateway-paypal-express-checkout/\";s:7:\"package\";s:92:\"https://downloads.wordpress.org/plugin/woocommerce-gateway-paypal-express-checkout.1.5.3.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:96:\"https://ps.w.org/woocommerce-gateway-paypal-express-checkout/assets/icon-256x256.png?rev=1410389\";s:2:\"1x\";s:96:\"https://ps.w.org/woocommerce-gateway-paypal-express-checkout/assets/icon-128x128.png?rev=1410389\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:99:\"https://ps.w.org/woocommerce-gateway-paypal-express-checkout/assets/banner-1544x500.png?rev=1410389\";s:2:\"1x\";s:98:\"https://ps.w.org/woocommerce-gateway-paypal-express-checkout/assets/banner-772x250.png?rev=1410389\";}s:11:\"banners_rtl\";a:0:{}}s:45:\"woocommerce-services/woocommerce-services.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:34:\"w.org/plugins/woocommerce-services\";s:4:\"slug\";s:20:\"woocommerce-services\";s:6:\"plugin\";s:45:\"woocommerce-services/woocommerce-services.php\";s:11:\"new_version\";s:6:\"1.12.3\";s:3:\"url\";s:51:\"https://wordpress.org/plugins/woocommerce-services/\";s:7:\"package\";s:70:\"https://downloads.wordpress.org/plugin/woocommerce-services.1.12.3.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:73:\"https://ps.w.org/woocommerce-services/assets/icon-256x256.png?rev=1586175\";s:2:\"1x\";s:73:\"https://ps.w.org/woocommerce-services/assets/icon-128x128.png?rev=1586175\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:76:\"https://ps.w.org/woocommerce-services/assets/banner-1544x500.png?rev=1598183\";s:2:\"1x\";s:75:\"https://ps.w.org/woocommerce-services/assets/banner-772x250.png?rev=1598183\";}s:11:\"banners_rtl\";a:0:{}}}}', 'no'),
(1344, '_transient_timeout_fveb4474ae32000207cd5a247f40b4596b1', '1524335745', 'no');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1345, '_transient_fveb4474ae32000207cd5a247f40b4596b1', 'a:6:{s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:28:{s:6:\"server\";s:5:\"nginx\";s:12:\"content-type\";s:16:\"application/json\";s:27:\"access-control-allow-origin\";s:1:\"*\";s:22:\"x-content-type-options\";s:7:\"nosniff\";s:15:\"x-frame-options\";s:10:\"sameorigin\";s:17:\"x-ratelimit-limit\";s:4:\"3600\";s:21:\"x-ratelimit-remaining\";s:4:\"3599\";s:17:\"x-ratelimit-reset\";s:10:\"1524166545\";s:19:\"content-disposition\";s:31:\"attachment; filename=vimeo.json\";s:13:\"cache-control\";s:10:\"max-age=60\";s:7:\"expires\";s:29:\"Thu, 19 Apr 2018 18:36:45 GMT\";s:13:\"last-modified\";s:29:\"Thu, 19 Apr 2018 15:51:28 GMT\";s:4:\"etag\";s:34:\"\"26f3b1b96b184c605116550f43f265ab\"\";s:15:\"x-ua-compatible\";s:7:\"IE=edge\";s:16:\"x-xss-protection\";s:13:\"1; mode=block\";s:25:\"strict-transport-security\";s:44:\"max-age=15552000; includeSubDomains; preload\";s:35:\"content-security-policy-report-only\";s:83:\"default-src https: data: blob: wss: \'unsafe-inline\' \'unsafe-eval\'; report-uri /_csp\";s:16:\"content-encoding\";s:4:\"gzip\";s:3:\"via\";a:2:{i:0;s:11:\"1.1 varnish\";i:1;s:11:\"1.1 varnish\";}s:14:\"content-length\";s:3:\"770\";s:13:\"accept-ranges\";s:5:\"bytes\";s:4:\"date\";s:29:\"Thu, 19 Apr 2018 18:35:45 GMT\";s:3:\"age\";s:1:\"0\";s:11:\"x-served-by\";s:37:\"cache-iad2143-IAD, cache-ewr18121-EWR\";s:7:\"x-cache\";s:10:\"MISS, MISS\";s:12:\"x-cache-hits\";s:4:\"0, 0\";s:7:\"x-timer\";s:27:\"S1524162946.919227,VS0,VE36\";s:4:\"vary\";s:26:\"User-Agent,Accept-Encoding\";}}s:4:\"body\";s:1583:\"[{\"id\":78535116,\"title\":\"MORRIS NATHANSON\",\"description\":\"Morris Nathanson founded the firm Morris Nathanson Design in 1967, and for over 40 years, he has developed a legacy in the Interior Design field, as a businessman and as an entrepreneur.  Nathanson\'s art has evolved not from any one style, but many, and more from a personal reaction to family events and community. His method of expression is varied in painting, print making and wood assemblage.  Nathanson is a civic leader in the community and volunteers with several non-profit and municipal organizations. He was the 2005 recipient of The Pawtucket Foundation Heritage Award that recognizes a long term commitment to the City of Pawtucket and its residents.\",\"url\":\"https:\\/\\/vimeo.com\\/78535116\",\"upload_date\":\"2013-11-04 09:43:30\",\"thumbnail_small\":\"https:\\/\\/i.vimeocdn.com\\/video\\/453943764_100x75.jpg\",\"thumbnail_medium\":\"https:\\/\\/i.vimeocdn.com\\/video\\/453943764_200x150.jpg\",\"thumbnail_large\":\"https:\\/\\/i.vimeocdn.com\\/video\\/453943764_640.jpg\",\"user_id\":9531360,\"user_name\":\"NetWorks Rhode Island\",\"user_url\":\"https:\\/\\/vimeo.com\\/networksri\",\"user_portrait_small\":\"https:\\/\\/i.vimeocdn.com\\/portrait\\/17602548_30x30\",\"user_portrait_medium\":\"https:\\/\\/i.vimeocdn.com\\/portrait\\/17602548_75x75\",\"user_portrait_large\":\"https:\\/\\/i.vimeocdn.com\\/portrait\\/17602548_100x100\",\"user_portrait_huge\":\"https:\\/\\/i.vimeocdn.com\\/portrait\\/17602548_300x300\",\"stats_number_of_likes\":1,\"stats_number_of_plays\":168,\"stats_number_of_comments\":0,\"duration\":512,\"width\":1280,\"height\":720,\"tags\":\"\",\"embed_privacy\":\"anywhere\"}]\";s:8:\"response\";a:2:{s:4:\"code\";i:200;s:7:\"message\";s:2:\"OK\";}s:7:\"cookies\";a:0:{}s:8:\"filename\";N;s:13:\"http_response\";O:25:\"WP_HTTP_Requests_Response\":5:{s:11:\"\0*\0response\";O:17:\"Requests_Response\":10:{s:4:\"body\";s:1583:\"[{\"id\":78535116,\"title\":\"MORRIS NATHANSON\",\"description\":\"Morris Nathanson founded the firm Morris Nathanson Design in 1967, and for over 40 years, he has developed a legacy in the Interior Design field, as a businessman and as an entrepreneur.  Nathanson\'s art has evolved not from any one style, but many, and more from a personal reaction to family events and community. His method of expression is varied in painting, print making and wood assemblage.  Nathanson is a civic leader in the community and volunteers with several non-profit and municipal organizations. He was the 2005 recipient of The Pawtucket Foundation Heritage Award that recognizes a long term commitment to the City of Pawtucket and its residents.\",\"url\":\"https:\\/\\/vimeo.com\\/78535116\",\"upload_date\":\"2013-11-04 09:43:30\",\"thumbnail_small\":\"https:\\/\\/i.vimeocdn.com\\/video\\/453943764_100x75.jpg\",\"thumbnail_medium\":\"https:\\/\\/i.vimeocdn.com\\/video\\/453943764_200x150.jpg\",\"thumbnail_large\":\"https:\\/\\/i.vimeocdn.com\\/video\\/453943764_640.jpg\",\"user_id\":9531360,\"user_name\":\"NetWorks Rhode Island\",\"user_url\":\"https:\\/\\/vimeo.com\\/networksri\",\"user_portrait_small\":\"https:\\/\\/i.vimeocdn.com\\/portrait\\/17602548_30x30\",\"user_portrait_medium\":\"https:\\/\\/i.vimeocdn.com\\/portrait\\/17602548_75x75\",\"user_portrait_large\":\"https:\\/\\/i.vimeocdn.com\\/portrait\\/17602548_100x100\",\"user_portrait_huge\":\"https:\\/\\/i.vimeocdn.com\\/portrait\\/17602548_300x300\",\"stats_number_of_likes\":1,\"stats_number_of_plays\":168,\"stats_number_of_comments\":0,\"duration\":512,\"width\":1280,\"height\":720,\"tags\":\"\",\"embed_privacy\":\"anywhere\"}]\";s:3:\"raw\";s:2623:\"HTTP/1.1 200 OK\r\nServer: nginx\r\nContent-Type: application/json\r\nAccess-Control-Allow-Origin: *\r\nX-Content-Type-Options: nosniff\r\nX-Frame-Options: sameorigin\r\nX-RateLimit-Limit: 3600\r\nX-RateLimit-Remaining: 3599\r\nX-RateLimit-Reset: 1524166545\r\nContent-Disposition: attachment; filename=vimeo.json\r\nCache-Control: max-age=60\r\nExpires: Thu, 19 Apr 2018 18:36:45 GMT\r\nLast-Modified: Thu, 19 Apr 2018 15:51:28 GMT\r\nEtag: \"26f3b1b96b184c605116550f43f265ab\"\r\nX-UA-Compatible: IE=edge\r\nX-XSS-Protection: 1; mode=block\r\nStrict-Transport-Security: max-age=15552000; includeSubDomains; preload\r\nContent-Security-Policy-Report-Only: default-src https: data: blob: wss: \'unsafe-inline\' \'unsafe-eval\'; report-uri /_csp\r\nContent-Encoding: gzip\r\nVia: 1.1 varnish\r\nContent-Length: 770\r\nAccept-Ranges: bytes\r\nDate: Thu, 19 Apr 2018 18:35:45 GMT\r\nVia: 1.1 varnish\r\nAge: 0\r\nConnection: close\r\nX-Served-By: cache-iad2143-IAD, cache-ewr18121-EWR\r\nX-Cache: MISS, MISS\r\nX-Cache-Hits: 0, 0\r\nX-Timer: S1524162946.919227,VS0,VE36\r\nVary: User-Agent,Accept-Encoding\r\n\r\n[{\"id\":78535116,\"title\":\"MORRIS NATHANSON\",\"description\":\"Morris Nathanson founded the firm Morris Nathanson Design in 1967, and for over 40 years, he has developed a legacy in the Interior Design field, as a businessman and as an entrepreneur.  Nathanson\'s art has evolved not from any one style, but many, and more from a personal reaction to family events and community. His method of expression is varied in painting, print making and wood assemblage.  Nathanson is a civic leader in the community and volunteers with several non-profit and municipal organizations. He was the 2005 recipient of The Pawtucket Foundation Heritage Award that recognizes a long term commitment to the City of Pawtucket and its residents.\",\"url\":\"https:\\/\\/vimeo.com\\/78535116\",\"upload_date\":\"2013-11-04 09:43:30\",\"thumbnail_small\":\"https:\\/\\/i.vimeocdn.com\\/video\\/453943764_100x75.jpg\",\"thumbnail_medium\":\"https:\\/\\/i.vimeocdn.com\\/video\\/453943764_200x150.jpg\",\"thumbnail_large\":\"https:\\/\\/i.vimeocdn.com\\/video\\/453943764_640.jpg\",\"user_id\":9531360,\"user_name\":\"NetWorks Rhode Island\",\"user_url\":\"https:\\/\\/vimeo.com\\/networksri\",\"user_portrait_small\":\"https:\\/\\/i.vimeocdn.com\\/portrait\\/17602548_30x30\",\"user_portrait_medium\":\"https:\\/\\/i.vimeocdn.com\\/portrait\\/17602548_75x75\",\"user_portrait_large\":\"https:\\/\\/i.vimeocdn.com\\/portrait\\/17602548_100x100\",\"user_portrait_huge\":\"https:\\/\\/i.vimeocdn.com\\/portrait\\/17602548_300x300\",\"stats_number_of_likes\":1,\"stats_number_of_plays\":168,\"stats_number_of_comments\":0,\"duration\":512,\"width\":1280,\"height\":720,\"tags\":\"\",\"embed_privacy\":\"anywhere\"}]\";s:7:\"headers\";O:25:\"Requests_Response_Headers\":1:{s:7:\"\0*\0data\";a:28:{s:6:\"server\";a:1:{i:0;s:5:\"nginx\";}s:12:\"content-type\";a:1:{i:0;s:16:\"application/json\";}s:27:\"access-control-allow-origin\";a:1:{i:0;s:1:\"*\";}s:22:\"x-content-type-options\";a:1:{i:0;s:7:\"nosniff\";}s:15:\"x-frame-options\";a:1:{i:0;s:10:\"sameorigin\";}s:17:\"x-ratelimit-limit\";a:1:{i:0;s:4:\"3600\";}s:21:\"x-ratelimit-remaining\";a:1:{i:0;s:4:\"3599\";}s:17:\"x-ratelimit-reset\";a:1:{i:0;s:10:\"1524166545\";}s:19:\"content-disposition\";a:1:{i:0;s:31:\"attachment; filename=vimeo.json\";}s:13:\"cache-control\";a:1:{i:0;s:10:\"max-age=60\";}s:7:\"expires\";a:1:{i:0;s:29:\"Thu, 19 Apr 2018 18:36:45 GMT\";}s:13:\"last-modified\";a:1:{i:0;s:29:\"Thu, 19 Apr 2018 15:51:28 GMT\";}s:4:\"etag\";a:1:{i:0;s:34:\"\"26f3b1b96b184c605116550f43f265ab\"\";}s:15:\"x-ua-compatible\";a:1:{i:0;s:7:\"IE=edge\";}s:16:\"x-xss-protection\";a:1:{i:0;s:13:\"1; mode=block\";}s:25:\"strict-transport-security\";a:1:{i:0;s:44:\"max-age=15552000; includeSubDomains; preload\";}s:35:\"content-security-policy-report-only\";a:1:{i:0;s:83:\"default-src https: data: blob: wss: \'unsafe-inline\' \'unsafe-eval\'; report-uri /_csp\";}s:16:\"content-encoding\";a:1:{i:0;s:4:\"gzip\";}s:3:\"via\";a:2:{i:0;s:11:\"1.1 varnish\";i:1;s:11:\"1.1 varnish\";}s:14:\"content-length\";a:1:{i:0;s:3:\"770\";}s:13:\"accept-ranges\";a:1:{i:0;s:5:\"bytes\";}s:4:\"date\";a:1:{i:0;s:29:\"Thu, 19 Apr 2018 18:35:45 GMT\";}s:3:\"age\";a:1:{i:0;s:1:\"0\";}s:11:\"x-served-by\";a:1:{i:0;s:37:\"cache-iad2143-IAD, cache-ewr18121-EWR\";}s:7:\"x-cache\";a:1:{i:0;s:10:\"MISS, MISS\";}s:12:\"x-cache-hits\";a:1:{i:0;s:4:\"0, 0\";}s:7:\"x-timer\";a:1:{i:0;s:27:\"S1524162946.919227,VS0,VE36\";}s:4:\"vary\";a:1:{i:0;s:26:\"User-Agent,Accept-Encoding\";}}}s:11:\"status_code\";i:200;s:16:\"protocol_version\";d:1.100000000000000088817841970012523233890533447265625;s:7:\"success\";b:1;s:9:\"redirects\";i:0;s:3:\"url\";s:44:\"https://vimeo.com/api/v2/video/78535116.json\";s:7:\"history\";a:0:{}s:7:\"cookies\";O:19:\"Requests_Cookie_Jar\":1:{s:10:\"\0*\0cookies\";a:0:{}}}s:11:\"\0*\0filename\";N;s:4:\"data\";N;s:7:\"headers\";N;s:6:\"status\";N;}}', 'no'),
(1350, '_transient_timeout_external_ip_address_::1', '1524777280', 'no'),
(1351, '_transient_external_ip_address_::1', '2600:6c64:4b7f:e678:0:d78b:c39f:f4c', 'no'),
(1352, '_site_transient_timeout_theme_roots', '1524174283', 'no'),
(1353, '_site_transient_theme_roots', 'a:1:{s:19:\"JointsWP-CSS-master\";s:7:\"/themes\";}', 'no'),
(1369, '_transient_timeout_jetpack_idc_allowed', '1524201658', 'no'),
(1370, '_transient_jetpack_idc_allowed', '1', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `wp_postmeta`
--

DROP TABLE IF EXISTS `wp_postmeta`;
CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_postmeta`
--

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 4, '_edit_last', '1'),
(3, 4, 'field_5ac7df22549dc', 'a:11:{s:3:\"key\";s:19:\"field_5ac7df22549dc\";s:5:\"label\";s:12:\"Banner Image\";s:4:\"name\";s:17:\"home_banner_image\";s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";s:1:\"1\";s:11:\"save_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:17:\"conditional_logic\";a:3:{s:6:\"status\";s:1:\"0\";s:5:\"rules\";a:1:{i:0;a:2:{s:5:\"field\";s:4:\"null\";s:8:\"operator\";s:2:\"==\";}}s:8:\"allorany\";s:3:\"all\";}s:8:\"order_no\";i:0;}'),
(5, 4, 'position', 'normal'),
(6, 4, 'layout', 'no_box'),
(7, 4, 'hide_on_screen', 'a:1:{i:0;s:11:\"the_content\";}'),
(8, 4, '_edit_lock', '1523274724:1'),
(9, 5, '_edit_last', '1'),
(10, 5, '_wp_page_template', 'templates/template-home.php'),
(11, 5, '_edit_lock', '1524195077:1'),
(12, 4, 'rule', 'a:5:{s:5:\"param\";s:4:\"page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:1:\"5\";s:8:\"order_no\";i:0;s:8:\"group_no\";i:0;}'),
(15, 8, '_edit_lock', '1524194989:1'),
(16, 8, '_edit_last', '1'),
(17, 2, '_wp_trash_meta_status', 'publish'),
(18, 2, '_wp_trash_meta_time', '1523289383'),
(19, 2, '_wp_desired_post_slug', 'sample-page'),
(20, 16, '_wp_attached_file', '2018/04/morris-nathanson-2018-retrospective-exhibition-providence-art-club.jpg'),
(21, 16, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:307;s:6:\"height\";i:396;s:4:\"file\";s:78:\"2018/04/morris-nathanson-2018-retrospective-exhibition-providence-art-club.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:78:\"morris-nathanson-2018-retrospective-exhibition-providence-art-club-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:78:\"morris-nathanson-2018-retrospective-exhibition-providence-art-club-233x300.jpg\";s:5:\"width\";i:233;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:78:\"morris-nathanson-2018-retrospective-exhibition-providence-art-club-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(22, 17, '_wp_attached_file', '2018/04/morris-nathanson-archive-composite.jpg'),
(23, 17, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1300;s:6:\"height\";i:655;s:4:\"file\";s:46:\"2018/04/morris-nathanson-archive-composite.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:46:\"morris-nathanson-archive-composite-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:46:\"morris-nathanson-archive-composite-300x151.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:151;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:46:\"morris-nathanson-archive-composite-768x387.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:387;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:47:\"morris-nathanson-archive-composite-1024x516.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:516;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:46:\"morris-nathanson-archive-composite-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(24, 18, '_wp_attached_file', '2018/04/morris-nathanson-pell-grant-waterfire-arts-center.jpg'),
(25, 18, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:307;s:6:\"height\";i:396;s:4:\"file\";s:61:\"2018/04/morris-nathanson-pell-grant-waterfire-arts-center.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:61:\"morris-nathanson-pell-grant-waterfire-arts-center-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:61:\"morris-nathanson-pell-grant-waterfire-arts-center-233x300.jpg\";s:5:\"width\";i:233;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:61:\"morris-nathanson-pell-grant-waterfire-arts-center-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(26, 19, '_wp_attached_file', '2018/04/morris-nathanson-portrait-homepage-banner.jpg'),
(27, 19, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1300;s:6:\"height\";i:721;s:4:\"file\";s:53:\"2018/04/morris-nathanson-portrait-homepage-banner.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:53:\"morris-nathanson-portrait-homepage-banner-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:53:\"morris-nathanson-portrait-homepage-banner-300x166.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:166;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:53:\"morris-nathanson-portrait-homepage-banner-768x426.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:426;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:54:\"morris-nathanson-portrait-homepage-banner-1024x568.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:568;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:53:\"morris-nathanson-portrait-homepage-banner-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(28, 20, '_wp_attached_file', '2018/04/morris-nathanson-private-viewing-commission.jpg'),
(29, 20, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:307;s:6:\"height\";i:396;s:4:\"file\";s:55:\"2018/04/morris-nathanson-private-viewing-commission.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:55:\"morris-nathanson-private-viewing-commission-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:55:\"morris-nathanson-private-viewing-commission-233x300.jpg\";s:5:\"width\";i:233;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:55:\"morris-nathanson-private-viewing-commission-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(30, 21, '_wp_attached_file', '2018/04/morris-nathanson-studio-quote.jpg'),
(31, 21, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1300;s:6:\"height\";i:728;s:4:\"file\";s:41:\"2018/04/morris-nathanson-studio-quote.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:41:\"morris-nathanson-studio-quote-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:41:\"morris-nathanson-studio-quote-300x168.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:168;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:41:\"morris-nathanson-studio-quote-768x430.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:430;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:42:\"morris-nathanson-studio-quote-1024x573.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:573;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:41:\"morris-nathanson-studio-quote-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(32, 5, 'home_banner_image', '19'),
(33, 5, '_home_banner_image', 'field_5ac7df22549dc'),
(34, 5, 'home_banner_headline', 'Artist and Designer.'),
(35, 5, '_home_banner_headline', 'field_5acb54f2e6861'),
(36, 5, 'home_banner_cta_text', 'See the studio »'),
(37, 5, '_home_banner_cta_text', 'field_5acb5515e6862'),
(38, 5, 'home_banner_cta_link', '52'),
(39, 5, '_home_banner_cta_link', 'field_5acb5532e6863'),
(40, 5, '_', 'field_5acb55b8e6864'),
(41, 22, 'home_banner_image', '19'),
(42, 22, '_home_banner_image', 'field_5ac7df22549dc'),
(43, 22, 'home_banner_headline', 'Artist and Designer.'),
(44, 22, '_home_banner_headline', 'field_5acb54f2e6861'),
(45, 22, 'home_banner_cta_text', 'See the studio »'),
(46, 22, '_home_banner_cta_text', 'field_5acb5515e6862'),
(47, 22, 'home_banner_cta_link', ''),
(48, 22, '_home_banner_cta_link', 'field_5acb5532e6863'),
(49, 5, 'home_cta_background_image', '17'),
(50, 5, '_home_cta_background_image', 'field_5acb90daf1058'),
(51, 5, 'home_cta_text', 'View the work »'),
(52, 5, '_home_cta_text', 'field_5acb90c3f1057'),
(53, 5, 'home_cta_link', ''),
(54, 5, '_home_cta_link', 'field_5acb9114f1059'),
(55, 26, 'home_banner_image', '19'),
(56, 26, '_home_banner_image', 'field_5ac7df22549dc'),
(57, 26, 'home_banner_headline', 'Artist and Designer.'),
(58, 26, '_home_banner_headline', 'field_5acb54f2e6861'),
(59, 26, 'home_banner_cta_text', 'See the studio »'),
(60, 26, '_home_banner_cta_text', 'field_5acb5515e6862'),
(61, 26, 'home_banner_cta_link', ''),
(62, 26, '_home_banner_cta_link', 'field_5acb5532e6863'),
(63, 26, 'home_cta_background_image', '17'),
(64, 26, '_home_cta_background_image', 'field_5acb90daf1058'),
(65, 26, 'home_cta_text', 'View the work »'),
(66, 26, '_home_cta_text', 'field_5acb90c3f1057'),
(67, 26, 'home_cta_link', ''),
(68, 26, '_home_cta_link', 'field_5acb9114f1059'),
(69, 1, '_edit_lock', '1523297258:1'),
(70, 29, '_edit_last', '1'),
(71, 29, '_edit_lock', '1523644291:1'),
(72, 38, '_edit_last', '1'),
(73, 38, '_edit_lock', '1524078326:1'),
(74, 38, 'gallery_piece_details', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore.'),
(75, 38, '_gallery_piece_details', 'field_5acbaeb6ce7fc'),
(76, 38, 'gallery_piece_medium', ''),
(77, 38, '_gallery_piece_medium', 'field_5acbaf04ce7fd'),
(78, 38, 'gallery_piece_year', ''),
(79, 38, '_gallery_piece_year', 'field_5acbaf11ce7fe'),
(80, 38, 'gallery_piece_size', '18\" x 12\"'),
(81, 38, '_gallery_piece_size', 'field_5acbaf1cce7ff'),
(82, 34, '_edit_lock', '1524172356:1'),
(83, 35, '_edit_lock', '1524162468:1'),
(84, 39, '_wc_review_count', '0'),
(85, 39, '_wc_rating_count', 'a:0:{}'),
(86, 39, '_wc_average_rating', '0'),
(87, 39, '_edit_last', '1'),
(88, 39, '_edit_lock', '1524161301:1'),
(89, 39, '_sku', ''),
(90, 39, '_regular_price', '30000'),
(91, 39, '_sale_price', ''),
(92, 39, '_sale_price_dates_from', ''),
(93, 39, '_sale_price_dates_to', ''),
(94, 39, 'total_sales', '0'),
(95, 39, '_tax_status', 'taxable'),
(96, 39, '_tax_class', ''),
(97, 39, '_manage_stock', 'no'),
(98, 39, '_backorders', 'no'),
(99, 39, '_sold_individually', 'yes'),
(100, 39, '_weight', ''),
(101, 39, '_length', ''),
(102, 39, '_width', ''),
(103, 39, '_height', ''),
(104, 39, '_upsell_ids', 'a:0:{}'),
(105, 39, '_crosssell_ids', 'a:0:{}'),
(106, 39, '_purchase_note', ''),
(107, 39, '_default_attributes', 'a:0:{}'),
(108, 39, '_virtual', 'no'),
(109, 39, '_downloadable', 'no'),
(110, 39, '_product_image_gallery', ''),
(111, 39, '_download_limit', '-1'),
(112, 39, '_download_expiry', '-1'),
(113, 39, '_stock', NULL),
(114, 39, '_stock_status', 'instock'),
(115, 39, '_product_version', '3.3.5'),
(116, 39, '_price', '30000'),
(117, 40, '_wp_attached_file', '2018/04/morris-nathanson-painting-bar-mitzvah-on-japonica-street2.jpg'),
(118, 40, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:198;s:6:\"height\";i:248;s:4:\"file\";s:69:\"2018/04/morris-nathanson-painting-bar-mitzvah-on-japonica-street2.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:69:\"morris-nathanson-painting-bar-mitzvah-on-japonica-street2-120x150.jpg\";s:5:\"width\";i:120;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:69:\"morris-nathanson-painting-bar-mitzvah-on-japonica-street2-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:69:\"morris-nathanson-painting-bar-mitzvah-on-japonica-street2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:69:\"morris-nathanson-painting-bar-mitzvah-on-japonica-street2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:69:\"morris-nathanson-painting-bar-mitzvah-on-japonica-street2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:69:\"morris-nathanson-painting-bar-mitzvah-on-japonica-street2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(119, 39, '_thumbnail_id', '223'),
(120, 5, 'home_quote_background_image', '21'),
(121, 5, '_home_quote_background_image', 'field_5acbcda4a152e'),
(122, 5, 'home_quote_text', '“What is unique about being a designer and also an artist, is that you are always composing and designing. It\'s like breathing. It\'s inherent. It\'s like musicians who are always humming when they walk down the street and don\'t even know they are doing it.\"'),
(123, 5, '_home_quote_text', 'field_5acbcdb6a152f'),
(124, 45, 'home_banner_image', '19'),
(125, 45, '_home_banner_image', 'field_5ac7df22549dc'),
(126, 45, 'home_banner_headline', 'Artist and Designer.'),
(127, 45, '_home_banner_headline', 'field_5acb54f2e6861'),
(128, 45, 'home_banner_cta_text', 'See the studio »'),
(129, 45, '_home_banner_cta_text', 'field_5acb5515e6862'),
(130, 45, 'home_banner_cta_link', ''),
(131, 45, '_home_banner_cta_link', 'field_5acb5532e6863'),
(132, 45, 'home_cta_background_image', '17'),
(133, 45, '_home_cta_background_image', 'field_5acb90daf1058'),
(134, 45, 'home_cta_text', 'View the work »'),
(135, 45, '_home_cta_text', 'field_5acb90c3f1057'),
(136, 45, 'home_cta_link', ''),
(137, 45, '_home_cta_link', 'field_5acb9114f1059'),
(138, 45, 'home_quote_background_image', '21'),
(139, 45, '_home_quote_background_image', 'field_5acbcda4a152e'),
(140, 45, 'home_quote_text', '“What is unique about being a designer and also an artist, is that you are always composing and designing. It\'s like breathing. It\'s inherent. It\'s like musicians who are always humming when they walk down the street and don\'t even know they are doing it.\"'),
(141, 45, '_home_quote_text', 'field_5acbcdb6a152f'),
(142, 46, '_edit_last', '1'),
(143, 46, '_edit_lock', '1524196604:1'),
(144, 52, '_edit_last', '1'),
(145, 52, '_edit_lock', '1524198459:1'),
(146, 52, '_wp_page_template', 'templates/template-in-the-studio.php'),
(147, 52, 'studio_main_video', 'https://vimeo.com/245236016'),
(148, 52, '_studio_main_video', 'field_5accb52e890ab'),
(149, 52, 'studio_visit_description', 'Meet the artist and experience the studio in person. <br>Contact gallery representative Phyllis Van Orden to set<br> up an appointment.'),
(150, 52, '_studio_visit_description', 'field_5accb5e2890ad'),
(151, 52, 'studio_visit_cta_link', ''),
(152, 52, '_studio_visit_cta_link', 'field_5accb604890af'),
(153, 52, 'studio_visit_cta_text', 'Contact »'),
(154, 52, '_studio_visit_cta_text', 'field_5accb5f3890ae'),
(155, 54, 'studio_main_video', ''),
(156, 54, '_studio_main_video', 'field_5accb52e890ab'),
(157, 54, 'studio_visit_description', 'Meet the artist and experience the studio in person. Contact gallery representative Phyllis Vanorden to set up an appointment.'),
(158, 54, '_studio_visit_description', 'field_5accb5e2890ad'),
(159, 54, 'studio_visit_cta_link', ''),
(160, 54, '_studio_visit_cta_link', 'field_5accb604890af'),
(161, 54, 'studio_visit_cta_text', 'Contact »'),
(162, 54, '_studio_visit_cta_text', 'field_5accb5f3890ae'),
(163, 52, 'studio_visit_headline', 'Schedule a Visit:'),
(164, 52, '_studio_visit_headline', 'field_5accddbd0baff'),
(165, 56, 'studio_main_video', ''),
(166, 56, '_studio_main_video', 'field_5accb52e890ab'),
(167, 56, 'studio_visit_description', 'Meet the artist and experience the studio in person. Contact gallery representative Phyllis Vanorden to set up an appointment.'),
(168, 56, '_studio_visit_description', 'field_5accb5e2890ad'),
(169, 56, 'studio_visit_cta_link', ''),
(170, 56, '_studio_visit_cta_link', 'field_5accb604890af'),
(171, 56, 'studio_visit_cta_text', 'Contact »'),
(172, 56, '_studio_visit_cta_text', 'field_5accb5f3890ae'),
(173, 56, 'studio_visit_headline', 'Schedule a Visit:'),
(174, 56, '_studio_visit_headline', 'field_5accddbd0baff'),
(175, 57, 'ml-slider_settings', 'a:35:{s:4:\"type\";s:4:\"flex\";s:6:\"random\";s:5:\"false\";s:8:\"cssClass\";s:0:\"\";s:8:\"printCss\";s:4:\"true\";s:7:\"printJs\";s:4:\"true\";s:5:\"width\";s:3:\"550\";s:6:\"height\";s:3:\"310\";s:3:\"spw\";s:1:\"7\";s:3:\"sph\";s:1:\"5\";s:5:\"delay\";s:4:\"3000\";s:6:\"sDelay\";s:2:\"30\";s:7:\"opacity\";s:1:\"0\";s:10:\"titleSpeed\";s:3:\"500\";s:6:\"effect\";s:5:\"slide\";s:10:\"navigation\";s:5:\"false\";s:5:\"links\";s:4:\"true\";s:10:\"hoverPause\";s:4:\"true\";s:5:\"theme\";s:7:\"default\";s:9:\"direction\";s:10:\"horizontal\";s:7:\"reverse\";s:5:\"false\";s:14:\"animationSpeed\";s:3:\"600\";s:8:\"prevText\";s:8:\"Previous\";s:8:\"nextText\";s:4:\"Next\";s:6:\"slices\";s:2:\"15\";s:6:\"center\";s:4:\"true\";s:9:\"smartCrop\";s:4:\"true\";s:12:\"carouselMode\";s:4:\"true\";s:14:\"carouselMargin\";s:2:\"30\";s:6:\"easing\";s:6:\"linear\";s:8:\"autoPlay\";s:5:\"false\";s:11:\"thumb_width\";i:150;s:12:\"thumb_height\";i:100;s:9:\"fullWidth\";s:4:\"true\";s:10:\"noConflict\";s:4:\"true\";s:12:\"smoothHeight\";s:5:\"false\";}'),
(176, 58, '_wp_attached_file', '2018/04/morris-nathanson-in-the-studio-artwork-in-progress.jpg'),
(177, 58, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:553;s:6:\"height\";i:311;s:4:\"file\";s:62:\"2018/04/morris-nathanson-in-the-studio-artwork-in-progress.jpg\";s:5:\"sizes\";a:11:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:61:\"morris-nathanson-in-the-studio-artwork-in-progress-150x84.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:84;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:62:\"morris-nathanson-in-the-studio-artwork-in-progress-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:62:\"morris-nathanson-in-the-studio-artwork-in-progress-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:62:\"morris-nathanson-in-the-studio-artwork-in-progress-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:62:\"morris-nathanson-in-the-studio-artwork-in-progress-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:62:\"morris-nathanson-in-the-studio-artwork-in-progress-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:62:\"morris-nathanson-in-the-studio-artwork-in-progress-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:62:\"morris-nathanson-in-the-studio-artwork-in-progress-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:62:\"morris-nathanson-in-the-studio-artwork-in-progress-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:27:\"meta-slider-resized-700x300\";a:4:{s:4:\"file\";s:62:\"morris-nathanson-in-the-studio-artwork-in-progress-700x300.jpg\";s:5:\"width\";i:553;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:27:\"meta-slider-resized-550x310\";a:4:{s:4:\"file\";s:62:\"morris-nathanson-in-the-studio-artwork-in-progress-550x310.jpg\";s:5:\"width\";i:550;s:6:\"height\";i:310;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(178, 59, '_wp_attached_file', '2018/04/morris-nathanson-in-the-studio-sitting-with-new-artwork.jpg'),
(179, 59, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:555;s:6:\"height\";i:312;s:4:\"file\";s:67:\"2018/04/morris-nathanson-in-the-studio-sitting-with-new-artwork.jpg\";s:5:\"sizes\";a:11:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:66:\"morris-nathanson-in-the-studio-sitting-with-new-artwork-150x84.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:84;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:67:\"morris-nathanson-in-the-studio-sitting-with-new-artwork-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:67:\"morris-nathanson-in-the-studio-sitting-with-new-artwork-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:67:\"morris-nathanson-in-the-studio-sitting-with-new-artwork-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:67:\"morris-nathanson-in-the-studio-sitting-with-new-artwork-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:67:\"morris-nathanson-in-the-studio-sitting-with-new-artwork-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:67:\"morris-nathanson-in-the-studio-sitting-with-new-artwork-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:67:\"morris-nathanson-in-the-studio-sitting-with-new-artwork-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:67:\"morris-nathanson-in-the-studio-sitting-with-new-artwork-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:27:\"meta-slider-resized-700x300\";a:4:{s:4:\"file\";s:67:\"morris-nathanson-in-the-studio-sitting-with-new-artwork-700x300.jpg\";s:5:\"width\";i:555;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:27:\"meta-slider-resized-550x310\";a:4:{s:4:\"file\";s:67:\"morris-nathanson-in-the-studio-sitting-with-new-artwork-550x310.jpg\";s:5:\"width\";i:550;s:6:\"height\";i:310;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(180, 60, '_wp_attached_file', '2018/04/morris-nathanson-in-the-studio-standing-with-new-artwork.jpg'),
(181, 60, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:555;s:6:\"height\";i:312;s:4:\"file\";s:68:\"2018/04/morris-nathanson-in-the-studio-standing-with-new-artwork.jpg\";s:5:\"sizes\";a:11:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:67:\"morris-nathanson-in-the-studio-standing-with-new-artwork-150x84.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:84;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:68:\"morris-nathanson-in-the-studio-standing-with-new-artwork-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:68:\"morris-nathanson-in-the-studio-standing-with-new-artwork-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:68:\"morris-nathanson-in-the-studio-standing-with-new-artwork-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:68:\"morris-nathanson-in-the-studio-standing-with-new-artwork-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:68:\"morris-nathanson-in-the-studio-standing-with-new-artwork-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:68:\"morris-nathanson-in-the-studio-standing-with-new-artwork-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:68:\"morris-nathanson-in-the-studio-standing-with-new-artwork-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:68:\"morris-nathanson-in-the-studio-standing-with-new-artwork-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:27:\"meta-slider-resized-700x300\";a:4:{s:4:\"file\";s:68:\"morris-nathanson-in-the-studio-standing-with-new-artwork-700x300.jpg\";s:5:\"width\";i:555;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:27:\"meta-slider-resized-550x310\";a:4:{s:4:\"file\";s:68:\"morris-nathanson-in-the-studio-standing-with-new-artwork-550x310.jpg\";s:5:\"width\";i:550;s:6:\"height\";i:310;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(182, 61, '_thumbnail_id', '58'),
(183, 61, 'ml-slider_type', 'image'),
(184, 61, 'ml-slider_inherit_image_caption', ''),
(185, 61, 'ml-slider_inherit_image_title', '1'),
(186, 61, 'ml-slider_inherit_image_alt', '1'),
(187, 62, '_thumbnail_id', '59'),
(188, 62, 'ml-slider_type', 'image'),
(189, 62, 'ml-slider_inherit_image_caption', ''),
(190, 62, 'ml-slider_inherit_image_title', '1'),
(191, 62, 'ml-slider_inherit_image_alt', '1'),
(192, 63, '_thumbnail_id', '60'),
(193, 63, 'ml-slider_type', 'image'),
(194, 63, 'ml-slider_inherit_image_caption', ''),
(195, 63, 'ml-slider_inherit_image_title', '1'),
(196, 63, 'ml-slider_inherit_image_alt', '1'),
(197, 58, '_wp_attachment_backup_sizes', 'a:2:{s:15:\"resized-700x300\";a:5:{s:4:\"path\";s:144:\"/Users/imac2/Documents/Websites/morrisnathanson.dev.cc/wp-content/uploads/2018/04/morris-nathanson-in-the-studio-artwork-in-progress-700x300.jpg\";s:4:\"file\";s:62:\"morris-nathanson-in-the-studio-artwork-in-progress-700x300.jpg\";s:5:\"width\";i:553;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"resized-550x310\";a:5:{s:4:\"path\";s:144:\"/Users/imac2/Documents/Websites/morrisnathanson.dev.cc/wp-content/uploads/2018/04/morris-nathanson-in-the-studio-artwork-in-progress-550x310.jpg\";s:4:\"file\";s:62:\"morris-nathanson-in-the-studio-artwork-in-progress-550x310.jpg\";s:5:\"width\";i:550;s:6:\"height\";i:310;s:9:\"mime-type\";s:10:\"image/jpeg\";}}'),
(198, 59, '_wp_attachment_backup_sizes', 'a:2:{s:15:\"resized-700x300\";a:5:{s:4:\"path\";s:149:\"/Users/imac2/Documents/Websites/morrisnathanson.dev.cc/wp-content/uploads/2018/04/morris-nathanson-in-the-studio-sitting-with-new-artwork-700x300.jpg\";s:4:\"file\";s:67:\"morris-nathanson-in-the-studio-sitting-with-new-artwork-700x300.jpg\";s:5:\"width\";i:555;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"resized-550x310\";a:5:{s:4:\"path\";s:149:\"/Users/imac2/Documents/Websites/morrisnathanson.dev.cc/wp-content/uploads/2018/04/morris-nathanson-in-the-studio-sitting-with-new-artwork-550x310.jpg\";s:4:\"file\";s:67:\"morris-nathanson-in-the-studio-sitting-with-new-artwork-550x310.jpg\";s:5:\"width\";i:550;s:6:\"height\";i:310;s:9:\"mime-type\";s:10:\"image/jpeg\";}}'),
(199, 60, '_wp_attachment_backup_sizes', 'a:2:{s:15:\"resized-700x300\";a:5:{s:4:\"path\";s:150:\"/Users/imac2/Documents/Websites/morrisnathanson.dev.cc/wp-content/uploads/2018/04/morris-nathanson-in-the-studio-standing-with-new-artwork-700x300.jpg\";s:4:\"file\";s:68:\"morris-nathanson-in-the-studio-standing-with-new-artwork-700x300.jpg\";s:5:\"width\";i:555;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"resized-550x310\";a:5:{s:4:\"path\";s:150:\"/Users/imac2/Documents/Websites/morrisnathanson.dev.cc/wp-content/uploads/2018/04/morris-nathanson-in-the-studio-standing-with-new-artwork-550x310.jpg\";s:4:\"file\";s:68:\"morris-nathanson-in-the-studio-standing-with-new-artwork-550x310.jpg\";s:5:\"width\";i:550;s:6:\"height\";i:310;s:9:\"mime-type\";s:10:\"image/jpeg\";}}'),
(200, 62, 'ml-slider_crop_position', 'center-center'),
(201, 62, '_wp_attachment_image_alt', ''),
(202, 61, 'ml-slider_crop_position', 'center-center'),
(203, 61, '_wp_attachment_image_alt', ''),
(204, 63, 'ml-slider_crop_position', 'center-center'),
(205, 63, '_wp_attachment_image_alt', ''),
(206, 73, '_wp_attached_file', '2018/04/in-the-studio-grid-pattern-background.jpg'),
(207, 73, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1300;s:6:\"height\";i:558;s:4:\"file\";s:49:\"2018/04/in-the-studio-grid-pattern-background.jpg\";s:5:\"sizes\";a:11:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:48:\"in-the-studio-grid-pattern-background-150x64.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:64;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:49:\"in-the-studio-grid-pattern-background-300x129.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:129;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:49:\"in-the-studio-grid-pattern-background-768x330.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:330;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:50:\"in-the-studio-grid-pattern-background-1024x440.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:440;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:49:\"in-the-studio-grid-pattern-background-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:49:\"in-the-studio-grid-pattern-background-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:49:\"in-the-studio-grid-pattern-background-300x129.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:129;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:49:\"in-the-studio-grid-pattern-background-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:49:\"in-the-studio-grid-pattern-background-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:49:\"in-the-studio-grid-pattern-background-300x129.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:129;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:49:\"in-the-studio-grid-pattern-background-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(208, 52, 'studio_videos', '3'),
(209, 52, '_studio_videos', 'field_5accf625e0115'),
(210, 52, 'studio_progress_header', 'In Progress'),
(211, 52, '_studio_progress_header', 'field_5accfea1e011c'),
(212, 52, 'studio_progress_background_image', '73'),
(213, 52, '_studio_progress_background_image', 'field_5accfe88e011b'),
(214, 52, 'studio_progress_slideshow_shortcode', ''),
(215, 52, '_studio_progress_slideshow_shortcode', 'field_5accfebde011d'),
(216, 74, 'studio_main_video', ''),
(217, 74, '_studio_main_video', 'field_5accb52e890ab'),
(218, 74, 'studio_visit_description', 'Meet the artist and experience the studio in person. Contact gallery representative Phyllis Vanorden to set up an appointment.'),
(219, 74, '_studio_visit_description', 'field_5accb5e2890ad'),
(220, 74, 'studio_visit_cta_link', ''),
(221, 74, '_studio_visit_cta_link', 'field_5accb604890af'),
(222, 74, 'studio_visit_cta_text', 'Contact »'),
(223, 74, '_studio_visit_cta_text', 'field_5accb5f3890ae'),
(224, 74, 'studio_visit_headline', 'Schedule a Visit:'),
(225, 74, '_studio_visit_headline', 'field_5accddbd0baff'),
(226, 74, 'studio_videos', ''),
(227, 74, '_studio_videos', 'field_5accf625e0115'),
(228, 74, 'studio_progress_header', 'In Progress'),
(229, 74, '_studio_progress_header', 'field_5accfea1e011c'),
(230, 74, 'studio_progress_background_image', '73'),
(231, 74, '_studio_progress_background_image', 'field_5accfe88e011b'),
(232, 74, 'studio_progress_slideshow_shortcode', '[metaslider id=\"57\"]'),
(233, 74, '_studio_progress_slideshow_shortcode', 'field_5accfebde011d'),
(234, 75, 'studio_main_video', ''),
(235, 75, '_studio_main_video', 'field_5accb52e890ab'),
(236, 75, 'studio_visit_description', 'Meet the artist and experience the studio in person. Contact gallery representative Phyllis Vanorden to set up an appointment.'),
(237, 75, '_studio_visit_description', 'field_5accb5e2890ad'),
(238, 75, 'studio_visit_cta_link', ''),
(239, 75, '_studio_visit_cta_link', 'field_5accb604890af'),
(240, 75, 'studio_visit_cta_text', 'Contact »'),
(241, 75, '_studio_visit_cta_text', 'field_5accb5f3890ae'),
(242, 75, 'studio_visit_headline', 'Schedule a Visit:'),
(243, 75, '_studio_visit_headline', 'field_5accddbd0baff'),
(244, 75, 'studio_videos', ''),
(245, 75, '_studio_videos', 'field_5accf625e0115'),
(246, 75, 'studio_progress_header', 'In Progress'),
(247, 75, '_studio_progress_header', 'field_5accfea1e011c'),
(248, 75, 'studio_progress_background_image', '73'),
(249, 75, '_studio_progress_background_image', 'field_5accfe88e011b'),
(250, 75, 'studio_progress_slideshow_shortcode', ''),
(251, 75, '_studio_progress_slideshow_shortcode', 'field_5accfebde011d'),
(252, 76, '_menu_item_type', 'post_type'),
(253, 76, '_menu_item_menu_item_parent', '0'),
(254, 76, '_menu_item_object_id', '52'),
(255, 76, '_menu_item_object', 'page'),
(256, 76, '_menu_item_target', ''),
(257, 76, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(258, 76, '_menu_item_xfn', ''),
(259, 76, '_menu_item_url', ''),
(270, 78, '_form', '<div class=\"contact-form\">\n	<div class=\"grid-x shrink\">\n		<div class=\"medium-12 cell\">\n			<h3 class=\"contact-header\">Contact</h3>\n			<p>Inquiries to gallery representative Phyllis Van Orden</p>\n		</div>\n\n		<div class=\"medium-12 cell\">\n			<label> [text* your-name] First, last name </label>\n		</div>\n\n		<div class=\"medium-12 cell\">\n			<label> [tel* your-number] Phone number </label>\n		</div>\n				\n		<div class=\"medium-12 cell\">\n			<label> [email* your-email] Email address </label>\n		</div>\n\n		<div class=\"medium-12 cell\">\n			<label> [textarea your-message] Type your message above </label>\n		</div>\n\n		<div class=\"medium-12 cell\">\n			[submit \"Submit »\"]\n		</div>\n	</div>\n</div>'),
(271, 78, '_mail', 'a:9:{s:6:\"active\";b:1;s:7:\"subject\";s:39:\"Morris Nathanson Art – Studio Inquiry\";s:6:\"sender\";s:46:\"[your-name] <wordpress@morrisnathanson.dev.cc>\";s:9:\"recipient\";s:19:\"dan@delindesign.com\";s:4:\"body\";s:192:\"From: [your-name] <[your-email]>\nPhone number: [your-number]\n\nMessage Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on Morris Nathanson Art (http://morrisnathanson.dev.cc)\";s:18:\"additional_headers\";s:22:\"Reply-To: [your-email]\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}'),
(272, 78, '_mail_2', 'a:9:{s:6:\"active\";b:0;s:7:\"subject\";s:37:\"Morris Nathanson Art \"[your-subject]\"\";s:6:\"sender\";s:55:\"Morris Nathanson Art <wordpress@morrisnathanson.dev.cc>\";s:9:\"recipient\";s:12:\"[your-email]\";s:4:\"body\";s:130:\"Message Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on Morris Nathanson Art (http://morrisnathanson.dev.cc)\";s:18:\"additional_headers\";s:29:\"Reply-To: dan@delindesign.com\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}'),
(273, 78, '_messages', 'a:23:{s:12:\"mail_sent_ok\";s:45:\"Thank you for your message. It has been sent.\";s:12:\"mail_sent_ng\";s:71:\"There was an error trying to send your message. Please try again later.\";s:16:\"validation_error\";s:61:\"One or more fields have an error. Please check and try again.\";s:4:\"spam\";s:71:\"There was an error trying to send your message. Please try again later.\";s:12:\"accept_terms\";s:69:\"You must accept the terms and conditions before sending your message.\";s:16:\"invalid_required\";s:22:\"The field is required.\";s:16:\"invalid_too_long\";s:22:\"The field is too long.\";s:17:\"invalid_too_short\";s:23:\"The field is too short.\";s:12:\"invalid_date\";s:29:\"The date format is incorrect.\";s:14:\"date_too_early\";s:44:\"The date is before the earliest one allowed.\";s:13:\"date_too_late\";s:41:\"The date is after the latest one allowed.\";s:13:\"upload_failed\";s:46:\"There was an unknown error uploading the file.\";s:24:\"upload_file_type_invalid\";s:49:\"You are not allowed to upload files of this type.\";s:21:\"upload_file_too_large\";s:20:\"The file is too big.\";s:23:\"upload_failed_php_error\";s:38:\"There was an error uploading the file.\";s:14:\"invalid_number\";s:29:\"The number format is invalid.\";s:16:\"number_too_small\";s:47:\"The number is smaller than the minimum allowed.\";s:16:\"number_too_large\";s:46:\"The number is larger than the maximum allowed.\";s:23:\"quiz_answer_not_correct\";s:36:\"The answer to the quiz is incorrect.\";s:17:\"captcha_not_match\";s:31:\"Your entered code is incorrect.\";s:13:\"invalid_email\";s:38:\"The e-mail address entered is invalid.\";s:11:\"invalid_url\";s:19:\"The URL is invalid.\";s:11:\"invalid_tel\";s:32:\"The telephone number is invalid.\";}'),
(274, 78, '_additional_settings', ''),
(275, 78, '_locale', 'en_US'),
(276, 52, 'studio_videos_0_studio_video_related_url', 'https://vimeo.com/244749533'),
(277, 52, '_studio_videos_0_studio_video_related_url', 'field_5accf64ae0116'),
(278, 52, 'studio_videos_0_studio_video_related_thumbnail', '83'),
(279, 52, '_studio_videos_0_studio_video_related_thumbnail', 'field_5accf6cae0117'),
(280, 52, 'studio_videos_0_studio_video_related_caption', 'The therapy of drawing.'),
(281, 52, '_studio_videos_0_studio_video_related_caption', 'field_5accf704e0118'),
(282, 52, 'studio_videos_1_studio_video_related_url', 'https://vimeo.com/244749306'),
(283, 52, '_studio_videos_1_studio_video_related_url', 'field_5accf64ae0116'),
(284, 52, 'studio_videos_1_studio_video_related_thumbnail', '81'),
(285, 52, '_studio_videos_1_studio_video_related_thumbnail', 'field_5accf6cae0117'),
(286, 52, 'studio_videos_1_studio_video_related_caption', 'Going through the archives.'),
(287, 52, '_studio_videos_1_studio_video_related_caption', 'field_5accf704e0118'),
(288, 52, 'studio_videos_2_studio_video_related_url', 'https://vimeo.com/249770248'),
(289, 52, '_studio_videos_2_studio_video_related_url', 'field_5accf64ae0116'),
(290, 52, 'studio_videos_2_studio_video_related_thumbnail', '82'),
(291, 52, '_studio_videos_2_studio_video_related_thumbnail', 'field_5accf6cae0117'),
(292, 52, 'studio_videos_2_studio_video_related_caption', 'Technique and process: ink to paper.'),
(293, 52, '_studio_videos_2_studio_video_related_caption', 'field_5accf704e0118'),
(294, 79, 'studio_main_video', 'https://vimeo.com/245236016'),
(295, 79, '_studio_main_video', 'field_5accb52e890ab'),
(296, 79, 'studio_visit_description', 'Meet the artist and experience the studio in person. Contact gallery representative Phyllis Vanorden to set up an appointment.'),
(297, 79, '_studio_visit_description', 'field_5accb5e2890ad'),
(298, 79, 'studio_visit_cta_link', ''),
(299, 79, '_studio_visit_cta_link', 'field_5accb604890af'),
(300, 79, 'studio_visit_cta_text', 'Contact »'),
(301, 79, '_studio_visit_cta_text', 'field_5accb5f3890ae'),
(302, 79, 'studio_visit_headline', 'Schedule a Visit:'),
(303, 79, '_studio_visit_headline', 'field_5accddbd0baff'),
(304, 79, 'studio_videos', '3'),
(305, 79, '_studio_videos', 'field_5accf625e0115'),
(306, 79, 'studio_progress_header', 'In Progress'),
(307, 79, '_studio_progress_header', 'field_5accfea1e011c'),
(308, 79, 'studio_progress_background_image', '73'),
(309, 79, '_studio_progress_background_image', 'field_5accfe88e011b'),
(310, 79, 'studio_progress_slideshow_shortcode', ''),
(311, 79, '_studio_progress_slideshow_shortcode', 'field_5accfebde011d'),
(312, 79, 'studio_videos_0_studio_video_related_url', 'https://vimeo.com/244749533'),
(313, 79, '_studio_videos_0_studio_video_related_url', 'field_5accf64ae0116'),
(314, 79, 'studio_videos_0_studio_video_related_thumbnail', ''),
(315, 79, '_studio_videos_0_studio_video_related_thumbnail', 'field_5accf6cae0117'),
(316, 79, 'studio_videos_0_studio_video_related_caption', 'The therapy of drawing.'),
(317, 79, '_studio_videos_0_studio_video_related_caption', 'field_5accf704e0118'),
(318, 79, 'studio_videos_1_studio_video_related_url', 'https://vimeo.com/244749306'),
(319, 79, '_studio_videos_1_studio_video_related_url', 'field_5accf64ae0116'),
(320, 79, 'studio_videos_1_studio_video_related_thumbnail', ''),
(321, 79, '_studio_videos_1_studio_video_related_thumbnail', 'field_5accf6cae0117'),
(322, 79, 'studio_videos_1_studio_video_related_caption', 'Going through the archives.'),
(323, 79, '_studio_videos_1_studio_video_related_caption', 'field_5accf704e0118'),
(324, 79, 'studio_videos_2_studio_video_related_url', 'https://vimeo.com/249770248'),
(325, 79, '_studio_videos_2_studio_video_related_url', 'field_5accf64ae0116'),
(326, 79, 'studio_videos_2_studio_video_related_thumbnail', ''),
(327, 79, '_studio_videos_2_studio_video_related_thumbnail', 'field_5accf6cae0117'),
(328, 79, 'studio_videos_2_studio_video_related_caption', 'Technique and process: ink to paper.'),
(329, 79, '_studio_videos_2_studio_video_related_caption', 'field_5accf704e0118'),
(330, 81, '_wp_attached_file', '2018/04/morris-nathanson-archives-video-thumbnail.jpg'),
(331, 81, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:307;s:6:\"height\";i:166;s:4:\"file\";s:53:\"2018/04/morris-nathanson-archives-video-thumbnail.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:52:\"morris-nathanson-archives-video-thumbnail-150x81.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:81;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:53:\"morris-nathanson-archives-video-thumbnail-300x162.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:162;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:53:\"morris-nathanson-archives-video-thumbnail-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:53:\"morris-nathanson-archives-video-thumbnail-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:53:\"morris-nathanson-archives-video-thumbnail-300x162.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:162;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:53:\"morris-nathanson-archives-video-thumbnail-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:53:\"morris-nathanson-archives-video-thumbnail-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:53:\"morris-nathanson-archives-video-thumbnail-300x162.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:162;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:53:\"morris-nathanson-archives-video-thumbnail-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(332, 82, '_wp_attached_file', '2018/04/morris-nathanson-technique-and-process-video-thumbnail.jpg'),
(333, 82, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:307;s:6:\"height\";i:166;s:4:\"file\";s:66:\"2018/04/morris-nathanson-technique-and-process-video-thumbnail.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:65:\"morris-nathanson-technique-and-process-video-thumbnail-150x81.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:81;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:66:\"morris-nathanson-technique-and-process-video-thumbnail-300x162.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:162;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:66:\"morris-nathanson-technique-and-process-video-thumbnail-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:66:\"morris-nathanson-technique-and-process-video-thumbnail-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:66:\"morris-nathanson-technique-and-process-video-thumbnail-300x162.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:162;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:66:\"morris-nathanson-technique-and-process-video-thumbnail-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:66:\"morris-nathanson-technique-and-process-video-thumbnail-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:66:\"morris-nathanson-technique-and-process-video-thumbnail-300x162.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:162;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:66:\"morris-nathanson-technique-and-process-video-thumbnail-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(334, 83, '_wp_attached_file', '2018/04/morris-nathanson-therapy-of-drawing-video-thumbnail.jpg');
INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(335, 83, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:307;s:6:\"height\";i:166;s:4:\"file\";s:63:\"2018/04/morris-nathanson-therapy-of-drawing-video-thumbnail.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:62:\"morris-nathanson-therapy-of-drawing-video-thumbnail-150x81.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:81;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:63:\"morris-nathanson-therapy-of-drawing-video-thumbnail-300x162.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:162;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:63:\"morris-nathanson-therapy-of-drawing-video-thumbnail-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:63:\"morris-nathanson-therapy-of-drawing-video-thumbnail-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:63:\"morris-nathanson-therapy-of-drawing-video-thumbnail-300x162.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:162;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:63:\"morris-nathanson-therapy-of-drawing-video-thumbnail-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:63:\"morris-nathanson-therapy-of-drawing-video-thumbnail-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:63:\"morris-nathanson-therapy-of-drawing-video-thumbnail-300x162.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:162;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:63:\"morris-nathanson-therapy-of-drawing-video-thumbnail-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(336, 52, 'studio_main_video_caption', ''),
(337, 52, '_studio_main_video_caption', 'field_5acd11915e5a0'),
(338, 84, 'studio_main_video', 'https://vimeo.com/245236016'),
(339, 84, '_studio_main_video', 'field_5accb52e890ab'),
(340, 84, 'studio_visit_description', 'Meet the artist and experience the studio in person. Contact gallery representative Phyllis Vanorden to set up an appointment.'),
(341, 84, '_studio_visit_description', 'field_5accb5e2890ad'),
(342, 84, 'studio_visit_cta_link', ''),
(343, 84, '_studio_visit_cta_link', 'field_5accb604890af'),
(344, 84, 'studio_visit_cta_text', 'Contact »'),
(345, 84, '_studio_visit_cta_text', 'field_5accb5f3890ae'),
(346, 84, 'studio_visit_headline', 'Schedule a Visit:'),
(347, 84, '_studio_visit_headline', 'field_5accddbd0baff'),
(348, 84, 'studio_videos', '3'),
(349, 84, '_studio_videos', 'field_5accf625e0115'),
(350, 84, 'studio_progress_header', 'In Progress'),
(351, 84, '_studio_progress_header', 'field_5accfea1e011c'),
(352, 84, 'studio_progress_background_image', '73'),
(353, 84, '_studio_progress_background_image', 'field_5accfe88e011b'),
(354, 84, 'studio_progress_slideshow_shortcode', ''),
(355, 84, '_studio_progress_slideshow_shortcode', 'field_5accfebde011d'),
(356, 84, 'studio_videos_0_studio_video_related_url', 'https://vimeo.com/244749533'),
(357, 84, '_studio_videos_0_studio_video_related_url', 'field_5accf64ae0116'),
(358, 84, 'studio_videos_0_studio_video_related_thumbnail', '83'),
(359, 84, '_studio_videos_0_studio_video_related_thumbnail', 'field_5accf6cae0117'),
(360, 84, 'studio_videos_0_studio_video_related_caption', 'The therapy of drawing.'),
(361, 84, '_studio_videos_0_studio_video_related_caption', 'field_5accf704e0118'),
(362, 84, 'studio_videos_1_studio_video_related_url', 'https://vimeo.com/244749306'),
(363, 84, '_studio_videos_1_studio_video_related_url', 'field_5accf64ae0116'),
(364, 84, 'studio_videos_1_studio_video_related_thumbnail', '81'),
(365, 84, '_studio_videos_1_studio_video_related_thumbnail', 'field_5accf6cae0117'),
(366, 84, 'studio_videos_1_studio_video_related_caption', 'Going through the archives.'),
(367, 84, '_studio_videos_1_studio_video_related_caption', 'field_5accf704e0118'),
(368, 84, 'studio_videos_2_studio_video_related_url', 'https://vimeo.com/249770248'),
(369, 84, '_studio_videos_2_studio_video_related_url', 'field_5accf64ae0116'),
(370, 84, 'studio_videos_2_studio_video_related_thumbnail', '82'),
(371, 84, '_studio_videos_2_studio_video_related_thumbnail', 'field_5accf6cae0117'),
(372, 84, 'studio_videos_2_studio_video_related_caption', 'Technique and process: ink to paper.'),
(373, 84, '_studio_videos_2_studio_video_related_caption', 'field_5accf704e0118'),
(374, 84, 'studio_main_video_caption', ''),
(375, 84, '_studio_main_video_caption', 'field_5acd11915e5a0'),
(376, 52, 'studio_related_videos_0_studio_related_video_url', 'https://vimeo.com/249770248'),
(377, 52, '_studio_related_videos_0_studio_related_video_url', 'field_5accf64ae0116'),
(378, 52, 'studio_related_videos_0_studio_related_video_thumbnail', '83'),
(379, 52, '_studio_related_videos_0_studio_related_video_thumbnail', 'field_5accf6cae0117'),
(380, 52, 'studio_related_videos_0_studio_related_video_caption', 'The therapy of drawing.'),
(381, 52, '_studio_related_videos_0_studio_related_video_caption', 'field_5accf704e0118'),
(382, 52, 'studio_related_videos_1_studio_related_video_url', 'https://vimeo.com/244749533'),
(383, 52, '_studio_related_videos_1_studio_related_video_url', 'field_5accf64ae0116'),
(384, 52, 'studio_related_videos_1_studio_related_video_thumbnail', '81'),
(385, 52, '_studio_related_videos_1_studio_related_video_thumbnail', 'field_5accf6cae0117'),
(386, 52, 'studio_related_videos_1_studio_related_video_caption', 'Going through the archives.'),
(387, 52, '_studio_related_videos_1_studio_related_video_caption', 'field_5accf704e0118'),
(388, 52, 'studio_related_videos_2_studio_related_video_url', 'https://vimeo.com/244749306'),
(389, 52, '_studio_related_videos_2_studio_related_video_url', 'field_5accf64ae0116'),
(390, 52, 'studio_related_videos_2_studio_related_video_thumbnail', '82'),
(391, 52, '_studio_related_videos_2_studio_related_video_thumbnail', 'field_5accf6cae0117'),
(392, 52, 'studio_related_videos_2_studio_related_video_caption', 'Technique and process: ink to paper.'),
(393, 52, '_studio_related_videos_2_studio_related_video_caption', 'field_5accf704e0118'),
(394, 52, 'studio_related_videos', '3'),
(395, 52, '_studio_related_videos', 'field_5accf625e0115'),
(396, 85, 'studio_main_video', 'https://vimeo.com/245236016'),
(397, 85, '_studio_main_video', 'field_5accb52e890ab'),
(398, 85, 'studio_visit_description', 'Meet the artist and experience the studio in person. Contact gallery representative Phyllis Vanorden to set up an appointment.'),
(399, 85, '_studio_visit_description', 'field_5accb5e2890ad'),
(400, 85, 'studio_visit_cta_link', ''),
(401, 85, '_studio_visit_cta_link', 'field_5accb604890af'),
(402, 85, 'studio_visit_cta_text', 'Contact »'),
(403, 85, '_studio_visit_cta_text', 'field_5accb5f3890ae'),
(404, 85, 'studio_visit_headline', 'Schedule a Visit:'),
(405, 85, '_studio_visit_headline', 'field_5accddbd0baff'),
(406, 85, 'studio_videos', '3'),
(407, 85, '_studio_videos', 'field_5accf625e0115'),
(408, 85, 'studio_progress_header', 'In Progress'),
(409, 85, '_studio_progress_header', 'field_5accfea1e011c'),
(410, 85, 'studio_progress_background_image', '73'),
(411, 85, '_studio_progress_background_image', 'field_5accfe88e011b'),
(412, 85, 'studio_progress_slideshow_shortcode', ''),
(413, 85, '_studio_progress_slideshow_shortcode', 'field_5accfebde011d'),
(414, 85, 'studio_videos_0_studio_video_related_url', 'https://vimeo.com/244749533'),
(415, 85, '_studio_videos_0_studio_video_related_url', 'field_5accf64ae0116'),
(416, 85, 'studio_videos_0_studio_video_related_thumbnail', '83'),
(417, 85, '_studio_videos_0_studio_video_related_thumbnail', 'field_5accf6cae0117'),
(418, 85, 'studio_videos_0_studio_video_related_caption', 'The therapy of drawing.'),
(419, 85, '_studio_videos_0_studio_video_related_caption', 'field_5accf704e0118'),
(420, 85, 'studio_videos_1_studio_video_related_url', 'https://vimeo.com/244749306'),
(421, 85, '_studio_videos_1_studio_video_related_url', 'field_5accf64ae0116'),
(422, 85, 'studio_videos_1_studio_video_related_thumbnail', '81'),
(423, 85, '_studio_videos_1_studio_video_related_thumbnail', 'field_5accf6cae0117'),
(424, 85, 'studio_videos_1_studio_video_related_caption', 'Going through the archives.'),
(425, 85, '_studio_videos_1_studio_video_related_caption', 'field_5accf704e0118'),
(426, 85, 'studio_videos_2_studio_video_related_url', 'https://vimeo.com/249770248'),
(427, 85, '_studio_videos_2_studio_video_related_url', 'field_5accf64ae0116'),
(428, 85, 'studio_videos_2_studio_video_related_thumbnail', '82'),
(429, 85, '_studio_videos_2_studio_video_related_thumbnail', 'field_5accf6cae0117'),
(430, 85, 'studio_videos_2_studio_video_related_caption', 'Technique and process: ink to paper.'),
(431, 85, '_studio_videos_2_studio_video_related_caption', 'field_5accf704e0118'),
(432, 85, 'studio_main_video_caption', ''),
(433, 85, '_studio_main_video_caption', 'field_5acd11915e5a0'),
(434, 85, 'studio_related_videos_0_studio_related_video_url', 'https://vimeo.com/249770248'),
(435, 85, '_studio_related_videos_0_studio_related_video_url', 'field_5accf64ae0116'),
(436, 85, 'studio_related_videos_0_studio_related_video_thumbnail', '83'),
(437, 85, '_studio_related_videos_0_studio_related_video_thumbnail', 'field_5accf6cae0117'),
(438, 85, 'studio_related_videos_0_studio_related_video_caption', 'The therapy of drawing.'),
(439, 85, '_studio_related_videos_0_studio_related_video_caption', 'field_5accf704e0118'),
(440, 85, 'studio_related_videos_1_studio_related_video_url', 'https://vimeo.com/244749533'),
(441, 85, '_studio_related_videos_1_studio_related_video_url', 'field_5accf64ae0116'),
(442, 85, 'studio_related_videos_1_studio_related_video_thumbnail', '81'),
(443, 85, '_studio_related_videos_1_studio_related_video_thumbnail', 'field_5accf6cae0117'),
(444, 85, 'studio_related_videos_1_studio_related_video_caption', 'Going through the archives.'),
(445, 85, '_studio_related_videos_1_studio_related_video_caption', 'field_5accf704e0118'),
(446, 85, 'studio_related_videos_2_studio_related_video_url', 'https://vimeo.com/244749306'),
(447, 85, '_studio_related_videos_2_studio_related_video_url', 'field_5accf64ae0116'),
(448, 85, 'studio_related_videos_2_studio_related_video_thumbnail', '82'),
(449, 85, '_studio_related_videos_2_studio_related_video_thumbnail', 'field_5accf6cae0117'),
(450, 85, 'studio_related_videos_2_studio_related_video_caption', 'Technique and process: ink to paper.'),
(451, 85, '_studio_related_videos_2_studio_related_video_caption', 'field_5accf704e0118'),
(452, 85, 'studio_related_videos', '3'),
(453, 85, '_studio_related_videos', 'field_5accf625e0115'),
(454, 87, '_edit_last', '1'),
(455, 87, '_edit_lock', '1523565351:1'),
(456, 88, '_edit_last', '1'),
(457, 88, '_edit_lock', '1523644626:1'),
(458, 87, 'news_article_date', 'May 12th, 2018'),
(459, 87, '_news_article_date', 'field_5acd1db05e352'),
(460, 87, 'news_article_excerpt', ''),
(461, 87, '_news_article_excerpt', 'field_5acd1dcd5e353'),
(462, 87, 'news_article_url', 'https://providenceartclub.org/galleries/'),
(463, 87, '_news_article_url', 'field_5acd1e1b5e354'),
(464, 92, '_edit_last', '1'),
(465, 92, '_edit_lock', '1523456317:1'),
(466, 92, '_wp_page_template', 'default'),
(475, 96, '_edit_last', '1'),
(476, 96, '_edit_lock', '1523980362:1'),
(477, 96, '_wp_page_template', 'templates/template-press-and-events.php'),
(478, 97, '_menu_item_type', 'post_type'),
(479, 97, '_menu_item_menu_item_parent', '0'),
(480, 97, '_menu_item_object_id', '96'),
(481, 97, '_menu_item_object', 'page'),
(482, 97, '_menu_item_target', ''),
(483, 97, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(484, 97, '_menu_item_xfn', ''),
(485, 97, '_menu_item_url', ''),
(486, 99, '_wp_attached_file', '2018/04/morris-nathanson-providence-art-club-retrospective-news-article.jpg'),
(487, 99, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:540;s:6:\"height\";i:366;s:4:\"file\";s:75:\"2018/04/morris-nathanson-providence-art-club-retrospective-news-article.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:75:\"morris-nathanson-providence-art-club-retrospective-news-article-150x102.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:102;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:75:\"morris-nathanson-providence-art-club-retrospective-news-article-300x203.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:203;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:75:\"morris-nathanson-providence-art-club-retrospective-news-article-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:75:\"morris-nathanson-providence-art-club-retrospective-news-article-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:75:\"morris-nathanson-providence-art-club-retrospective-news-article-300x203.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:203;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:75:\"morris-nathanson-providence-art-club-retrospective-news-article-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:75:\"morris-nathanson-providence-art-club-retrospective-news-article-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:75:\"morris-nathanson-providence-art-club-retrospective-news-article-300x203.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:203;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:75:\"morris-nathanson-providence-art-club-retrospective-news-article-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(488, 87, '_thumbnail_id', '99'),
(489, 100, '_edit_last', '1'),
(490, 100, '_edit_lock', '1523629730:1'),
(491, 100, 'news_article_date', 'May 21st, 2018'),
(492, 100, '_news_article_date', 'field_5acd1db05e352'),
(493, 100, 'news_article_url', 'http://www.providencejournal.com/news/20180326/trinity-rep-announces-3-local-pell-award-winners'),
(494, 100, '_news_article_url', 'field_5acd1e1b5e354'),
(495, 101, '_wp_attached_file', '2018/04/2018-rhode-island-pell-grant-waterfire-arts-center.jpg'),
(496, 101, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:540;s:6:\"height\";i:366;s:4:\"file\";s:62:\"2018/04/2018-rhode-island-pell-grant-waterfire-arts-center.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:62:\"2018-rhode-island-pell-grant-waterfire-arts-center-150x102.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:102;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:62:\"2018-rhode-island-pell-grant-waterfire-arts-center-300x203.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:203;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:62:\"2018-rhode-island-pell-grant-waterfire-arts-center-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:62:\"2018-rhode-island-pell-grant-waterfire-arts-center-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:62:\"2018-rhode-island-pell-grant-waterfire-arts-center-300x203.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:203;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:62:\"2018-rhode-island-pell-grant-waterfire-arts-center-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:62:\"2018-rhode-island-pell-grant-waterfire-arts-center-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:62:\"2018-rhode-island-pell-grant-waterfire-arts-center-300x203.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:203;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:62:\"2018-rhode-island-pell-grant-waterfire-arts-center-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(497, 102, '_wp_attached_file', '2018/04/morris-nathanson-pawtucket-bridge-lighting-ceremony.jpg'),
(498, 102, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:540;s:6:\"height\";i:366;s:4:\"file\";s:63:\"2018/04/morris-nathanson-pawtucket-bridge-lighting-ceremony.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:63:\"morris-nathanson-pawtucket-bridge-lighting-ceremony-150x102.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:102;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:63:\"morris-nathanson-pawtucket-bridge-lighting-ceremony-300x203.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:203;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:63:\"morris-nathanson-pawtucket-bridge-lighting-ceremony-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:63:\"morris-nathanson-pawtucket-bridge-lighting-ceremony-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:63:\"morris-nathanson-pawtucket-bridge-lighting-ceremony-300x203.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:203;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:63:\"morris-nathanson-pawtucket-bridge-lighting-ceremony-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:63:\"morris-nathanson-pawtucket-bridge-lighting-ceremony-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:63:\"morris-nathanson-pawtucket-bridge-lighting-ceremony-300x203.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:203;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:63:\"morris-nathanson-pawtucket-bridge-lighting-ceremony-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(499, 100, '_thumbnail_id', '101'),
(500, 103, '_edit_last', '1'),
(501, 103, '_edit_lock', '1523983284:1'),
(502, 103, 'news_article_date', 'Sept. 8th, 2017'),
(503, 103, '_news_article_date', 'field_5acd1db05e352'),
(504, 103, 'news_article_url', 'http://motifri.com/morris-nathanson/'),
(505, 103, '_news_article_url', 'field_5acd1e1b5e354'),
(506, 103, '_thumbnail_id', '102'),
(507, 5, 'home_featured_section_header', 'Featured Happenings'),
(508, 5, '_home_featured_section_header', 'field_5ace2f1f98fca'),
(509, 5, 'home_featured_0_home_featured_article', '103'),
(510, 5, '_home_featured_0_home_featured_article', 'field_5ace2fa998fcc'),
(511, 5, 'home_featured_1_home_featured_article', '100'),
(512, 5, '_home_featured_1_home_featured_article', 'field_5ace2fa998fcc'),
(513, 5, 'home_featured_2_home_featured_article', '87'),
(514, 5, '_home_featured_2_home_featured_article', 'field_5ace2fa998fcc'),
(515, 5, 'home_featured', '6'),
(516, 5, '_home_featured', 'field_5ace2f7e98fcb'),
(517, 108, 'home_banner_image', '19'),
(518, 108, '_home_banner_image', 'field_5ac7df22549dc'),
(519, 108, 'home_banner_headline', 'Artist and Designer.'),
(520, 108, '_home_banner_headline', 'field_5acb54f2e6861'),
(521, 108, 'home_banner_cta_text', 'See the studio »'),
(522, 108, '_home_banner_cta_text', 'field_5acb5515e6862'),
(523, 108, 'home_banner_cta_link', ''),
(524, 108, '_home_banner_cta_link', 'field_5acb5532e6863'),
(525, 108, 'home_cta_background_image', '17'),
(526, 108, '_home_cta_background_image', 'field_5acb90daf1058'),
(527, 108, 'home_cta_text', 'View the work »'),
(528, 108, '_home_cta_text', 'field_5acb90c3f1057'),
(529, 108, 'home_cta_link', ''),
(530, 108, '_home_cta_link', 'field_5acb9114f1059'),
(531, 108, 'home_quote_background_image', '21'),
(532, 108, '_home_quote_background_image', 'field_5acbcda4a152e'),
(533, 108, 'home_quote_text', '“What is unique about being a designer and also an artist, is that you are always composing and designing. It\'s like breathing. It\'s inherent. It\'s like musicians who are always humming when they walk down the street and don\'t even know they are doing it.\"'),
(534, 108, '_home_quote_text', 'field_5acbcdb6a152f'),
(535, 108, 'home_featured_section_header', 'Featured Happenings'),
(536, 108, '_home_featured_section_header', 'field_5ace2f1f98fca'),
(537, 108, 'home_featured_0_home_featured_article', '103'),
(538, 108, '_home_featured_0_home_featured_article', 'field_5ace2fa998fcc'),
(539, 108, 'home_featured_1_home_featured_article', '100'),
(540, 108, '_home_featured_1_home_featured_article', 'field_5ace2fa998fcc'),
(541, 108, 'home_featured_2_home_featured_article', '87'),
(542, 108, '_home_featured_2_home_featured_article', 'field_5ace2fa998fcc'),
(543, 108, 'home_featured', '3'),
(544, 108, '_home_featured', 'field_5ace2f7e98fcb'),
(572, 112, '_edit_last', '1'),
(573, 112, '_wp_page_template', 'templates/template-stories.php'),
(582, 112, '_edit_lock', '1524012332:1'),
(583, 116, '_edit_last', '1'),
(584, 116, '_edit_lock', '1524017618:1'),
(585, 124, '_edit_last', '1'),
(586, 124, '_edit_lock', '1523984030:1'),
(587, 124, 'story_year', '2006'),
(588, 124, '_story_year', 'field_5acf90b3e9f5b'),
(589, 124, 'story_quote', '“One of the best creations I was commissioned for was the assemblage in the Riverfront lobby—I really, really enjoyed that.”'),
(590, 124, '_story_quote', 'field_5acf90dee9f5c'),
(591, 124, 'story_map_image', ''),
(592, 124, '_story_map_image', 'field_5acf9112e9f5e'),
(593, 124, 'intro_vertical_image', ''),
(594, 124, '_intro_vertical_image', 'field_5acf9130e9f5f'),
(595, 124, 'horitonzal_image_1', ''),
(596, 124, '_horitonzal_image_1', 'field_5acf9155e9f60'),
(597, 124, 'story_content', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ornare quam ut turpis elementum, sit amet rutrum mi dignissim.\r\n\r\nNunc euismod vehicula magna, non sollicitudin ex condimentum sit amet. Morbi eu eleifend sem. Fusce sed mattis mi, non lacinia dolor.\r\n\r\nSed non nulla ac ipsum pretium tempor id eu nisl. Cras lacinia eleifend imperdiet. Praesent quis elit augue. Vestibulum ac volutpat elit, molestie commodo tellus.'),
(598, 124, '_story_content', 'field_5acf916ae9f62'),
(599, 124, 'horitonzal_image_2', ''),
(600, 124, '_horitonzal_image_2', 'field_5acf9163e9f61'),
(601, 125, 'studio_main_video', 'https://vimeo.com/245236016'),
(602, 125, '_studio_main_video', 'field_5accb52e890ab'),
(603, 125, 'studio_visit_description', 'Meet the artist and experience the studio in person. Contact gallery representative Phyllis Van Orden to set up an appointment.'),
(604, 125, '_studio_visit_description', 'field_5accb5e2890ad'),
(605, 125, 'studio_visit_cta_link', ''),
(606, 125, '_studio_visit_cta_link', 'field_5accb604890af'),
(607, 125, 'studio_visit_cta_text', 'Contact »'),
(608, 125, '_studio_visit_cta_text', 'field_5accb5f3890ae'),
(609, 125, 'studio_visit_headline', 'Schedule a Visit:'),
(610, 125, '_studio_visit_headline', 'field_5accddbd0baff'),
(611, 125, 'studio_videos', '3'),
(612, 125, '_studio_videos', 'field_5accf625e0115'),
(613, 125, 'studio_progress_header', 'In Progress'),
(614, 125, '_studio_progress_header', 'field_5accfea1e011c'),
(615, 125, 'studio_progress_background_image', '73'),
(616, 125, '_studio_progress_background_image', 'field_5accfe88e011b'),
(617, 125, 'studio_progress_slideshow_shortcode', ''),
(618, 125, '_studio_progress_slideshow_shortcode', 'field_5accfebde011d'),
(619, 125, 'studio_videos_0_studio_video_related_url', 'https://vimeo.com/244749533'),
(620, 125, '_studio_videos_0_studio_video_related_url', 'field_5accf64ae0116'),
(621, 125, 'studio_videos_0_studio_video_related_thumbnail', '83'),
(622, 125, '_studio_videos_0_studio_video_related_thumbnail', 'field_5accf6cae0117'),
(623, 125, 'studio_videos_0_studio_video_related_caption', 'The therapy of drawing.'),
(624, 125, '_studio_videos_0_studio_video_related_caption', 'field_5accf704e0118'),
(625, 125, 'studio_videos_1_studio_video_related_url', 'https://vimeo.com/244749306'),
(626, 125, '_studio_videos_1_studio_video_related_url', 'field_5accf64ae0116'),
(627, 125, 'studio_videos_1_studio_video_related_thumbnail', '81'),
(628, 125, '_studio_videos_1_studio_video_related_thumbnail', 'field_5accf6cae0117'),
(629, 125, 'studio_videos_1_studio_video_related_caption', 'Going through the archives.'),
(630, 125, '_studio_videos_1_studio_video_related_caption', 'field_5accf704e0118'),
(631, 125, 'studio_videos_2_studio_video_related_url', 'https://vimeo.com/249770248'),
(632, 125, '_studio_videos_2_studio_video_related_url', 'field_5accf64ae0116'),
(633, 125, 'studio_videos_2_studio_video_related_thumbnail', '82'),
(634, 125, '_studio_videos_2_studio_video_related_thumbnail', 'field_5accf6cae0117'),
(635, 125, 'studio_videos_2_studio_video_related_caption', 'Technique and process: ink to paper.'),
(636, 125, '_studio_videos_2_studio_video_related_caption', 'field_5accf704e0118'),
(637, 125, 'studio_main_video_caption', ''),
(638, 125, '_studio_main_video_caption', 'field_5acd11915e5a0'),
(639, 125, 'studio_related_videos_0_studio_related_video_url', 'https://vimeo.com/249770248'),
(640, 125, '_studio_related_videos_0_studio_related_video_url', 'field_5accf64ae0116'),
(641, 125, 'studio_related_videos_0_studio_related_video_thumbnail', '83'),
(642, 125, '_studio_related_videos_0_studio_related_video_thumbnail', 'field_5accf6cae0117'),
(643, 125, 'studio_related_videos_0_studio_related_video_caption', 'The therapy of drawing.'),
(644, 125, '_studio_related_videos_0_studio_related_video_caption', 'field_5accf704e0118'),
(645, 125, 'studio_related_videos_1_studio_related_video_url', 'https://vimeo.com/244749533'),
(646, 125, '_studio_related_videos_1_studio_related_video_url', 'field_5accf64ae0116'),
(647, 125, 'studio_related_videos_1_studio_related_video_thumbnail', '81'),
(648, 125, '_studio_related_videos_1_studio_related_video_thumbnail', 'field_5accf6cae0117'),
(649, 125, 'studio_related_videos_1_studio_related_video_caption', 'Going through the archives.'),
(650, 125, '_studio_related_videos_1_studio_related_video_caption', 'field_5accf704e0118'),
(651, 125, 'studio_related_videos_2_studio_related_video_url', 'https://vimeo.com/244749306'),
(652, 125, '_studio_related_videos_2_studio_related_video_url', 'field_5accf64ae0116'),
(653, 125, 'studio_related_videos_2_studio_related_video_thumbnail', '82'),
(654, 125, '_studio_related_videos_2_studio_related_video_thumbnail', 'field_5accf6cae0117'),
(655, 125, 'studio_related_videos_2_studio_related_video_caption', 'Technique and process: ink to paper.'),
(656, 125, '_studio_related_videos_2_studio_related_video_caption', 'field_5accf704e0118'),
(657, 125, 'studio_related_videos', '3'),
(658, 125, '_studio_related_videos', 'field_5accf625e0115'),
(659, 52, 'studi_visit_contact_shortcode', '[contact-form-7 id=\"78\" title=\"Contact form 1\"]'),
(660, 52, '_studi_visit_contact_shortcode', 'field_5acfa23e6ce2f'),
(661, 129, 'studio_main_video', 'https://vimeo.com/245236016'),
(662, 129, '_studio_main_video', 'field_5accb52e890ab'),
(663, 129, 'studio_visit_description', 'Meet the artist and experience the studio in person. Contact gallery representative Phyllis Van Orden to set up an appointment.'),
(664, 129, '_studio_visit_description', 'field_5accb5e2890ad'),
(665, 129, 'studio_visit_cta_link', ''),
(666, 129, '_studio_visit_cta_link', 'field_5accb604890af'),
(667, 129, 'studio_visit_cta_text', 'Contact »'),
(668, 129, '_studio_visit_cta_text', 'field_5accb5f3890ae'),
(669, 129, 'studio_visit_headline', 'Schedule a Visit:'),
(670, 129, '_studio_visit_headline', 'field_5accddbd0baff'),
(671, 129, 'studio_videos', '3'),
(672, 129, '_studio_videos', 'field_5accf625e0115'),
(673, 129, 'studio_progress_header', 'In Progress'),
(674, 129, '_studio_progress_header', 'field_5accfea1e011c'),
(675, 129, 'studio_progress_background_image', '73'),
(676, 129, '_studio_progress_background_image', 'field_5accfe88e011b'),
(677, 129, 'studio_progress_slideshow_shortcode', ''),
(678, 129, '_studio_progress_slideshow_shortcode', 'field_5accfebde011d'),
(679, 129, 'studio_videos_0_studio_video_related_url', 'https://vimeo.com/244749533'),
(680, 129, '_studio_videos_0_studio_video_related_url', 'field_5accf64ae0116'),
(681, 129, 'studio_videos_0_studio_video_related_thumbnail', '83'),
(682, 129, '_studio_videos_0_studio_video_related_thumbnail', 'field_5accf6cae0117'),
(683, 129, 'studio_videos_0_studio_video_related_caption', 'The therapy of drawing.'),
(684, 129, '_studio_videos_0_studio_video_related_caption', 'field_5accf704e0118'),
(685, 129, 'studio_videos_1_studio_video_related_url', 'https://vimeo.com/244749306'),
(686, 129, '_studio_videos_1_studio_video_related_url', 'field_5accf64ae0116'),
(687, 129, 'studio_videos_1_studio_video_related_thumbnail', '81'),
(688, 129, '_studio_videos_1_studio_video_related_thumbnail', 'field_5accf6cae0117'),
(689, 129, 'studio_videos_1_studio_video_related_caption', 'Going through the archives.'),
(690, 129, '_studio_videos_1_studio_video_related_caption', 'field_5accf704e0118'),
(691, 129, 'studio_videos_2_studio_video_related_url', 'https://vimeo.com/249770248'),
(692, 129, '_studio_videos_2_studio_video_related_url', 'field_5accf64ae0116'),
(693, 129, 'studio_videos_2_studio_video_related_thumbnail', '82'),
(694, 129, '_studio_videos_2_studio_video_related_thumbnail', 'field_5accf6cae0117'),
(695, 129, 'studio_videos_2_studio_video_related_caption', 'Technique and process: ink to paper.'),
(696, 129, '_studio_videos_2_studio_video_related_caption', 'field_5accf704e0118'),
(697, 129, 'studio_main_video_caption', ''),
(698, 129, '_studio_main_video_caption', 'field_5acd11915e5a0'),
(699, 129, 'studio_related_videos_0_studio_related_video_url', 'https://vimeo.com/249770248'),
(700, 129, '_studio_related_videos_0_studio_related_video_url', 'field_5accf64ae0116'),
(701, 129, 'studio_related_videos_0_studio_related_video_thumbnail', '83'),
(702, 129, '_studio_related_videos_0_studio_related_video_thumbnail', 'field_5accf6cae0117'),
(703, 129, 'studio_related_videos_0_studio_related_video_caption', 'The therapy of drawing.'),
(704, 129, '_studio_related_videos_0_studio_related_video_caption', 'field_5accf704e0118'),
(705, 129, 'studio_related_videos_1_studio_related_video_url', 'https://vimeo.com/244749533'),
(706, 129, '_studio_related_videos_1_studio_related_video_url', 'field_5accf64ae0116'),
(707, 129, 'studio_related_videos_1_studio_related_video_thumbnail', '81'),
(708, 129, '_studio_related_videos_1_studio_related_video_thumbnail', 'field_5accf6cae0117'),
(709, 129, 'studio_related_videos_1_studio_related_video_caption', 'Going through the archives.'),
(710, 129, '_studio_related_videos_1_studio_related_video_caption', 'field_5accf704e0118'),
(711, 129, 'studio_related_videos_2_studio_related_video_url', 'https://vimeo.com/244749306'),
(712, 129, '_studio_related_videos_2_studio_related_video_url', 'field_5accf64ae0116'),
(713, 129, 'studio_related_videos_2_studio_related_video_thumbnail', '82'),
(714, 129, '_studio_related_videos_2_studio_related_video_thumbnail', 'field_5accf6cae0117'),
(715, 129, 'studio_related_videos_2_studio_related_video_caption', 'Technique and process: ink to paper.'),
(716, 129, '_studio_related_videos_2_studio_related_video_caption', 'field_5accf704e0118'),
(717, 129, 'studio_related_videos', '3'),
(718, 129, '_studio_related_videos', 'field_5accf625e0115'),
(719, 129, 'studi_visit_contact_shortcode', '[contact-form-7 id=\"78\" title=\"Contact form 1\"]'),
(720, 129, '_studi_visit_contact_shortcode', 'field_5acfa23e6ce2f'),
(721, 130, '_wp_attached_file', '2018/04/2018-rhode-island-pell-grant-waterfire-arts-center2.jpg'),
(722, 130, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:307;s:6:\"height\";i:396;s:4:\"file\";s:63:\"2018/04/2018-rhode-island-pell-grant-waterfire-arts-center2.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:63:\"2018-rhode-island-pell-grant-waterfire-arts-center2-116x150.jpg\";s:5:\"width\";i:116;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:63:\"2018-rhode-island-pell-grant-waterfire-arts-center2-233x300.jpg\";s:5:\"width\";i:233;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:63:\"2018-rhode-island-pell-grant-waterfire-arts-center2-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:63:\"2018-rhode-island-pell-grant-waterfire-arts-center2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:63:\"2018-rhode-island-pell-grant-waterfire-arts-center2-300x387.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:387;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:63:\"2018-rhode-island-pell-grant-waterfire-arts-center2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:63:\"2018-rhode-island-pell-grant-waterfire-arts-center2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:63:\"2018-rhode-island-pell-grant-waterfire-arts-center2-300x387.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:387;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:63:\"2018-rhode-island-pell-grant-waterfire-arts-center2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(723, 131, '_wp_attached_file', '2018/04/2018-rhode-island-pell-grant-waterfire-arts-center3.jpg'),
(724, 131, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:307;s:6:\"height\";i:294;s:4:\"file\";s:63:\"2018/04/2018-rhode-island-pell-grant-waterfire-arts-center3.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:63:\"2018-rhode-island-pell-grant-waterfire-arts-center3-150x144.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:144;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:63:\"2018-rhode-island-pell-grant-waterfire-arts-center3-300x287.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:287;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:63:\"2018-rhode-island-pell-grant-waterfire-arts-center3-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:63:\"2018-rhode-island-pell-grant-waterfire-arts-center3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:63:\"2018-rhode-island-pell-grant-waterfire-arts-center3-300x287.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:287;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:63:\"2018-rhode-island-pell-grant-waterfire-arts-center3-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:63:\"2018-rhode-island-pell-grant-waterfire-arts-center3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:63:\"2018-rhode-island-pell-grant-waterfire-arts-center3-300x287.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:287;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:63:\"2018-rhode-island-pell-grant-waterfire-arts-center3-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(725, 132, '_wp_attached_file', '2018/04/morris-nathanson-pawtucket-bridge-lighting-ceremony2.jpg'),
(726, 132, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:307;s:6:\"height\";i:396;s:4:\"file\";s:64:\"2018/04/morris-nathanson-pawtucket-bridge-lighting-ceremony2.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:64:\"morris-nathanson-pawtucket-bridge-lighting-ceremony2-116x150.jpg\";s:5:\"width\";i:116;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:64:\"morris-nathanson-pawtucket-bridge-lighting-ceremony2-233x300.jpg\";s:5:\"width\";i:233;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:64:\"morris-nathanson-pawtucket-bridge-lighting-ceremony2-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:64:\"morris-nathanson-pawtucket-bridge-lighting-ceremony2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:64:\"morris-nathanson-pawtucket-bridge-lighting-ceremony2-300x387.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:387;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:64:\"morris-nathanson-pawtucket-bridge-lighting-ceremony2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:64:\"morris-nathanson-pawtucket-bridge-lighting-ceremony2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:64:\"morris-nathanson-pawtucket-bridge-lighting-ceremony2-300x387.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:387;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:64:\"morris-nathanson-pawtucket-bridge-lighting-ceremony2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(727, 133, '_wp_attached_file', '2018/04/morris-nathanson-pawtucket-bridge-lighting-ceremony3.jpg'),
(728, 133, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:307;s:6:\"height\";i:294;s:4:\"file\";s:64:\"2018/04/morris-nathanson-pawtucket-bridge-lighting-ceremony3.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:64:\"morris-nathanson-pawtucket-bridge-lighting-ceremony3-150x144.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:144;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:64:\"morris-nathanson-pawtucket-bridge-lighting-ceremony3-300x287.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:287;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:64:\"morris-nathanson-pawtucket-bridge-lighting-ceremony3-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:64:\"morris-nathanson-pawtucket-bridge-lighting-ceremony3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:64:\"morris-nathanson-pawtucket-bridge-lighting-ceremony3-300x287.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:287;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:64:\"morris-nathanson-pawtucket-bridge-lighting-ceremony3-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:64:\"morris-nathanson-pawtucket-bridge-lighting-ceremony3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:64:\"morris-nathanson-pawtucket-bridge-lighting-ceremony3-300x287.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:287;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:64:\"morris-nathanson-pawtucket-bridge-lighting-ceremony3-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(729, 134, '_wp_attached_file', '2018/04/morris-nathanson-providence-art-club-retrospective-news-article2.jpg'),
(730, 134, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:307;s:6:\"height\";i:396;s:4:\"file\";s:76:\"2018/04/morris-nathanson-providence-art-club-retrospective-news-article2.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:76:\"morris-nathanson-providence-art-club-retrospective-news-article2-116x150.jpg\";s:5:\"width\";i:116;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:76:\"morris-nathanson-providence-art-club-retrospective-news-article2-233x300.jpg\";s:5:\"width\";i:233;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:76:\"morris-nathanson-providence-art-club-retrospective-news-article2-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:76:\"morris-nathanson-providence-art-club-retrospective-news-article2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:76:\"morris-nathanson-providence-art-club-retrospective-news-article2-300x387.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:387;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:76:\"morris-nathanson-providence-art-club-retrospective-news-article2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:76:\"morris-nathanson-providence-art-club-retrospective-news-article2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:76:\"morris-nathanson-providence-art-club-retrospective-news-article2-300x387.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:387;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:76:\"morris-nathanson-providence-art-club-retrospective-news-article2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(731, 135, '_wp_attached_file', '2018/04/morris-nathanson-providence-art-club-retrospective-news-article3.jpg'),
(732, 135, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:307;s:6:\"height\";i:294;s:4:\"file\";s:76:\"2018/04/morris-nathanson-providence-art-club-retrospective-news-article3.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:76:\"morris-nathanson-providence-art-club-retrospective-news-article3-150x144.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:144;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:76:\"morris-nathanson-providence-art-club-retrospective-news-article3-300x287.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:287;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:76:\"morris-nathanson-providence-art-club-retrospective-news-article3-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:76:\"morris-nathanson-providence-art-club-retrospective-news-article3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:76:\"morris-nathanson-providence-art-club-retrospective-news-article3-300x287.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:287;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:76:\"morris-nathanson-providence-art-club-retrospective-news-article3-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:76:\"morris-nathanson-providence-art-club-retrospective-news-article3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:76:\"morris-nathanson-providence-art-club-retrospective-news-article3-300x287.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:287;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:76:\"morris-nathanson-providence-art-club-retrospective-news-article3-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(733, 103, 'news_article_square_image', '133'),
(734, 103, '_news_article_square_image', 'field_5acfa063547c1'),
(735, 103, 'news_article_vertical_image', '132'),
(736, 103, '_news_article_vertical_image', 'field_5acfa087547c2'),
(737, 100, 'news_article_square_image', '131'),
(738, 100, '_news_article_square_image', 'field_5acfa063547c1'),
(739, 100, 'news_article_vertical_image', '130'),
(740, 100, '_news_article_vertical_image', 'field_5acfa087547c2'),
(741, 87, 'news_article_square_image', '135'),
(742, 87, '_news_article_square_image', 'field_5acfa063547c1'),
(743, 87, 'news_article_vertical_image', '134'),
(744, 87, '_news_article_vertical_image', 'field_5acfa087547c2'),
(745, 136, 'home_banner_image', '19'),
(746, 136, '_home_banner_image', 'field_5ac7df22549dc'),
(747, 136, 'home_banner_headline', 'Artist and Designer.'),
(748, 136, '_home_banner_headline', 'field_5acb54f2e6861'),
(749, 136, 'home_banner_cta_text', 'See the studio »'),
(750, 136, '_home_banner_cta_text', 'field_5acb5515e6862'),
(751, 136, 'home_banner_cta_link', '52'),
(752, 136, '_home_banner_cta_link', 'field_5acb5532e6863'),
(753, 136, 'home_cta_background_image', '17'),
(754, 136, '_home_cta_background_image', 'field_5acb90daf1058'),
(755, 136, 'home_cta_text', 'View the work »'),
(756, 136, '_home_cta_text', 'field_5acb90c3f1057'),
(757, 136, 'home_cta_link', ''),
(758, 136, '_home_cta_link', 'field_5acb9114f1059'),
(759, 136, 'home_quote_background_image', '21'),
(760, 136, '_home_quote_background_image', 'field_5acbcda4a152e'),
(761, 136, 'home_quote_text', '“What is unique about being a designer and also an artist, is that you are always composing and designing. It\'s like breathing. It\'s inherent. It\'s like musicians who are always humming when they walk down the street and don\'t even know they are doing it.\"'),
(762, 136, '_home_quote_text', 'field_5acbcdb6a152f'),
(763, 136, 'home_featured_section_header', 'Featured Happenings');
INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(764, 136, '_home_featured_section_header', 'field_5ace2f1f98fca'),
(765, 136, 'home_featured_0_home_featured_article', '103'),
(766, 136, '_home_featured_0_home_featured_article', 'field_5ace2fa998fcc'),
(767, 136, 'home_featured_1_home_featured_article', '100'),
(768, 136, '_home_featured_1_home_featured_article', 'field_5ace2fa998fcc'),
(769, 136, 'home_featured_2_home_featured_article', '87'),
(770, 136, '_home_featured_2_home_featured_article', 'field_5ace2fa998fcc'),
(771, 136, 'home_featured', '3'),
(772, 136, '_home_featured', 'field_5ace2f7e98fcb'),
(773, 92, '_wp_trash_meta_status', 'publish'),
(774, 92, '_wp_trash_meta_time', '1523629925'),
(775, 92, '_wp_desired_post_slug', 'contact'),
(776, 29, '_wp_trash_meta_status', 'publish'),
(777, 29, '_wp_trash_meta_time', '1523644438'),
(778, 29, '_wp_desired_post_slug', 'group_5acbaeaecfd92'),
(779, 30, '_wp_trash_meta_status', 'publish'),
(780, 30, '_wp_trash_meta_time', '1523644438'),
(781, 30, '_wp_desired_post_slug', 'field_5acbaeb6ce7fc'),
(782, 31, '_wp_trash_meta_status', 'publish'),
(783, 31, '_wp_trash_meta_time', '1523644438'),
(784, 31, '_wp_desired_post_slug', 'field_5acbaf04ce7fd'),
(785, 32, '_wp_trash_meta_status', 'publish'),
(786, 32, '_wp_trash_meta_time', '1523644438'),
(787, 32, '_wp_desired_post_slug', 'field_5acbaf11ce7fe'),
(788, 33, '_wp_trash_meta_status', 'publish'),
(789, 33, '_wp_trash_meta_time', '1523644438'),
(790, 33, '_wp_desired_post_slug', 'field_5acbaf1cce7ff'),
(791, 138, '_menu_item_type', 'custom'),
(792, 138, '_menu_item_menu_item_parent', '0'),
(793, 138, '_menu_item_object_id', '138'),
(794, 138, '_menu_item_object', 'custom'),
(795, 138, '_menu_item_target', ''),
(796, 138, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(797, 138, '_menu_item_xfn', ''),
(798, 138, '_menu_item_url', '#'),
(799, 138, '_menu_item_orphaned', '1523903252'),
(800, 5, 'home_featured_3_home_featured_article', '103'),
(801, 5, '_home_featured_3_home_featured_article', 'field_5ace2fa998fcc'),
(802, 5, 'home_featured_4_home_featured_article', '100'),
(803, 5, '_home_featured_4_home_featured_article', 'field_5ace2fa998fcc'),
(804, 5, 'home_featured_5_home_featured_article', '87'),
(805, 5, '_home_featured_5_home_featured_article', 'field_5ace2fa998fcc'),
(806, 139, 'home_banner_image', '19'),
(807, 139, '_home_banner_image', 'field_5ac7df22549dc'),
(808, 139, 'home_banner_headline', 'Artist and Designer.'),
(809, 139, '_home_banner_headline', 'field_5acb54f2e6861'),
(810, 139, 'home_banner_cta_text', 'See the studio »'),
(811, 139, '_home_banner_cta_text', 'field_5acb5515e6862'),
(812, 139, 'home_banner_cta_link', '52'),
(813, 139, '_home_banner_cta_link', 'field_5acb5532e6863'),
(814, 139, 'home_cta_background_image', '17'),
(815, 139, '_home_cta_background_image', 'field_5acb90daf1058'),
(816, 139, 'home_cta_text', 'View the work »'),
(817, 139, '_home_cta_text', 'field_5acb90c3f1057'),
(818, 139, 'home_cta_link', ''),
(819, 139, '_home_cta_link', 'field_5acb9114f1059'),
(820, 139, 'home_quote_background_image', '21'),
(821, 139, '_home_quote_background_image', 'field_5acbcda4a152e'),
(822, 139, 'home_quote_text', '“What is unique about being a designer and also an artist, is that you are always composing and designing. It\'s like breathing. It\'s inherent. It\'s like musicians who are always humming when they walk down the street and don\'t even know they are doing it.\"'),
(823, 139, '_home_quote_text', 'field_5acbcdb6a152f'),
(824, 139, 'home_featured_section_header', 'Featured Happenings'),
(825, 139, '_home_featured_section_header', 'field_5ace2f1f98fca'),
(826, 139, 'home_featured_0_home_featured_article', '103'),
(827, 139, '_home_featured_0_home_featured_article', 'field_5ace2fa998fcc'),
(828, 139, 'home_featured_1_home_featured_article', '100'),
(829, 139, '_home_featured_1_home_featured_article', 'field_5ace2fa998fcc'),
(830, 139, 'home_featured_2_home_featured_article', '87'),
(831, 139, '_home_featured_2_home_featured_article', 'field_5ace2fa998fcc'),
(832, 139, 'home_featured', '6'),
(833, 139, '_home_featured', 'field_5ace2f7e98fcb'),
(834, 139, 'home_featured_3_home_featured_article', '103'),
(835, 139, '_home_featured_3_home_featured_article', 'field_5ace2fa998fcc'),
(836, 139, 'home_featured_4_home_featured_article', '100'),
(837, 139, '_home_featured_4_home_featured_article', 'field_5ace2fa998fcc'),
(838, 139, 'home_featured_5_home_featured_article', '87'),
(839, 139, '_home_featured_5_home_featured_article', 'field_5ace2fa998fcc'),
(840, 140, '_menu_item_type', 'custom'),
(841, 140, '_menu_item_menu_item_parent', '145'),
(842, 140, '_menu_item_object_id', '140'),
(843, 140, '_menu_item_object', 'custom'),
(844, 140, '_menu_item_target', ''),
(845, 140, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(846, 140, '_menu_item_xfn', ''),
(847, 140, '_menu_item_url', '#'),
(849, 141, '_menu_item_type', 'custom'),
(850, 141, '_menu_item_menu_item_parent', '145'),
(851, 141, '_menu_item_object_id', '141'),
(852, 141, '_menu_item_object', 'custom'),
(853, 141, '_menu_item_target', ''),
(854, 141, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(855, 141, '_menu_item_xfn', ''),
(856, 141, '_menu_item_url', '#'),
(858, 142, '_menu_item_type', 'custom'),
(859, 142, '_menu_item_menu_item_parent', '145'),
(860, 142, '_menu_item_object_id', '142'),
(861, 142, '_menu_item_object', 'custom'),
(862, 142, '_menu_item_target', ''),
(863, 142, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(864, 142, '_menu_item_xfn', ''),
(865, 142, '_menu_item_url', '#'),
(867, 143, '_menu_item_type', 'custom'),
(868, 143, '_menu_item_menu_item_parent', '145'),
(869, 143, '_menu_item_object_id', '143'),
(870, 143, '_menu_item_object', 'custom'),
(871, 143, '_menu_item_target', ''),
(872, 143, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(873, 143, '_menu_item_xfn', ''),
(874, 143, '_menu_item_url', '#'),
(876, 144, '_menu_item_type', 'custom'),
(877, 144, '_menu_item_menu_item_parent', '145'),
(878, 144, '_menu_item_object_id', '144'),
(879, 144, '_menu_item_object', 'custom'),
(880, 144, '_menu_item_target', ''),
(881, 144, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(882, 144, '_menu_item_xfn', ''),
(883, 144, '_menu_item_url', '#'),
(885, 145, '_menu_item_type', 'custom'),
(886, 145, '_menu_item_menu_item_parent', '0'),
(887, 145, '_menu_item_object_id', '145'),
(888, 145, '_menu_item_object', 'custom'),
(889, 145, '_menu_item_target', ''),
(890, 145, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(891, 145, '_menu_item_xfn', ''),
(892, 145, '_menu_item_url', '#'),
(894, 146, '_menu_item_type', 'post_type'),
(895, 146, '_menu_item_menu_item_parent', '0'),
(896, 146, '_menu_item_object_id', '52'),
(897, 146, '_menu_item_object', 'page'),
(898, 146, '_menu_item_target', ''),
(899, 146, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(900, 146, '_menu_item_xfn', ''),
(901, 146, '_menu_item_url', ''),
(903, 147, '_menu_item_type', 'custom'),
(904, 147, '_menu_item_menu_item_parent', '146'),
(905, 147, '_menu_item_object_id', '147'),
(906, 147, '_menu_item_object', 'custom'),
(907, 147, '_menu_item_target', ''),
(908, 147, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(909, 147, '_menu_item_xfn', ''),
(910, 147, '_menu_item_url', '#'),
(912, 148, '_menu_item_type', 'custom'),
(913, 148, '_menu_item_menu_item_parent', '146'),
(914, 148, '_menu_item_object_id', '148'),
(915, 148, '_menu_item_object', 'custom'),
(916, 148, '_menu_item_target', ''),
(917, 148, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(918, 148, '_menu_item_xfn', ''),
(919, 148, '_menu_item_url', '#'),
(921, 149, '_menu_item_type', 'custom'),
(922, 149, '_menu_item_menu_item_parent', '146'),
(923, 149, '_menu_item_object_id', '149'),
(924, 149, '_menu_item_object', 'custom'),
(925, 149, '_menu_item_target', ''),
(926, 149, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(927, 149, '_menu_item_xfn', ''),
(928, 149, '_menu_item_url', '#'),
(930, 150, '_menu_item_type', 'post_type'),
(931, 150, '_menu_item_menu_item_parent', '0'),
(932, 150, '_menu_item_object_id', '96'),
(933, 150, '_menu_item_object', 'page'),
(934, 150, '_menu_item_target', ''),
(935, 150, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(936, 150, '_menu_item_xfn', ''),
(937, 150, '_menu_item_url', ''),
(939, 151, '_menu_item_type', 'custom'),
(940, 151, '_menu_item_menu_item_parent', '150'),
(941, 151, '_menu_item_object_id', '151'),
(942, 151, '_menu_item_object', 'custom'),
(943, 151, '_menu_item_target', ''),
(944, 151, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(945, 151, '_menu_item_xfn', ''),
(946, 151, '_menu_item_url', '#'),
(948, 152, '_menu_item_type', 'custom'),
(949, 152, '_menu_item_menu_item_parent', '150'),
(950, 152, '_menu_item_object_id', '152'),
(951, 152, '_menu_item_object', 'custom'),
(952, 152, '_menu_item_target', ''),
(953, 152, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(954, 152, '_menu_item_xfn', ''),
(955, 152, '_menu_item_url', '#'),
(957, 153, '_menu_item_type', 'post_type'),
(958, 153, '_menu_item_menu_item_parent', '0'),
(959, 153, '_menu_item_object_id', '112'),
(960, 153, '_menu_item_object', 'page'),
(961, 153, '_menu_item_target', ''),
(962, 153, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(963, 153, '_menu_item_xfn', ''),
(964, 153, '_menu_item_url', ''),
(966, 154, '_menu_item_type', 'post_type'),
(967, 154, '_menu_item_menu_item_parent', '0'),
(968, 154, '_menu_item_object_id', '34'),
(969, 154, '_menu_item_object', 'page'),
(970, 154, '_menu_item_target', ''),
(971, 154, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(972, 154, '_menu_item_xfn', ''),
(973, 154, '_menu_item_url', ''),
(975, 155, '_menu_item_type', 'custom'),
(976, 155, '_menu_item_menu_item_parent', '154'),
(977, 155, '_menu_item_object_id', '155'),
(978, 155, '_menu_item_object', 'custom'),
(979, 155, '_menu_item_target', ''),
(980, 155, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(981, 155, '_menu_item_xfn', ''),
(982, 155, '_menu_item_url', '#'),
(984, 52, 'studio_visit_contact_shortcode', ''),
(985, 52, '_studio_visit_contact_shortcode', 'field_5acfa23e6ce2f'),
(986, 156, 'studio_main_video', 'https://vimeo.com/245236016'),
(987, 156, '_studio_main_video', 'field_5accb52e890ab'),
(988, 156, 'studio_visit_description', 'Meet the artist and experience the studio in person. <br>Contact gallery representative Phyllis Van Orden to set up an appointment.'),
(989, 156, '_studio_visit_description', 'field_5accb5e2890ad'),
(990, 156, 'studio_visit_cta_link', ''),
(991, 156, '_studio_visit_cta_link', 'field_5accb604890af'),
(992, 156, 'studio_visit_cta_text', 'Contact »'),
(993, 156, '_studio_visit_cta_text', 'field_5accb5f3890ae'),
(994, 156, 'studio_visit_headline', 'Schedule a Visit:'),
(995, 156, '_studio_visit_headline', 'field_5accddbd0baff'),
(996, 156, 'studio_videos', '3'),
(997, 156, '_studio_videos', 'field_5accf625e0115'),
(998, 156, 'studio_progress_header', 'In Progress'),
(999, 156, '_studio_progress_header', 'field_5accfea1e011c'),
(1000, 156, 'studio_progress_background_image', '73'),
(1001, 156, '_studio_progress_background_image', 'field_5accfe88e011b'),
(1002, 156, 'studio_progress_slideshow_shortcode', ''),
(1003, 156, '_studio_progress_slideshow_shortcode', 'field_5accfebde011d'),
(1004, 156, 'studio_videos_0_studio_video_related_url', 'https://vimeo.com/244749533'),
(1005, 156, '_studio_videos_0_studio_video_related_url', 'field_5accf64ae0116'),
(1006, 156, 'studio_videos_0_studio_video_related_thumbnail', '83'),
(1007, 156, '_studio_videos_0_studio_video_related_thumbnail', 'field_5accf6cae0117'),
(1008, 156, 'studio_videos_0_studio_video_related_caption', 'The therapy of drawing.'),
(1009, 156, '_studio_videos_0_studio_video_related_caption', 'field_5accf704e0118'),
(1010, 156, 'studio_videos_1_studio_video_related_url', 'https://vimeo.com/244749306'),
(1011, 156, '_studio_videos_1_studio_video_related_url', 'field_5accf64ae0116'),
(1012, 156, 'studio_videos_1_studio_video_related_thumbnail', '81'),
(1013, 156, '_studio_videos_1_studio_video_related_thumbnail', 'field_5accf6cae0117'),
(1014, 156, 'studio_videos_1_studio_video_related_caption', 'Going through the archives.'),
(1015, 156, '_studio_videos_1_studio_video_related_caption', 'field_5accf704e0118'),
(1016, 156, 'studio_videos_2_studio_video_related_url', 'https://vimeo.com/249770248'),
(1017, 156, '_studio_videos_2_studio_video_related_url', 'field_5accf64ae0116'),
(1018, 156, 'studio_videos_2_studio_video_related_thumbnail', '82'),
(1019, 156, '_studio_videos_2_studio_video_related_thumbnail', 'field_5accf6cae0117'),
(1020, 156, 'studio_videos_2_studio_video_related_caption', 'Technique and process: ink to paper.'),
(1021, 156, '_studio_videos_2_studio_video_related_caption', 'field_5accf704e0118'),
(1022, 156, 'studio_main_video_caption', ''),
(1023, 156, '_studio_main_video_caption', 'field_5acd11915e5a0'),
(1024, 156, 'studio_related_videos_0_studio_related_video_url', 'https://vimeo.com/249770248'),
(1025, 156, '_studio_related_videos_0_studio_related_video_url', 'field_5accf64ae0116'),
(1026, 156, 'studio_related_videos_0_studio_related_video_thumbnail', '83'),
(1027, 156, '_studio_related_videos_0_studio_related_video_thumbnail', 'field_5accf6cae0117'),
(1028, 156, 'studio_related_videos_0_studio_related_video_caption', 'The therapy of drawing.'),
(1029, 156, '_studio_related_videos_0_studio_related_video_caption', 'field_5accf704e0118'),
(1030, 156, 'studio_related_videos_1_studio_related_video_url', 'https://vimeo.com/244749533'),
(1031, 156, '_studio_related_videos_1_studio_related_video_url', 'field_5accf64ae0116'),
(1032, 156, 'studio_related_videos_1_studio_related_video_thumbnail', '81'),
(1033, 156, '_studio_related_videos_1_studio_related_video_thumbnail', 'field_5accf6cae0117'),
(1034, 156, 'studio_related_videos_1_studio_related_video_caption', 'Going through the archives.'),
(1035, 156, '_studio_related_videos_1_studio_related_video_caption', 'field_5accf704e0118'),
(1036, 156, 'studio_related_videos_2_studio_related_video_url', 'https://vimeo.com/244749306'),
(1037, 156, '_studio_related_videos_2_studio_related_video_url', 'field_5accf64ae0116'),
(1038, 156, 'studio_related_videos_2_studio_related_video_thumbnail', '82'),
(1039, 156, '_studio_related_videos_2_studio_related_video_thumbnail', 'field_5accf6cae0117'),
(1040, 156, 'studio_related_videos_2_studio_related_video_caption', 'Technique and process: ink to paper.'),
(1041, 156, '_studio_related_videos_2_studio_related_video_caption', 'field_5accf704e0118'),
(1042, 156, 'studio_related_videos', '3'),
(1043, 156, '_studio_related_videos', 'field_5accf625e0115'),
(1044, 156, 'studi_visit_contact_shortcode', '[contact-form-7 id=\"78\" title=\"Contact form 1\"]'),
(1045, 156, '_studi_visit_contact_shortcode', 'field_5acfa23e6ce2f'),
(1046, 156, 'studio_visit_contact_shortcode', ''),
(1047, 156, '_studio_visit_contact_shortcode', 'field_5acfa23e6ce2f'),
(1048, 157, 'studio_main_video', 'https://vimeo.com/245236016'),
(1049, 157, '_studio_main_video', 'field_5accb52e890ab'),
(1050, 157, 'studio_visit_description', 'Meet the artist and experience the studio in person. <br>Contact gallery representative Phyllis Van Orden to set<br> up an appointment.'),
(1051, 157, '_studio_visit_description', 'field_5accb5e2890ad'),
(1052, 157, 'studio_visit_cta_link', ''),
(1053, 157, '_studio_visit_cta_link', 'field_5accb604890af'),
(1054, 157, 'studio_visit_cta_text', 'Contact »'),
(1055, 157, '_studio_visit_cta_text', 'field_5accb5f3890ae'),
(1056, 157, 'studio_visit_headline', 'Schedule a Visit:'),
(1057, 157, '_studio_visit_headline', 'field_5accddbd0baff'),
(1058, 157, 'studio_videos', '3'),
(1059, 157, '_studio_videos', 'field_5accf625e0115'),
(1060, 157, 'studio_progress_header', 'In Progress'),
(1061, 157, '_studio_progress_header', 'field_5accfea1e011c'),
(1062, 157, 'studio_progress_background_image', '73'),
(1063, 157, '_studio_progress_background_image', 'field_5accfe88e011b'),
(1064, 157, 'studio_progress_slideshow_shortcode', ''),
(1065, 157, '_studio_progress_slideshow_shortcode', 'field_5accfebde011d'),
(1066, 157, 'studio_videos_0_studio_video_related_url', 'https://vimeo.com/244749533'),
(1067, 157, '_studio_videos_0_studio_video_related_url', 'field_5accf64ae0116'),
(1068, 157, 'studio_videos_0_studio_video_related_thumbnail', '83'),
(1069, 157, '_studio_videos_0_studio_video_related_thumbnail', 'field_5accf6cae0117'),
(1070, 157, 'studio_videos_0_studio_video_related_caption', 'The therapy of drawing.'),
(1071, 157, '_studio_videos_0_studio_video_related_caption', 'field_5accf704e0118'),
(1072, 157, 'studio_videos_1_studio_video_related_url', 'https://vimeo.com/244749306'),
(1073, 157, '_studio_videos_1_studio_video_related_url', 'field_5accf64ae0116'),
(1074, 157, 'studio_videos_1_studio_video_related_thumbnail', '81'),
(1075, 157, '_studio_videos_1_studio_video_related_thumbnail', 'field_5accf6cae0117'),
(1076, 157, 'studio_videos_1_studio_video_related_caption', 'Going through the archives.'),
(1077, 157, '_studio_videos_1_studio_video_related_caption', 'field_5accf704e0118'),
(1078, 157, 'studio_videos_2_studio_video_related_url', 'https://vimeo.com/249770248'),
(1079, 157, '_studio_videos_2_studio_video_related_url', 'field_5accf64ae0116'),
(1080, 157, 'studio_videos_2_studio_video_related_thumbnail', '82'),
(1081, 157, '_studio_videos_2_studio_video_related_thumbnail', 'field_5accf6cae0117'),
(1082, 157, 'studio_videos_2_studio_video_related_caption', 'Technique and process: ink to paper.'),
(1083, 157, '_studio_videos_2_studio_video_related_caption', 'field_5accf704e0118'),
(1084, 157, 'studio_main_video_caption', ''),
(1085, 157, '_studio_main_video_caption', 'field_5acd11915e5a0'),
(1086, 157, 'studio_related_videos_0_studio_related_video_url', 'https://vimeo.com/249770248'),
(1087, 157, '_studio_related_videos_0_studio_related_video_url', 'field_5accf64ae0116'),
(1088, 157, 'studio_related_videos_0_studio_related_video_thumbnail', '83'),
(1089, 157, '_studio_related_videos_0_studio_related_video_thumbnail', 'field_5accf6cae0117'),
(1090, 157, 'studio_related_videos_0_studio_related_video_caption', 'The therapy of drawing.'),
(1091, 157, '_studio_related_videos_0_studio_related_video_caption', 'field_5accf704e0118'),
(1092, 157, 'studio_related_videos_1_studio_related_video_url', 'https://vimeo.com/244749533'),
(1093, 157, '_studio_related_videos_1_studio_related_video_url', 'field_5accf64ae0116'),
(1094, 157, 'studio_related_videos_1_studio_related_video_thumbnail', '81'),
(1095, 157, '_studio_related_videos_1_studio_related_video_thumbnail', 'field_5accf6cae0117'),
(1096, 157, 'studio_related_videos_1_studio_related_video_caption', 'Going through the archives.'),
(1097, 157, '_studio_related_videos_1_studio_related_video_caption', 'field_5accf704e0118'),
(1098, 157, 'studio_related_videos_2_studio_related_video_url', 'https://vimeo.com/244749306'),
(1099, 157, '_studio_related_videos_2_studio_related_video_url', 'field_5accf64ae0116'),
(1100, 157, 'studio_related_videos_2_studio_related_video_thumbnail', '82'),
(1101, 157, '_studio_related_videos_2_studio_related_video_thumbnail', 'field_5accf6cae0117'),
(1102, 157, 'studio_related_videos_2_studio_related_video_caption', 'Technique and process: ink to paper.'),
(1103, 157, '_studio_related_videos_2_studio_related_video_caption', 'field_5accf704e0118'),
(1104, 157, 'studio_related_videos', '3'),
(1105, 157, '_studio_related_videos', 'field_5accf625e0115'),
(1106, 157, 'studi_visit_contact_shortcode', '[contact-form-7 id=\"78\" title=\"Contact form 1\"]'),
(1107, 157, '_studi_visit_contact_shortcode', 'field_5acfa23e6ce2f'),
(1108, 157, 'studio_visit_contact_shortcode', ''),
(1109, 157, '_studio_visit_contact_shortcode', 'field_5acfa23e6ce2f'),
(1110, 158, '_edit_last', '1'),
(1111, 158, '_edit_lock', '1523981016:1'),
(1112, 158, 'news_article_date', 'May 12th, 2018'),
(1113, 158, '_news_article_date', 'field_5acd1db05e352'),
(1114, 158, 'news_article_url', 'https://facebook.com'),
(1115, 158, '_news_article_url', 'field_5acd1e1b5e354'),
(1116, 158, 'news_article_square_image', '133'),
(1117, 158, '_news_article_square_image', 'field_5acfa063547c1'),
(1118, 158, 'news_article_vertical_image', '101'),
(1119, 158, '_news_article_vertical_image', 'field_5acfa087547c2'),
(1120, 158, '_thumbnail_id', '135'),
(1121, 158, '_wp_trash_meta_status', 'publish'),
(1122, 158, '_wp_trash_meta_time', '1523981160'),
(1123, 158, '_wp_desired_post_slug', 'providence-art-club-gallery-exhibition-is-locked-providence-art-club-gallery-exhibition'),
(1124, 159, '_edit_last', '1'),
(1125, 159, '_edit_lock', '1523983440:1'),
(1126, 159, 'news_article_date', 'May 12th, 2018'),
(1127, 159, '_news_article_date', 'field_5acd1db05e352'),
(1128, 159, 'news_article_url', 'https://facebook.com'),
(1129, 159, '_news_article_url', 'field_5acd1e1b5e354'),
(1130, 159, 'news_article_square_image', '133'),
(1131, 159, '_news_article_square_image', 'field_5acfa063547c1'),
(1132, 159, 'news_article_vertical_image', ''),
(1133, 159, '_news_article_vertical_image', 'field_5acfa087547c2'),
(1134, 159, '_thumbnail_id', '102'),
(1135, 1, '_wp_trash_meta_status', 'publish'),
(1136, 1, '_wp_trash_meta_time', '1523984179'),
(1137, 1, '_wp_desired_post_slug', 'hello-world'),
(1138, 1, '_wp_trash_meta_comments_status', 'a:1:{i:1;s:1:\"1\";}'),
(1144, 166, '_edit_last', '1'),
(1145, 166, 'story_year', '2006'),
(1146, 166, '_story_year', 'field_5acf90b3e9f5b'),
(1147, 166, 'story_quote', '“One of the best creations I was commissioned for was the assemblage in the Riverfront lobby–I really, really enjoyed that.”'),
(1148, 166, '_story_quote', 'field_5acf90dee9f5c'),
(1149, 166, 'story_map_image', '170'),
(1150, 166, '_story_map_image', 'field_5acf9112e9f5e'),
(1151, 166, 'intro_vertical_image', '168'),
(1152, 166, '_intro_vertical_image', 'field_5acf9130e9f5f'),
(1153, 166, 'horitonzal_image_1', '169'),
(1154, 166, '_horitonzal_image_1', 'field_5acf9155e9f60'),
(1155, 166, 'story_content', '[one_half padding=\"0 10px 0 0\"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ornare quam ut turpis elementum, sit amet rutrum mi dignissim.\r\n\r\nNunc euismod vehicula magna, non sollicitudin ex condimentum sit amet. Morbi eu eleifend sem. Fusce sed mattis mi, non lacinia dolor.\r\n\r\nSed non nulla ac ipsum pretium tempor id eu nisl. Cras lacinia eleifend imperdiet. Praesent quis elit augue. Vestibulum ac volutpat elit, molestie commodo tellus. [/one_half][one_half padding=\"0 0 0 10px\"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ornare quam ut turpis elementum, sit amet rutrum mi dignissim.\r\n\r\nNunc euismod vehicula magna, non sollicitudin ex condimentum sit amet. Morbi eu eleifend sem. Fusce sed mattis mi, non lacinia dolor.\r\n\r\nSed non nulla ac ipsum pretium tempor id eu nisl. Cras lacinia eleifend imperdiet. Praesent quis elit augue. Vestibulum ac volutpat elit, molestie commodo tellus.[/one_half]\r\n\r\n&nbsp;\r\n\r\n[fve]https://vimeo.com/78535116[/fve]'),
(1156, 166, '_story_content', 'field_5acf916ae9f62'),
(1157, 166, 'horitonzal_image_2', ''),
(1158, 166, '_horitonzal_image_2', 'field_5acf9163e9f61'),
(1159, 166, '_edit_lock', '1524163134:1'),
(1160, 167, '_menu_item_type', 'post_type'),
(1161, 167, '_menu_item_menu_item_parent', '0'),
(1162, 167, '_menu_item_object_id', '34'),
(1163, 167, '_menu_item_object', 'page'),
(1164, 167, '_menu_item_target', ''),
(1165, 167, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(1166, 167, '_menu_item_xfn', ''),
(1167, 167, '_menu_item_url', ''),
(1169, 168, '_wp_attached_file', '2018/04/Image-1.png'),
(1170, 168, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:754;s:6:\"height\";i:946;s:4:\"file\";s:19:\"2018/04/Image-1.png\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"Image-1-120x150.png\";s:5:\"width\";i:120;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"Image-1-239x300.png\";s:5:\"width\";i:239;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:19:\"Image-1-125x125.png\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:19:\"Image-1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:19:\"Image-1-300x376.png\";s:5:\"width\";i:300;s:6:\"height\";i:376;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:19:\"Image-1-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:19:\"Image-1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:19:\"Image-1-300x376.png\";s:5:\"width\";i:300;s:6:\"height\";i:376;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:19:\"Image-1-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1171, 169, '_wp_attached_file', '2018/04/Image-2.png'),
(1172, 169, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1612;s:6:\"height\";i:750;s:4:\"file\";s:19:\"2018/04/Image-2.png\";s:5:\"sizes\";a:11:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"Image-2-150x70.png\";s:5:\"width\";i:150;s:6:\"height\";i:70;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"Image-2-300x140.png\";s:5:\"width\";i:300;s:6:\"height\";i:140;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"Image-2-768x357.png\";s:5:\"width\";i:768;s:6:\"height\";i:357;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:20:\"Image-2-1024x476.png\";s:5:\"width\";i:1024;s:6:\"height\";i:476;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:19:\"Image-2-125x125.png\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:19:\"Image-2-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:19:\"Image-2-300x140.png\";s:5:\"width\";i:300;s:6:\"height\";i:140;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:19:\"Image-2-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:19:\"Image-2-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:19:\"Image-2-300x140.png\";s:5:\"width\";i:300;s:6:\"height\";i:140;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:19:\"Image-2-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1173, 170, '_wp_attached_file', '2018/04/map.png'),
(1174, 170, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:388;s:6:\"height\";i:288;s:4:\"file\";s:15:\"2018/04/map.png\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"map-150x111.png\";s:5:\"width\";i:150;s:6:\"height\";i:111;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"map-300x223.png\";s:5:\"width\";i:300;s:6:\"height\";i:223;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:15:\"map-125x125.png\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:15:\"map-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:15:\"map-300x223.png\";s:5:\"width\";i:300;s:6:\"height\";i:223;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:15:\"map-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:15:\"map-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:15:\"map-300x223.png\";s:5:\"width\";i:300;s:6:\"height\";i:223;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:15:\"map-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1175, 171, '_edit_last', '1'),
(1176, 171, '_edit_lock', '1524071077:1'),
(1177, 172, '_wp_attached_file', '2018/04/morris.png'),
(1178, 172, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:377;s:6:\"height\";i:473;s:4:\"file\";s:18:\"2018/04/morris.png\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"morris-120x150.png\";s:5:\"width\";i:120;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"morris-239x300.png\";s:5:\"width\";i:239;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:18:\"morris-125x125.png\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:18:\"morris-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:18:\"morris-300x376.png\";s:5:\"width\";i:300;s:6:\"height\";i:376;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:18:\"morris-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:18:\"morris-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:18:\"morris-300x376.png\";s:5:\"width\";i:300;s:6:\"height\";i:376;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:18:\"morris-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1179, 173, '_wp_attached_file', '2018/04/morris-cover.png'),
(1180, 173, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:806;s:6:\"height\";i:375;s:4:\"file\";s:24:\"2018/04/morris-cover.png\";s:5:\"sizes\";a:10:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:23:\"morris-cover-150x70.png\";s:5:\"width\";i:150;s:6:\"height\";i:70;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:24:\"morris-cover-300x140.png\";s:5:\"width\";i:300;s:6:\"height\";i:140;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:24:\"morris-cover-768x357.png\";s:5:\"width\";i:768;s:6:\"height\";i:357;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:24:\"morris-cover-125x125.png\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:24:\"morris-cover-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:24:\"morris-cover-300x140.png\";s:5:\"width\";i:300;s:6:\"height\";i:140;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:24:\"morris-cover-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:24:\"morris-cover-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:24:\"morris-cover-300x140.png\";s:5:\"width\";i:300;s:6:\"height\";i:140;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:24:\"morris-cover-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1181, 174, '_wp_attached_file', '2018/04/morris-cover-2.png'),
(1182, 174, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:806;s:6:\"height\";i:375;s:4:\"file\";s:26:\"2018/04/morris-cover-2.png\";s:5:\"sizes\";a:10:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"morris-cover-2-150x70.png\";s:5:\"width\";i:150;s:6:\"height\";i:70;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:26:\"morris-cover-2-300x140.png\";s:5:\"width\";i:300;s:6:\"height\";i:140;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:26:\"morris-cover-2-768x357.png\";s:5:\"width\";i:768;s:6:\"height\";i:357;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:26:\"morris-cover-2-125x125.png\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:26:\"morris-cover-2-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:26:\"morris-cover-2-300x140.png\";s:5:\"width\";i:300;s:6:\"height\";i:140;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:26:\"morris-cover-2-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:26:\"morris-cover-2-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:26:\"morris-cover-2-300x140.png\";s:5:\"width\";i:300;s:6:\"height\";i:140;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:26:\"morris-cover-2-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1183, 171, 'story_year', '2000s'),
(1184, 171, '_story_year', 'field_5acf90b3e9f5b'),
(1185, 171, 'story_quote', '“Over the years, (whenever possible) we tried to include in our designs, original artwork–as much as we could. ”'),
(1186, 171, '_story_quote', 'field_5acf90dee9f5c'),
(1187, 171, 'story_map_image', '175'),
(1188, 171, '_story_map_image', 'field_5acf9112e9f5e'),
(1189, 171, 'intro_vertical_image', '172'),
(1190, 171, '_intro_vertical_image', 'field_5acf9130e9f5f'),
(1191, 171, 'horitonzal_image_1', '173'),
(1192, 171, '_horitonzal_image_1', 'field_5acf9155e9f60'),
(1193, 171, 'story_content', '[one_half padding=\"0 10px 0 0\"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ornare quam ut turpis elementum, sit amet rutrum mi dignissim.\r\n\r\nNunc euismod vehicula magna, non sollicitudin ex condimentum sit amet. Morbi eu eleifend sem. Fusce sed mattis mi, non lacinia dolor.\r\n\r\nSed non nulla ac ipsum pretium tempor id eu nisl. Cras lacinia eleifend imperdiet. Praesent quis elit augue. Vestibulum ac volutpat elit, molestie commodo tellus. [/one_half][one_half padding=\"0 0 0 10px\"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ornare quam ut turpis elementum, sit amet rutrum mi dignissim.\r\n\r\nNunc euismod vehicula magna, non sollicitudin ex condimentum sit amet. Morbi eu eleifend sem. Fusce sed mattis mi, non lacinia dolor.\r\n\r\nSed non nulla ac ipsum pretium tempor id eu nisl. Cras lacinia eleifend imperdiet. Praesent quis elit augue. Vestibulum ac volutpat elit, molestie commodo tellus.[/one_half]'),
(1194, 171, '_story_content', 'field_5acf916ae9f62'),
(1195, 171, 'horitonzal_image_2', '174'),
(1196, 171, '_horitonzal_image_2', 'field_5acf9163e9f61'),
(1197, 175, '_wp_attached_file', '2018/04/morris-map.png'),
(1198, 175, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:194;s:6:\"height\";i:145;s:4:\"file\";s:22:\"2018/04/morris-map.png\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:22:\"morris-map-150x112.png\";s:5:\"width\";i:150;s:6:\"height\";i:112;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:22:\"morris-map-125x125.png\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:22:\"morris-map-150x145.png\";s:5:\"width\";i:150;s:6:\"height\";i:145;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:22:\"morris-map-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:22:\"morris-map-150x145.png\";s:5:\"width\";i:150;s:6:\"height\";i:145;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:22:\"morris-map-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1199, 176, '_edit_last', '1'),
(1200, 176, '_edit_lock', '1524057173:1'),
(1201, 177, '_wp_attached_file', '2018/04/atlantis-cover-2.png'),
(1202, 177, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:806;s:6:\"height\";i:375;s:4:\"file\";s:28:\"2018/04/atlantis-cover-2.png\";s:5:\"sizes\";a:10:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"atlantis-cover-2-150x70.png\";s:5:\"width\";i:150;s:6:\"height\";i:70;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:28:\"atlantis-cover-2-300x140.png\";s:5:\"width\";i:300;s:6:\"height\";i:140;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:28:\"atlantis-cover-2-768x357.png\";s:5:\"width\";i:768;s:6:\"height\";i:357;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:28:\"atlantis-cover-2-125x125.png\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:28:\"atlantis-cover-2-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:28:\"atlantis-cover-2-300x140.png\";s:5:\"width\";i:300;s:6:\"height\";i:140;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:28:\"atlantis-cover-2-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:28:\"atlantis-cover-2-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:28:\"atlantis-cover-2-300x140.png\";s:5:\"width\";i:300;s:6:\"height\";i:140;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:28:\"atlantis-cover-2-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1203, 178, '_wp_attached_file', '2018/04/atlantis-cover.png'),
(1204, 178, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:806;s:6:\"height\";i:375;s:4:\"file\";s:26:\"2018/04/atlantis-cover.png\";s:5:\"sizes\";a:10:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"atlantis-cover-150x70.png\";s:5:\"width\";i:150;s:6:\"height\";i:70;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:26:\"atlantis-cover-300x140.png\";s:5:\"width\";i:300;s:6:\"height\";i:140;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:26:\"atlantis-cover-768x357.png\";s:5:\"width\";i:768;s:6:\"height\";i:357;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:26:\"atlantis-cover-125x125.png\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:26:\"atlantis-cover-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:26:\"atlantis-cover-300x140.png\";s:5:\"width\";i:300;s:6:\"height\";i:140;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:26:\"atlantis-cover-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:26:\"atlantis-cover-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:26:\"atlantis-cover-300x140.png\";s:5:\"width\";i:300;s:6:\"height\";i:140;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:26:\"atlantis-cover-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1205, 179, '_wp_attached_file', '2018/04/atlantis-map.png'),
(1206, 179, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:194;s:6:\"height\";i:149;s:4:\"file\";s:24:\"2018/04/atlantis-map.png\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:24:\"atlantis-map-150x115.png\";s:5:\"width\";i:150;s:6:\"height\";i:115;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:24:\"atlantis-map-125x125.png\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:24:\"atlantis-map-150x149.png\";s:5:\"width\";i:150;s:6:\"height\";i:149;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:24:\"atlantis-map-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:24:\"atlantis-map-150x149.png\";s:5:\"width\";i:150;s:6:\"height\";i:149;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:24:\"atlantis-map-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1207, 180, '_wp_attached_file', '2018/04/atlantis.png'),
(1208, 180, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:377;s:6:\"height\";i:473;s:4:\"file\";s:20:\"2018/04/atlantis.png\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"atlantis-120x150.png\";s:5:\"width\";i:120;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"atlantis-239x300.png\";s:5:\"width\";i:239;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:20:\"atlantis-125x125.png\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:20:\"atlantis-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:20:\"atlantis-300x376.png\";s:5:\"width\";i:300;s:6:\"height\";i:376;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:20:\"atlantis-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:20:\"atlantis-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:20:\"atlantis-300x376.png\";s:5:\"width\";i:300;s:6:\"height\";i:376;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:20:\"atlantis-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1209, 176, 'story_year', '1990s'),
(1210, 176, '_story_year', 'field_5acf90b3e9f5b'),
(1211, 176, 'story_quote', '“Certainly one of the most exciting projects we worked on was with Mr. Kerzner.”'),
(1212, 176, '_story_quote', 'field_5acf90dee9f5c'),
(1213, 176, 'story_map_image', '179'),
(1214, 176, '_story_map_image', 'field_5acf9112e9f5e'),
(1215, 176, 'intro_vertical_image', '180'),
(1216, 176, '_intro_vertical_image', 'field_5acf9130e9f5f'),
(1217, 176, 'horitonzal_image_1', '178'),
(1218, 176, '_horitonzal_image_1', 'field_5acf9155e9f60'),
(1219, 176, 'story_content', '[one_half padding=\"0 10px 0 0\"]Certainly one of the most exciting projects we worked on was with Mr. Kerzner, so I snuck in paradise island in the Bahamas and it was a wonderful wonderful experience and probably one the highlights of my career.\r\n\r\nI think what excited Mr. Kerzner about our presentation was the ideas we had for design.[/one_half][one_half padding=\"0 0 0 10px\"]We both were very fond of a restaurant in Miami Beach, which had been there for many many years. It was a delicatessen and restaurant called Wolfie’s, and what we did was the whole story about Wolfie’s.\r\n\r\nIt was the idea was to bring that story and out to the public and it really was an exciting thing.\r\n[/one_half]'),
(1220, 176, '_story_content', 'field_5acf916ae9f62'),
(1221, 176, 'horitonzal_image_2', '177'),
(1222, 176, '_horitonzal_image_2', 'field_5acf9163e9f61'),
(1223, 181, '_edit_last', '1'),
(1224, 181, '_edit_lock', '1524057389:1'),
(1225, 182, '_wp_attached_file', '2018/04/euro-disney-cover-2.png'),
(1226, 182, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:806;s:6:\"height\";i:375;s:4:\"file\";s:31:\"2018/04/euro-disney-cover-2.png\";s:5:\"sizes\";a:10:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:30:\"euro-disney-cover-2-150x70.png\";s:5:\"width\";i:150;s:6:\"height\";i:70;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"euro-disney-cover-2-300x140.png\";s:5:\"width\";i:300;s:6:\"height\";i:140;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"euro-disney-cover-2-768x357.png\";s:5:\"width\";i:768;s:6:\"height\";i:357;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:31:\"euro-disney-cover-2-125x125.png\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:31:\"euro-disney-cover-2-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:31:\"euro-disney-cover-2-300x140.png\";s:5:\"width\";i:300;s:6:\"height\";i:140;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:31:\"euro-disney-cover-2-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:31:\"euro-disney-cover-2-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:31:\"euro-disney-cover-2-300x140.png\";s:5:\"width\";i:300;s:6:\"height\";i:140;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:31:\"euro-disney-cover-2-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}');
INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1227, 183, '_wp_attached_file', '2018/04/euro-disney-cover.png'),
(1228, 183, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:806;s:6:\"height\";i:375;s:4:\"file\";s:29:\"2018/04/euro-disney-cover.png\";s:5:\"sizes\";a:10:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:28:\"euro-disney-cover-150x70.png\";s:5:\"width\";i:150;s:6:\"height\";i:70;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:29:\"euro-disney-cover-300x140.png\";s:5:\"width\";i:300;s:6:\"height\";i:140;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:29:\"euro-disney-cover-768x357.png\";s:5:\"width\";i:768;s:6:\"height\";i:357;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:29:\"euro-disney-cover-125x125.png\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:29:\"euro-disney-cover-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:29:\"euro-disney-cover-300x140.png\";s:5:\"width\";i:300;s:6:\"height\";i:140;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:29:\"euro-disney-cover-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:29:\"euro-disney-cover-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:29:\"euro-disney-cover-300x140.png\";s:5:\"width\";i:300;s:6:\"height\";i:140;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:29:\"euro-disney-cover-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1229, 184, '_wp_attached_file', '2018/04/euro-disney-map.png'),
(1230, 184, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:194;s:6:\"height\";i:145;s:4:\"file\";s:27:\"2018/04/euro-disney-map.png\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"euro-disney-map-150x112.png\";s:5:\"width\";i:150;s:6:\"height\";i:112;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:27:\"euro-disney-map-125x125.png\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:27:\"euro-disney-map-150x145.png\";s:5:\"width\";i:150;s:6:\"height\";i:145;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:27:\"euro-disney-map-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:27:\"euro-disney-map-150x145.png\";s:5:\"width\";i:150;s:6:\"height\";i:145;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:27:\"euro-disney-map-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1231, 185, '_wp_attached_file', '2018/04/euro-disney.png'),
(1232, 185, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:377;s:6:\"height\";i:473;s:4:\"file\";s:23:\"2018/04/euro-disney.png\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:23:\"euro-disney-120x150.png\";s:5:\"width\";i:120;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:23:\"euro-disney-239x300.png\";s:5:\"width\";i:239;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:23:\"euro-disney-125x125.png\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:23:\"euro-disney-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:23:\"euro-disney-300x376.png\";s:5:\"width\";i:300;s:6:\"height\";i:376;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:23:\"euro-disney-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:23:\"euro-disney-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:23:\"euro-disney-300x376.png\";s:5:\"width\";i:300;s:6:\"height\";i:376;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:23:\"euro-disney-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1233, 181, 'story_year', '1990'),
(1234, 181, '_story_year', 'field_5acf90b3e9f5b'),
(1235, 181, 'story_quote', '“We had artists create original artwork for all the interiors in buildings, designed by Frank Gehry.”'),
(1236, 181, '_story_quote', 'field_5acf90dee9f5c'),
(1237, 181, 'story_map_image', '184'),
(1238, 181, '_story_map_image', 'field_5acf9112e9f5e'),
(1239, 181, 'intro_vertical_image', '185'),
(1240, 181, '_intro_vertical_image', 'field_5acf9130e9f5f'),
(1241, 181, 'horitonzal_image_1', '183'),
(1242, 181, '_horitonzal_image_1', 'field_5acf9155e9f60'),
(1243, 181, 'story_content', '[one_half padding=\"0 10px 0 0\"]In the 1990s we were hired by Michael Eisner from the Disney company to be the interior design directors for all the restaurants in the restaurant park at the EuroDisney.[/one_half][one_half_last padding=\"0 0px 0 10px\"]We had friends and local artists create artwork for all the interiors in buildings that were designed by Frank Gehry – you might know as the very famous architect. I might say it was quite an exciting venture working together.[/one_half_last]'),
(1244, 181, '_story_content', 'field_5acf916ae9f62'),
(1245, 181, 'horitonzal_image_2', '182'),
(1246, 181, '_horitonzal_image_2', 'field_5acf9163e9f61'),
(1247, 186, '_edit_last', '1'),
(1248, 186, '_edit_lock', '1524057878:1'),
(1249, 187, '_wp_attached_file', '2018/04/soho-cover-2.png'),
(1250, 187, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:806;s:6:\"height\";i:375;s:4:\"file\";s:24:\"2018/04/soho-cover-2.png\";s:5:\"sizes\";a:10:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:23:\"soho-cover-2-150x70.png\";s:5:\"width\";i:150;s:6:\"height\";i:70;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:24:\"soho-cover-2-300x140.png\";s:5:\"width\";i:300;s:6:\"height\";i:140;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:24:\"soho-cover-2-768x357.png\";s:5:\"width\";i:768;s:6:\"height\";i:357;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:24:\"soho-cover-2-125x125.png\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:24:\"soho-cover-2-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:24:\"soho-cover-2-300x140.png\";s:5:\"width\";i:300;s:6:\"height\";i:140;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:24:\"soho-cover-2-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:24:\"soho-cover-2-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:24:\"soho-cover-2-300x140.png\";s:5:\"width\";i:300;s:6:\"height\";i:140;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:24:\"soho-cover-2-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1251, 188, '_wp_attached_file', '2018/04/soho-cover.png'),
(1252, 188, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:806;s:6:\"height\";i:375;s:4:\"file\";s:22:\"2018/04/soho-cover.png\";s:5:\"sizes\";a:10:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"soho-cover-150x70.png\";s:5:\"width\";i:150;s:6:\"height\";i:70;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:22:\"soho-cover-300x140.png\";s:5:\"width\";i:300;s:6:\"height\";i:140;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:22:\"soho-cover-768x357.png\";s:5:\"width\";i:768;s:6:\"height\";i:357;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:22:\"soho-cover-125x125.png\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:22:\"soho-cover-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:22:\"soho-cover-300x140.png\";s:5:\"width\";i:300;s:6:\"height\";i:140;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:22:\"soho-cover-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:22:\"soho-cover-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:22:\"soho-cover-300x140.png\";s:5:\"width\";i:300;s:6:\"height\";i:140;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:22:\"soho-cover-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1253, 189, '_wp_attached_file', '2018/04/soho-map.png'),
(1254, 189, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:194;s:6:\"height\";i:145;s:4:\"file\";s:20:\"2018/04/soho-map.png\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"soho-map-150x112.png\";s:5:\"width\";i:150;s:6:\"height\";i:112;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:20:\"soho-map-125x125.png\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:20:\"soho-map-150x145.png\";s:5:\"width\";i:150;s:6:\"height\";i:145;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:20:\"soho-map-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:20:\"soho-map-150x145.png\";s:5:\"width\";i:150;s:6:\"height\";i:145;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:20:\"soho-map-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1255, 190, '_wp_attached_file', '2018/04/soho.png'),
(1256, 190, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:377;s:6:\"height\";i:473;s:4:\"file\";s:16:\"2018/04/soho.png\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:16:\"soho-120x150.png\";s:5:\"width\";i:120;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:16:\"soho-239x300.png\";s:5:\"width\";i:239;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:16:\"soho-125x125.png\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:16:\"soho-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:16:\"soho-300x376.png\";s:5:\"width\";i:300;s:6:\"height\";i:376;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:16:\"soho-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:16:\"soho-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:16:\"soho-300x376.png\";s:5:\"width\";i:300;s:6:\"height\";i:376;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:16:\"soho-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1257, 186, 'story_year', '1970s'),
(1258, 186, '_story_year', 'field_5acf90b3e9f5b'),
(1259, 186, 'story_quote', '“Soho residents there we’re doing great artwork, but they were known for other careers as well.”'),
(1260, 186, '_story_quote', 'field_5acf90dee9f5c'),
(1261, 186, 'story_map_image', '189'),
(1262, 186, '_story_map_image', 'field_5acf9112e9f5e'),
(1263, 186, 'intro_vertical_image', '190'),
(1264, 186, '_intro_vertical_image', 'field_5acf9130e9f5f'),
(1265, 186, 'horitonzal_image_1', '188'),
(1266, 186, '_horitonzal_image_1', 'field_5acf9155e9f60'),
(1267, 186, 'story_content', '[one_half padding=\"0 10px 0 0\"]Working in Soho in the 70s and 80s I was fortunate to be doing some work. As a matter of fact I actually became a partner in running a gallery in that area. While I was there I saw how the once empty buildings were being occupied by artists coming in. It was a very exciting experience and soon I was able to take that adventure and that experience to Pawtucket. We had so many of these old mill buildings, and were able to bring new life to them.[/one_half][one_half_last padding=\"0 0 0 10px\"]While working in the gallery we realized that Soho residents there we’re doing great artwork, but they were known for other things as well. For example, in the 80s Harry Belafonte‘s mother-in-law was a very fine artist who had shows. One day we realized that Morley Safer (of 60 Minutes fame) was a really terrific artist. Even though you’d say he was primitive, he had an incredible show which was a complete sellout. Overall, a very exciting and great adventure.[/one_half_last]'),
(1268, 186, '_story_content', 'field_5acf916ae9f62'),
(1269, 186, 'horitonzal_image_2', '187'),
(1270, 186, '_horitonzal_image_2', 'field_5acf9163e9f61'),
(1271, 191, '_menu_item_type', 'custom'),
(1272, 191, '_menu_item_menu_item_parent', '0'),
(1273, 191, '_menu_item_object_id', '191'),
(1274, 191, '_menu_item_object', 'custom'),
(1275, 191, '_menu_item_target', ''),
(1276, 191, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(1277, 191, '_menu_item_xfn', ''),
(1278, 191, '_menu_item_url', '/gallery'),
(1280, 192, '_menu_item_type', 'custom'),
(1281, 192, '_menu_item_menu_item_parent', '0'),
(1282, 192, '_menu_item_object_id', '192'),
(1283, 192, '_menu_item_object', 'custom'),
(1284, 192, '_menu_item_target', ''),
(1285, 192, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(1286, 192, '_menu_item_xfn', ''),
(1287, 192, '_menu_item_url', '/story'),
(1289, 193, '_edit_last', '1'),
(1290, 193, '_edit_lock', '1524078280:1'),
(1294, 38, 'gallery_size', '18”x12”'),
(1295, 38, '_gallery_size', 'field_5ad776f9a7194'),
(1296, 38, 'gallery_year', '2018'),
(1297, 38, '_gallery_year', 'field_5ad74d51bcc7c'),
(1298, 197, '_edit_last', '1'),
(1299, 197, '_edit_lock', '1524078340:1'),
(1300, 198, '_wp_attached_file', '2018/04/2-bar-open-kitchen-510x689.png'),
(1301, 198, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:564;s:6:\"height\";i:762;s:4:\"file\";s:38:\"2018/04/2-bar-open-kitchen-510x689.png\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:38:\"2-bar-open-kitchen-510x689-111x150.png\";s:5:\"width\";i:111;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:38:\"2-bar-open-kitchen-510x689-222x300.png\";s:5:\"width\";i:222;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:38:\"2-bar-open-kitchen-510x689-125x125.png\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:38:\"2-bar-open-kitchen-510x689-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:38:\"2-bar-open-kitchen-510x689-300x405.png\";s:5:\"width\";i:300;s:6:\"height\";i:405;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:38:\"2-bar-open-kitchen-510x689-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:38:\"2-bar-open-kitchen-510x689-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:38:\"2-bar-open-kitchen-510x689-300x405.png\";s:5:\"width\";i:300;s:6:\"height\";i:405;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:38:\"2-bar-open-kitchen-510x689-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1304, 200, '_wp_attached_file', '2018/04/4-birmingham_church-510x636.png'),
(1305, 200, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:621;s:6:\"height\";i:774;s:4:\"file\";s:39:\"2018/04/4-birmingham_church-510x636.png\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:39:\"4-birmingham_church-510x636-120x150.png\";s:5:\"width\";i:120;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:39:\"4-birmingham_church-510x636-241x300.png\";s:5:\"width\";i:241;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:39:\"4-birmingham_church-510x636-125x125.png\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:39:\"4-birmingham_church-510x636-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:39:\"4-birmingham_church-510x636-300x374.png\";s:5:\"width\";i:300;s:6:\"height\";i:374;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:39:\"4-birmingham_church-510x636-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:39:\"4-birmingham_church-510x636-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:39:\"4-birmingham_church-510x636-300x374.png\";s:5:\"width\";i:300;s:6:\"height\";i:374;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:39:\"4-birmingham_church-510x636-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1306, 201, '_wp_attached_file', '2018/04/5-brush-510x690.png'),
(1307, 201, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:585;s:6:\"height\";i:792;s:4:\"file\";s:27:\"2018/04/5-brush-510x690.png\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"5-brush-510x690-111x150.png\";s:5:\"width\";i:111;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:27:\"5-brush-510x690-222x300.png\";s:5:\"width\";i:222;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:27:\"5-brush-510x690-125x125.png\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:27:\"5-brush-510x690-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:27:\"5-brush-510x690-300x406.png\";s:5:\"width\";i:300;s:6:\"height\";i:406;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:27:\"5-brush-510x690-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:27:\"5-brush-510x690-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:27:\"5-brush-510x690-300x406.png\";s:5:\"width\";i:300;s:6:\"height\";i:406;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:27:\"5-brush-510x690-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1308, 202, '_wp_attached_file', '2018/04/6-clock-510x681.png'),
(1309, 202, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:567;s:6:\"height\";i:759;s:4:\"file\";s:27:\"2018/04/6-clock-510x681.png\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"6-clock-510x681-112x150.png\";s:5:\"width\";i:112;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:27:\"6-clock-510x681-224x300.png\";s:5:\"width\";i:224;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:27:\"6-clock-510x681-125x125.png\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:27:\"6-clock-510x681-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:27:\"6-clock-510x681-300x402.png\";s:5:\"width\";i:300;s:6:\"height\";i:402;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:27:\"6-clock-510x681-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:27:\"6-clock-510x681-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:27:\"6-clock-510x681-300x402.png\";s:5:\"width\";i:300;s:6:\"height\";i:402;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:27:\"6-clock-510x681-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1310, 203, '_wp_attached_file', '2018/04/7-doctor-south-africa-510x426.png'),
(1311, 203, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:624;s:6:\"height\";i:519;s:4:\"file\";s:41:\"2018/04/7-doctor-south-africa-510x426.png\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:41:\"7-doctor-south-africa-510x426-150x125.png\";s:5:\"width\";i:150;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:41:\"7-doctor-south-africa-510x426-300x250.png\";s:5:\"width\";i:300;s:6:\"height\";i:250;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:41:\"7-doctor-south-africa-510x426-125x125.png\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:41:\"7-doctor-south-africa-510x426-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:41:\"7-doctor-south-africa-510x426-300x250.png\";s:5:\"width\";i:300;s:6:\"height\";i:250;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:41:\"7-doctor-south-africa-510x426-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:41:\"7-doctor-south-africa-510x426-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:41:\"7-doctor-south-africa-510x426-300x250.png\";s:5:\"width\";i:300;s:6:\"height\";i:250;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:41:\"7-doctor-south-africa-510x426-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1312, 204, '_wp_attached_file', '2018/04/8-hector-510x675.png'),
(1313, 204, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:576;s:6:\"height\";i:765;s:4:\"file\";s:28:\"2018/04/8-hector-510x675.png\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:28:\"8-hector-510x675-113x150.png\";s:5:\"width\";i:113;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:28:\"8-hector-510x675-226x300.png\";s:5:\"width\";i:226;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:28:\"8-hector-510x675-125x125.png\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:28:\"8-hector-510x675-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:28:\"8-hector-510x675-300x398.png\";s:5:\"width\";i:300;s:6:\"height\";i:398;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:28:\"8-hector-510x675-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:28:\"8-hector-510x675-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:28:\"8-hector-510x675-300x398.png\";s:5:\"width\";i:300;s:6:\"height\";i:398;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:28:\"8-hector-510x675-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1314, 205, '_wp_attached_file', '2018/04/9-japonica-510x790.png'),
(1315, 205, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:483;s:6:\"height\";i:747;s:4:\"file\";s:30:\"2018/04/9-japonica-510x790.png\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:29:\"9-japonica-510x790-97x150.png\";s:5:\"width\";i:97;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:30:\"9-japonica-510x790-194x300.png\";s:5:\"width\";i:194;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:30:\"9-japonica-510x790-125x125.png\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:30:\"9-japonica-510x790-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:30:\"9-japonica-510x790-300x464.png\";s:5:\"width\";i:300;s:6:\"height\";i:464;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:30:\"9-japonica-510x790-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:30:\"9-japonica-510x790-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:30:\"9-japonica-510x790-300x464.png\";s:5:\"width\";i:300;s:6:\"height\";i:464;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:30:\"9-japonica-510x790-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1316, 206, '_wp_attached_file', '2018/04/10-key-510x708.png'),
(1317, 206, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:576;s:6:\"height\";i:798;s:4:\"file\";s:26:\"2018/04/10-key-510x708.png\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:26:\"10-key-510x708-108x150.png\";s:5:\"width\";i:108;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:26:\"10-key-510x708-217x300.png\";s:5:\"width\";i:217;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:26:\"10-key-510x708-125x125.png\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:26:\"10-key-510x708-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:26:\"10-key-510x708-300x416.png\";s:5:\"width\";i:300;s:6:\"height\";i:416;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:26:\"10-key-510x708-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:26:\"10-key-510x708-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:26:\"10-key-510x708-300x416.png\";s:5:\"width\";i:300;s:6:\"height\";i:416;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:26:\"10-key-510x708-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1318, 207, '_wp_attached_file', '2018/04/11-mother-angel-child-510x735.png'),
(1319, 207, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:525;s:6:\"height\";i:762;s:4:\"file\";s:41:\"2018/04/11-mother-angel-child-510x735.png\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:41:\"11-mother-angel-child-510x735-103x150.png\";s:5:\"width\";i:103;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:41:\"11-mother-angel-child-510x735-207x300.png\";s:5:\"width\";i:207;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:41:\"11-mother-angel-child-510x735-125x125.png\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:41:\"11-mother-angel-child-510x735-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:41:\"11-mother-angel-child-510x735-300x435.png\";s:5:\"width\";i:300;s:6:\"height\";i:435;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:41:\"11-mother-angel-child-510x735-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:41:\"11-mother-angel-child-510x735-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:41:\"11-mother-angel-child-510x735-300x435.png\";s:5:\"width\";i:300;s:6:\"height\";i:435;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:41:\"11-mother-angel-child-510x735-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1320, 208, '_wp_attached_file', '2018/04/12-moon-beauty-510x425.png'),
(1321, 208, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:585;s:6:\"height\";i:486;s:4:\"file\";s:34:\"2018/04/12-moon-beauty-510x425.png\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:34:\"12-moon-beauty-510x425-150x125.png\";s:5:\"width\";i:150;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:34:\"12-moon-beauty-510x425-300x249.png\";s:5:\"width\";i:300;s:6:\"height\";i:249;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:34:\"12-moon-beauty-510x425-125x125.png\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:34:\"12-moon-beauty-510x425-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:34:\"12-moon-beauty-510x425-300x249.png\";s:5:\"width\";i:300;s:6:\"height\";i:249;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:34:\"12-moon-beauty-510x425-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:34:\"12-moon-beauty-510x425-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:34:\"12-moon-beauty-510x425-300x249.png\";s:5:\"width\";i:300;s:6:\"height\";i:249;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:34:\"12-moon-beauty-510x425-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1322, 197, '_thumbnail_id', '198'),
(1323, 197, 'gallery_size', 'Medium'),
(1324, 197, '_gallery_size', 'field_5ad776f9a7194'),
(1325, 197, 'gallery_year', '2018'),
(1326, 197, '_gallery_year', 'field_5ad74d51bcc7c'),
(1327, 209, '_edit_last', '1'),
(1328, 209, '_edit_lock', '1524078353:1'),
(1329, 209, '_thumbnail_id', '202'),
(1330, 209, 'gallery_size', 'Medium'),
(1331, 209, '_gallery_size', 'field_5ad776f9a7194'),
(1332, 209, 'gallery_year', '2018'),
(1333, 209, '_gallery_year', 'field_5ad74d51bcc7c'),
(1334, 210, '_edit_last', '1'),
(1335, 210, '_edit_lock', '1524078368:1'),
(1336, 210, '_thumbnail_id', '200'),
(1337, 210, 'gallery_size', 'Medium'),
(1338, 210, '_gallery_size', 'field_5ad776f9a7194'),
(1339, 210, 'gallery_year', '2018'),
(1340, 210, '_gallery_year', 'field_5ad74d51bcc7c'),
(1341, 211, '_edit_last', '1'),
(1342, 211, '_edit_lock', '1524078378:1'),
(1343, 211, '_thumbnail_id', '201'),
(1344, 211, 'gallery_size', 'Medium'),
(1345, 211, '_gallery_size', 'field_5ad776f9a7194'),
(1346, 211, 'gallery_year', '2018'),
(1347, 211, '_gallery_year', 'field_5ad74d51bcc7c'),
(1348, 212, '_edit_last', '1'),
(1349, 212, '_edit_lock', '1524078386:1'),
(1350, 213, '_wp_attached_file', '2018/04/1-glove-man-510x715.png'),
(1351, 213, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:585;s:6:\"height\";i:816;s:4:\"file\";s:31:\"2018/04/1-glove-man-510x715.png\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"1-glove-man-510x715-108x150.png\";s:5:\"width\";i:108;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"1-glove-man-510x715-215x300.png\";s:5:\"width\";i:215;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:31:\"1-glove-man-510x715-125x125.png\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:31:\"1-glove-man-510x715-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:31:\"1-glove-man-510x715-300x418.png\";s:5:\"width\";i:300;s:6:\"height\";i:418;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:31:\"1-glove-man-510x715-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:31:\"1-glove-man-510x715-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:31:\"1-glove-man-510x715-300x418.png\";s:5:\"width\";i:300;s:6:\"height\";i:418;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:31:\"1-glove-man-510x715-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1352, 212, '_thumbnail_id', '213'),
(1353, 212, 'gallery_size', 'Medium'),
(1354, 212, '_gallery_size', 'field_5ad776f9a7194'),
(1355, 212, 'gallery_year', '2018'),
(1356, 212, '_gallery_year', 'field_5ad74d51bcc7c'),
(1357, 214, '_edit_last', '1'),
(1358, 214, '_edit_lock', '1524078397:1'),
(1359, 214, '_thumbnail_id', '203'),
(1360, 214, 'gallery_size', 'Medium'),
(1361, 214, '_gallery_size', 'field_5ad776f9a7194'),
(1362, 214, 'gallery_year', '2018'),
(1363, 214, '_gallery_year', 'field_5ad74d51bcc7c'),
(1364, 215, '_edit_last', '1'),
(1365, 215, '_edit_lock', '1524078406:1'),
(1366, 215, '_thumbnail_id', '204'),
(1367, 215, 'gallery_size', 'Medium'),
(1368, 215, '_gallery_size', 'field_5ad776f9a7194'),
(1369, 215, 'gallery_year', '2018'),
(1370, 215, '_gallery_year', 'field_5ad74d51bcc7c'),
(1371, 216, '_edit_last', '1'),
(1372, 216, '_edit_lock', '1524078418:1'),
(1373, 216, '_thumbnail_id', '205'),
(1374, 216, 'gallery_size', 'Medium'),
(1375, 216, '_gallery_size', 'field_5ad776f9a7194'),
(1376, 216, 'gallery_year', '2018'),
(1377, 216, '_gallery_year', 'field_5ad74d51bcc7c'),
(1378, 217, '_edit_last', '1'),
(1379, 217, '_edit_lock', '1524078427:1'),
(1380, 217, '_thumbnail_id', '206'),
(1381, 217, 'gallery_size', 'Medium'),
(1382, 217, '_gallery_size', 'field_5ad776f9a7194'),
(1383, 217, 'gallery_year', '2018'),
(1384, 217, '_gallery_year', 'field_5ad74d51bcc7c'),
(1385, 218, '_edit_last', '1'),
(1386, 218, '_edit_lock', '1524078434:1'),
(1387, 218, '_thumbnail_id', '207'),
(1388, 218, 'gallery_size', 'Medium'),
(1389, 218, '_gallery_size', 'field_5ad776f9a7194'),
(1390, 218, 'gallery_year', '2018'),
(1391, 218, '_gallery_year', 'field_5ad74d51bcc7c'),
(1392, 219, '_edit_last', '1'),
(1393, 219, '_edit_lock', '1524078443:1'),
(1394, 219, '_thumbnail_id', '208'),
(1395, 219, 'gallery_size', 'Medium'),
(1396, 219, '_gallery_size', 'field_5ad776f9a7194'),
(1397, 219, 'gallery_year', '2018'),
(1398, 219, '_gallery_year', 'field_5ad74d51bcc7c'),
(1399, 219, 'gallery_medium', 'Medium'),
(1400, 219, '_gallery_medium', 'field_5ad74ce5bcc7b'),
(1401, 218, 'gallery_medium', 'Medium'),
(1402, 218, '_gallery_medium', 'field_5ad74ce5bcc7b'),
(1403, 217, 'gallery_medium', 'Medium'),
(1404, 217, '_gallery_medium', 'field_5ad74ce5bcc7b'),
(1405, 216, 'gallery_medium', 'Medium'),
(1406, 216, '_gallery_medium', 'field_5ad74ce5bcc7b'),
(1407, 215, 'gallery_medium', 'Medium'),
(1408, 215, '_gallery_medium', 'field_5ad74ce5bcc7b'),
(1409, 214, 'gallery_medium', 'Medium'),
(1410, 214, '_gallery_medium', 'field_5ad74ce5bcc7b'),
(1411, 212, 'gallery_medium', 'Medium'),
(1412, 212, '_gallery_medium', 'field_5ad74ce5bcc7b'),
(1413, 211, 'gallery_medium', 'Medium'),
(1414, 211, '_gallery_medium', 'field_5ad74ce5bcc7b'),
(1415, 210, 'gallery_medium', 'Medium'),
(1416, 210, '_gallery_medium', 'field_5ad74ce5bcc7b'),
(1417, 209, 'gallery_medium', 'Medium'),
(1418, 209, '_gallery_medium', 'field_5ad74ce5bcc7b'),
(1419, 197, 'gallery_medium', 'Medium'),
(1420, 197, '_gallery_medium', 'field_5ad74ce5bcc7b'),
(1421, 38, 'gallery_medium', 'Medium'),
(1422, 38, '_gallery_medium', 'field_5ad74ce5bcc7b'),
(1423, 221, '_wp_attached_file', '2018/04/bar-mitzva-on-japonica-510x628.png'),
(1424, 221, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:461;s:6:\"height\";i:567;s:4:\"file\";s:42:\"2018/04/bar-mitzva-on-japonica-510x628.png\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:42:\"bar-mitzva-on-japonica-510x628-122x150.png\";s:5:\"width\";i:122;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:42:\"bar-mitzva-on-japonica-510x628-244x300.png\";s:5:\"width\";i:244;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:42:\"bar-mitzva-on-japonica-510x628-125x125.png\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:42:\"bar-mitzva-on-japonica-510x628-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:42:\"bar-mitzva-on-japonica-510x628-300x369.png\";s:5:\"width\";i:300;s:6:\"height\";i:369;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:42:\"bar-mitzva-on-japonica-510x628-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:42:\"bar-mitzva-on-japonica-510x628-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:42:\"bar-mitzva-on-japonica-510x628-300x369.png\";s:5:\"width\";i:300;s:6:\"height\";i:369;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:42:\"bar-mitzva-on-japonica-510x628-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1425, 38, '_thumbnail_id', '221'),
(1426, 222, '_wp_attached_file', '2018/04/DSC02390.jpg'),
(1427, 222, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1600;s:6:\"height\";i:1193;s:4:\"file\";s:20:\"2018/04/DSC02390.jpg\";s:5:\"sizes\";a:11:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC02390-150x112.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:112;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"DSC02390-300x224.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:224;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"DSC02390-768x573.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:573;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"DSC02390-1024x764.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:764;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC02390-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:20:\"DSC02390-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:20:\"DSC02390-300x224.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:224;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC02390-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:20:\"DSC02390-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:20:\"DSC02390-300x224.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:224;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC02390-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1428, 223, '_wp_attached_file', '2018/04/DSC02391.jpg');
INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1429, 223, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1600;s:6:\"height\";i:1126;s:4:\"file\";s:20:\"2018/04/DSC02391.jpg\";s:5:\"sizes\";a:11:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC02391-150x106.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:106;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"DSC02391-300x211.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:211;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"DSC02391-768x540.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:540;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"DSC02391-1024x721.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:721;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC02391-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:20:\"DSC02391-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:20:\"DSC02391-300x211.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:211;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC02391-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:20:\"DSC02391-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:20:\"DSC02391-300x211.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:211;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC02391-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1430, 224, '_wp_attached_file', '2018/04/DSC02392.jpg'),
(1431, 224, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1600;s:6:\"height\";i:1169;s:4:\"file\";s:20:\"2018/04/DSC02392.jpg\";s:5:\"sizes\";a:11:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC02392-150x110.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:110;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"DSC02392-300x219.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:219;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"DSC02392-768x561.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:561;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"DSC02392-1024x748.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:748;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC02392-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:20:\"DSC02392-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:20:\"DSC02392-300x219.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:219;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC02392-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:20:\"DSC02392-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:20:\"DSC02392-300x219.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:219;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC02392-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1432, 225, '_wp_attached_file', '2018/04/DSC02395.jpg'),
(1433, 225, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1600;s:6:\"height\";i:1190;s:4:\"file\";s:20:\"2018/04/DSC02395.jpg\";s:5:\"sizes\";a:11:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC02395-150x112.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:112;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"DSC02395-300x223.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:223;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"DSC02395-768x571.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:571;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"DSC02395-1024x762.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:762;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC02395-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:20:\"DSC02395-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:20:\"DSC02395-300x223.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:223;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC02395-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:20:\"DSC02395-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:20:\"DSC02395-300x223.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:223;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC02395-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1434, 226, '_wp_attached_file', '2018/04/DSC02396.jpg'),
(1435, 226, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1600;s:6:\"height\";i:996;s:4:\"file\";s:20:\"2018/04/DSC02396.jpg\";s:5:\"sizes\";a:11:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"DSC02396-150x93.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:93;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"DSC02396-300x187.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:187;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"DSC02396-768x478.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:478;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"DSC02396-1024x637.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:637;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC02396-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:20:\"DSC02396-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:20:\"DSC02396-300x187.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:187;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC02396-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:20:\"DSC02396-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:20:\"DSC02396-300x187.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:187;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC02396-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1436, 227, '_wp_attached_file', '2018/04/DSC02399.jpg'),
(1437, 227, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1600;s:6:\"height\";i:1216;s:4:\"file\";s:20:\"2018/04/DSC02399.jpg\";s:5:\"sizes\";a:11:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC02399-150x114.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:114;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"DSC02399-300x228.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:228;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"DSC02399-768x584.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:584;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"DSC02399-1024x778.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:778;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC02399-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:20:\"DSC02399-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:20:\"DSC02399-300x228.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:228;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC02399-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:20:\"DSC02399-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:20:\"DSC02399-300x228.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:228;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC02399-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1438, 228, '_wp_attached_file', '2018/04/DSC023911.jpg'),
(1439, 228, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1600;s:6:\"height\";i:1126;s:4:\"file\";s:21:\"2018/04/DSC023911.jpg\";s:5:\"sizes\";a:11:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"DSC023911-150x106.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:106;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"DSC023911-300x211.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:211;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"DSC023911-768x540.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:540;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:22:\"DSC023911-1024x721.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:721;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:21:\"DSC023911-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:21:\"DSC023911-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:21:\"DSC023911-300x211.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:211;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:21:\"DSC023911-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:21:\"DSC023911-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:21:\"DSC023911-300x211.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:211;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:21:\"DSC023911-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1444, 232, '_wp_attached_file', '2018/04/relief-print-1.jpg'),
(1445, 232, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:422;s:6:\"height\";i:556;s:4:\"file\";s:26:\"2018/04/relief-print-1.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:26:\"relief-print-1-114x150.jpg\";s:5:\"width\";i:114;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:26:\"relief-print-1-228x300.jpg\";s:5:\"width\";i:228;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:26:\"relief-print-1-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:26:\"relief-print-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:26:\"relief-print-1-300x395.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:395;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:26:\"relief-print-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:26:\"relief-print-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:26:\"relief-print-1-300x395.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:395;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:26:\"relief-print-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1446, 233, '_wp_attached_file', '2018/04/relief-print-4.jpg'),
(1447, 233, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:475;s:6:\"height\";i:360;s:4:\"file\";s:26:\"2018/04/relief-print-4.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:26:\"relief-print-4-150x114.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:114;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:26:\"relief-print-4-300x227.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:227;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:26:\"relief-print-4-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:26:\"relief-print-4-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:26:\"relief-print-4-300x227.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:227;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:26:\"relief-print-4-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:26:\"relief-print-4-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:26:\"relief-print-4-300x227.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:227;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:26:\"relief-print-4-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1448, 234, '_sku', ''),
(1449, 234, '_regular_price', '30000'),
(1450, 234, '_sale_price', ''),
(1451, 234, '_sale_price_dates_from', ''),
(1452, 234, '_sale_price_dates_to', ''),
(1453, 234, 'total_sales', '0'),
(1454, 234, '_tax_status', 'taxable'),
(1455, 234, '_tax_class', ''),
(1456, 234, '_manage_stock', 'no'),
(1457, 234, '_backorders', 'no'),
(1458, 234, '_sold_individually', 'yes'),
(1459, 234, '_weight', ''),
(1460, 234, '_length', ''),
(1461, 234, '_width', ''),
(1462, 234, '_height', ''),
(1463, 234, '_upsell_ids', 'a:0:{}'),
(1464, 234, '_crosssell_ids', 'a:0:{}'),
(1465, 234, '_purchase_note', ''),
(1466, 234, '_default_attributes', 'a:0:{}'),
(1467, 234, '_virtual', 'no'),
(1468, 234, '_downloadable', 'no'),
(1469, 234, '_product_image_gallery', ''),
(1470, 234, '_download_limit', '-1'),
(1471, 234, '_download_expiry', '-1'),
(1472, 234, '_thumbnail_id', '224'),
(1473, 234, '_stock', NULL),
(1474, 234, '_stock_status', 'instock'),
(1475, 234, '_wc_average_rating', '0'),
(1476, 234, '_wc_rating_count', 'a:0:{}'),
(1477, 234, '_wc_review_count', '0'),
(1478, 234, '_downloadable_files', 'a:0:{}'),
(1479, 234, '_product_attributes', 'a:0:{}'),
(1480, 234, '_product_version', '3.3.5'),
(1481, 234, '_price', '30000'),
(1482, 234, '_edit_lock', '1524155089:1'),
(1483, 234, '_edit_last', '1'),
(1484, 235, '_sku', ''),
(1485, 235, '_regular_price', '30000'),
(1486, 235, '_sale_price', ''),
(1487, 235, '_sale_price_dates_from', ''),
(1488, 235, '_sale_price_dates_to', ''),
(1489, 235, 'total_sales', '0'),
(1490, 235, '_tax_status', 'taxable'),
(1491, 235, '_tax_class', ''),
(1492, 235, '_manage_stock', 'no'),
(1493, 235, '_backorders', 'no'),
(1494, 235, '_sold_individually', 'yes'),
(1495, 235, '_weight', ''),
(1496, 235, '_length', ''),
(1497, 235, '_width', ''),
(1498, 235, '_height', ''),
(1499, 235, '_upsell_ids', 'a:0:{}'),
(1500, 235, '_crosssell_ids', 'a:0:{}'),
(1501, 235, '_purchase_note', ''),
(1502, 235, '_default_attributes', 'a:0:{}'),
(1503, 235, '_virtual', 'no'),
(1504, 235, '_downloadable', 'no'),
(1505, 235, '_product_image_gallery', ''),
(1506, 235, '_download_limit', '-1'),
(1507, 235, '_download_expiry', '-1'),
(1508, 235, '_thumbnail_id', '226'),
(1509, 235, '_stock', NULL),
(1510, 235, '_stock_status', 'instock'),
(1511, 235, '_wc_average_rating', '0'),
(1512, 235, '_wc_rating_count', 'a:0:{}'),
(1513, 235, '_wc_review_count', '0'),
(1514, 235, '_downloadable_files', 'a:0:{}'),
(1515, 235, '_product_attributes', 'a:0:{}'),
(1516, 235, '_product_version', '3.3.5'),
(1517, 235, '_price', '30000'),
(1518, 235, '_edit_lock', '1524155096:1'),
(1519, 235, '_edit_last', '1'),
(1520, 236, '_sku', ''),
(1521, 236, '_regular_price', '30000'),
(1522, 236, '_sale_price', ''),
(1523, 236, '_sale_price_dates_from', ''),
(1524, 236, '_sale_price_dates_to', ''),
(1525, 236, 'total_sales', '0'),
(1526, 236, '_tax_status', 'taxable'),
(1527, 236, '_tax_class', ''),
(1528, 236, '_manage_stock', 'no'),
(1529, 236, '_backorders', 'no'),
(1530, 236, '_sold_individually', 'yes'),
(1531, 236, '_weight', ''),
(1532, 236, '_length', ''),
(1533, 236, '_width', ''),
(1534, 236, '_height', ''),
(1535, 236, '_upsell_ids', 'a:0:{}'),
(1536, 236, '_crosssell_ids', 'a:0:{}'),
(1537, 236, '_purchase_note', ''),
(1538, 236, '_default_attributes', 'a:0:{}'),
(1539, 236, '_virtual', 'no'),
(1540, 236, '_downloadable', 'no'),
(1541, 236, '_product_image_gallery', ''),
(1542, 236, '_download_limit', '-1'),
(1543, 236, '_download_expiry', '-1'),
(1544, 236, '_thumbnail_id', '233'),
(1545, 236, '_stock', NULL),
(1546, 236, '_stock_status', 'instock'),
(1547, 236, '_wc_average_rating', '0'),
(1548, 236, '_wc_rating_count', 'a:0:{}'),
(1549, 236, '_wc_review_count', '0'),
(1550, 236, '_downloadable_files', 'a:0:{}'),
(1551, 236, '_product_attributes', 'a:0:{}'),
(1552, 236, '_product_version', '3.3.5'),
(1553, 236, '_price', '30000'),
(1554, 236, '_edit_lock', '1524155103:1'),
(1555, 236, '_edit_last', '1'),
(1556, 237, '_sku', ''),
(1557, 237, '_regular_price', '30000'),
(1558, 237, '_sale_price', ''),
(1559, 237, '_sale_price_dates_from', ''),
(1560, 237, '_sale_price_dates_to', ''),
(1561, 237, 'total_sales', '0'),
(1562, 237, '_tax_status', 'taxable'),
(1563, 237, '_tax_class', ''),
(1564, 237, '_manage_stock', 'no'),
(1565, 237, '_backorders', 'no'),
(1566, 237, '_sold_individually', 'yes'),
(1567, 237, '_weight', ''),
(1568, 237, '_length', ''),
(1569, 237, '_width', ''),
(1570, 237, '_height', ''),
(1571, 237, '_upsell_ids', 'a:0:{}'),
(1572, 237, '_crosssell_ids', 'a:0:{}'),
(1573, 237, '_purchase_note', ''),
(1574, 237, '_default_attributes', 'a:0:{}'),
(1575, 237, '_virtual', 'no'),
(1576, 237, '_downloadable', 'no'),
(1577, 237, '_product_image_gallery', ''),
(1578, 237, '_download_limit', '-1'),
(1579, 237, '_download_expiry', '-1'),
(1580, 237, '_thumbnail_id', '222'),
(1581, 237, '_stock', NULL),
(1582, 237, '_stock_status', 'instock'),
(1583, 237, '_wc_average_rating', '0'),
(1584, 237, '_wc_rating_count', 'a:0:{}'),
(1585, 237, '_wc_review_count', '0'),
(1586, 237, '_downloadable_files', 'a:0:{}'),
(1587, 237, '_product_attributes', 'a:0:{}'),
(1588, 237, '_product_version', '3.3.5'),
(1589, 237, '_price', '30000'),
(1590, 237, '_edit_lock', '1524155111:1'),
(1591, 237, '_edit_last', '1'),
(1592, 238, '_sku', ''),
(1593, 238, '_regular_price', '30000'),
(1594, 238, '_sale_price', ''),
(1595, 238, '_sale_price_dates_from', ''),
(1596, 238, '_sale_price_dates_to', ''),
(1597, 238, 'total_sales', '0'),
(1598, 238, '_tax_status', 'taxable'),
(1599, 238, '_tax_class', ''),
(1600, 238, '_manage_stock', 'no'),
(1601, 238, '_backorders', 'no'),
(1602, 238, '_sold_individually', 'yes'),
(1603, 238, '_weight', ''),
(1604, 238, '_length', ''),
(1605, 238, '_width', ''),
(1606, 238, '_height', ''),
(1607, 238, '_upsell_ids', 'a:0:{}'),
(1608, 238, '_crosssell_ids', 'a:0:{}'),
(1609, 238, '_purchase_note', ''),
(1610, 238, '_default_attributes', 'a:0:{}'),
(1611, 238, '_virtual', 'no'),
(1612, 238, '_downloadable', 'no'),
(1613, 238, '_product_image_gallery', ''),
(1614, 238, '_download_limit', '-1'),
(1615, 238, '_download_expiry', '-1'),
(1616, 238, '_thumbnail_id', '232'),
(1617, 238, '_stock', NULL),
(1618, 238, '_stock_status', 'outofstock'),
(1619, 238, '_wc_average_rating', '0'),
(1620, 238, '_wc_rating_count', 'a:0:{}'),
(1621, 238, '_wc_review_count', '0'),
(1622, 238, '_downloadable_files', 'a:0:{}'),
(1623, 238, '_product_attributes', 'a:0:{}'),
(1624, 238, '_product_version', '3.3.5'),
(1625, 238, '_price', '30000'),
(1626, 238, '_edit_lock', '1524155117:1'),
(1627, 238, '_edit_last', '1'),
(1628, 239, '_sku', ''),
(1629, 239, '_regular_price', '30000'),
(1630, 239, '_sale_price', ''),
(1631, 239, '_sale_price_dates_from', ''),
(1632, 239, '_sale_price_dates_to', ''),
(1633, 239, 'total_sales', '0'),
(1634, 239, '_tax_status', 'taxable'),
(1635, 239, '_tax_class', ''),
(1636, 239, '_manage_stock', 'no'),
(1637, 239, '_backorders', 'no'),
(1638, 239, '_sold_individually', 'yes'),
(1639, 239, '_weight', ''),
(1640, 239, '_length', ''),
(1641, 239, '_width', ''),
(1642, 239, '_height', ''),
(1643, 239, '_upsell_ids', 'a:0:{}'),
(1644, 239, '_crosssell_ids', 'a:0:{}'),
(1645, 239, '_purchase_note', ''),
(1646, 239, '_default_attributes', 'a:0:{}'),
(1647, 239, '_virtual', 'no'),
(1648, 239, '_downloadable', 'no'),
(1649, 239, '_product_image_gallery', ''),
(1650, 239, '_download_limit', '-1'),
(1651, 239, '_download_expiry', '-1'),
(1652, 239, '_thumbnail_id', '227'),
(1653, 239, '_stock', NULL),
(1654, 239, '_stock_status', 'instock'),
(1655, 239, '_wc_average_rating', '0'),
(1656, 239, '_wc_rating_count', 'a:0:{}'),
(1657, 239, '_wc_review_count', '0'),
(1658, 239, '_downloadable_files', 'a:0:{}'),
(1659, 239, '_product_attributes', 'a:0:{}'),
(1660, 239, '_product_version', '3.3.5'),
(1661, 239, '_price', '30000'),
(1662, 239, '_edit_lock', '1524155124:1'),
(1663, 239, '_edit_last', '1'),
(1664, 240, '_sku', ''),
(1665, 240, '_regular_price', '30000'),
(1666, 240, '_sale_price', ''),
(1667, 240, '_sale_price_dates_from', ''),
(1668, 240, '_sale_price_dates_to', ''),
(1669, 240, 'total_sales', '0'),
(1670, 240, '_tax_status', 'taxable'),
(1671, 240, '_tax_class', ''),
(1672, 240, '_manage_stock', 'no'),
(1673, 240, '_backorders', 'no'),
(1674, 240, '_sold_individually', 'yes'),
(1675, 240, '_weight', ''),
(1676, 240, '_length', ''),
(1677, 240, '_width', ''),
(1678, 240, '_height', ''),
(1679, 240, '_upsell_ids', 'a:0:{}'),
(1680, 240, '_crosssell_ids', 'a:0:{}'),
(1681, 240, '_purchase_note', ''),
(1682, 240, '_default_attributes', 'a:0:{}'),
(1683, 240, '_virtual', 'no'),
(1684, 240, '_downloadable', 'no'),
(1685, 240, '_product_image_gallery', ''),
(1686, 240, '_download_limit', '-1'),
(1687, 240, '_download_expiry', '-1'),
(1688, 240, '_thumbnail_id', '228'),
(1689, 240, '_stock', NULL),
(1690, 240, '_stock_status', 'instock'),
(1691, 240, '_wc_average_rating', '0'),
(1692, 240, '_wc_rating_count', 'a:0:{}'),
(1693, 240, '_wc_review_count', '0'),
(1694, 240, '_downloadable_files', 'a:0:{}'),
(1695, 240, '_product_attributes', 'a:0:{}'),
(1696, 240, '_product_version', '3.3.5'),
(1697, 240, '_price', '30000'),
(1698, 240, '_edit_lock', '1524155132:1'),
(1699, 240, '_edit_last', '1'),
(1700, 241, '_sku', ''),
(1701, 241, '_regular_price', '30000'),
(1702, 241, '_sale_price', ''),
(1703, 241, '_sale_price_dates_from', ''),
(1704, 241, '_sale_price_dates_to', ''),
(1705, 241, 'total_sales', '0'),
(1706, 241, '_tax_status', 'taxable'),
(1707, 241, '_tax_class', ''),
(1708, 241, '_manage_stock', 'no'),
(1709, 241, '_backorders', 'no'),
(1710, 241, '_sold_individually', 'yes'),
(1711, 241, '_weight', ''),
(1712, 241, '_length', ''),
(1713, 241, '_width', ''),
(1714, 241, '_height', ''),
(1715, 241, '_upsell_ids', 'a:0:{}'),
(1716, 241, '_crosssell_ids', 'a:0:{}'),
(1717, 241, '_purchase_note', ''),
(1718, 241, '_default_attributes', 'a:0:{}'),
(1719, 241, '_virtual', 'no'),
(1720, 241, '_downloadable', 'no'),
(1721, 241, '_product_image_gallery', ''),
(1722, 241, '_download_limit', '-1'),
(1723, 241, '_download_expiry', '-1'),
(1724, 241, '_thumbnail_id', '225'),
(1725, 241, '_stock', NULL),
(1726, 241, '_stock_status', 'outofstock'),
(1727, 241, '_wc_average_rating', '0'),
(1728, 241, '_wc_rating_count', 'a:0:{}'),
(1729, 241, '_wc_review_count', '0'),
(1730, 241, '_downloadable_files', 'a:0:{}'),
(1731, 241, '_product_attributes', 'a:0:{}'),
(1732, 241, '_product_version', '3.3.5'),
(1733, 241, '_price', '30000'),
(1734, 241, '_edit_lock', '1524155136:1'),
(1735, 241, '_edit_last', '1'),
(1736, 38, 'gallery_status', 'Available'),
(1737, 38, '_gallery_status', 'field_5ad796bd52c42'),
(1738, 197, 'gallery_status', 'Available'),
(1739, 197, '_gallery_status', 'field_5ad796bd52c42'),
(1740, 209, 'gallery_status', 'Available'),
(1741, 209, '_gallery_status', 'field_5ad796bd52c42'),
(1742, 210, 'gallery_status', 'Available'),
(1743, 210, '_gallery_status', 'field_5ad796bd52c42'),
(1744, 211, 'gallery_status', 'Available'),
(1745, 211, '_gallery_status', 'field_5ad796bd52c42'),
(1746, 212, 'gallery_status', 'Available'),
(1747, 212, '_gallery_status', 'field_5ad796bd52c42'),
(1748, 214, 'gallery_status', 'Available'),
(1749, 214, '_gallery_status', 'field_5ad796bd52c42'),
(1750, 215, 'gallery_status', 'Available'),
(1751, 215, '_gallery_status', 'field_5ad796bd52c42'),
(1752, 216, 'gallery_status', 'Available'),
(1753, 216, '_gallery_status', 'field_5ad796bd52c42'),
(1754, 217, 'gallery_status', 'Available'),
(1755, 217, '_gallery_status', 'field_5ad796bd52c42'),
(1756, 218, 'gallery_status', 'Available'),
(1757, 218, '_gallery_status', 'field_5ad796bd52c42'),
(1758, 219, 'gallery_status', 'Available'),
(1759, 219, '_gallery_status', 'field_5ad796bd52c42'),
(1760, 34, '_edit_last', '1'),
(1761, 36, '_edit_lock', '1524162640:1'),
(1762, 35, '_edit_last', '1'),
(1763, 35, '_wp_page_template', 'templates/template-page.php'),
(1764, 36, '_edit_last', '1'),
(1765, 36, '_wp_page_template', 'templates/template-page.php'),
(1766, 37, '_edit_lock', '1524150315:1'),
(1767, 37, '_edit_last', '1'),
(1768, 37, '_wp_page_template', 'templates/template-full-width.php'),
(1769, 247, '_edit_last', '1'),
(1770, 247, '_edit_lock', '1524157127:1'),
(1771, 39, '_product_attributes', 'a:0:{}'),
(1772, 39, 'product_size', '18”x12”'),
(1773, 39, '_product_size', 'field_5ad8cb36aa7af'),
(1774, 52, 'slideshow_0_slide_image', '60'),
(1775, 52, '_slideshow_0_slide_image', 'field_5ad95cc0219a7'),
(1776, 52, 'slideshow_0_slide_caption', 'Caption goes here'),
(1777, 52, '_slideshow_0_slide_caption', 'field_5ad95cd6219a8'),
(1778, 52, 'slideshow_1_slide_image', '58'),
(1779, 52, '_slideshow_1_slide_image', 'field_5ad95cc0219a7'),
(1780, 52, 'slideshow_1_slide_caption', 'Caption goes here'),
(1781, 52, '_slideshow_1_slide_caption', 'field_5ad95cd6219a8'),
(1782, 52, 'slideshow_2_slide_image', '59'),
(1783, 52, '_slideshow_2_slide_image', 'field_5ad95cc0219a7'),
(1784, 52, 'slideshow_2_slide_caption', 'Caption goes here'),
(1785, 52, '_slideshow_2_slide_caption', 'field_5ad95cd6219a8'),
(1786, 52, 'slideshow', '4'),
(1787, 52, '_slideshow', 'field_5accfebde011d'),
(1788, 251, 'studio_main_video', 'https://vimeo.com/245236016'),
(1789, 251, '_studio_main_video', 'field_5accb52e890ab'),
(1790, 251, 'studio_visit_description', 'Meet the artist and experience the studio in person. <br>Contact gallery representative Phyllis Van Orden to set<br> up an appointment.'),
(1791, 251, '_studio_visit_description', 'field_5accb5e2890ad'),
(1792, 251, 'studio_visit_cta_link', ''),
(1793, 251, '_studio_visit_cta_link', 'field_5accb604890af'),
(1794, 251, 'studio_visit_cta_text', 'Contact »'),
(1795, 251, '_studio_visit_cta_text', 'field_5accb5f3890ae'),
(1796, 251, 'studio_visit_headline', 'Schedule a Visit:'),
(1797, 251, '_studio_visit_headline', 'field_5accddbd0baff'),
(1798, 251, 'studio_videos', '3'),
(1799, 251, '_studio_videos', 'field_5accf625e0115'),
(1800, 251, 'studio_progress_header', 'In Progress'),
(1801, 251, '_studio_progress_header', 'field_5accfea1e011c'),
(1802, 251, 'studio_progress_background_image', '73'),
(1803, 251, '_studio_progress_background_image', 'field_5accfe88e011b'),
(1804, 251, 'studio_progress_slideshow_shortcode', ''),
(1805, 251, '_studio_progress_slideshow_shortcode', 'field_5accfebde011d'),
(1806, 251, 'studio_videos_0_studio_video_related_url', 'https://vimeo.com/244749533'),
(1807, 251, '_studio_videos_0_studio_video_related_url', 'field_5accf64ae0116'),
(1808, 251, 'studio_videos_0_studio_video_related_thumbnail', '83'),
(1809, 251, '_studio_videos_0_studio_video_related_thumbnail', 'field_5accf6cae0117'),
(1810, 251, 'studio_videos_0_studio_video_related_caption', 'The therapy of drawing.'),
(1811, 251, '_studio_videos_0_studio_video_related_caption', 'field_5accf704e0118'),
(1812, 251, 'studio_videos_1_studio_video_related_url', 'https://vimeo.com/244749306'),
(1813, 251, '_studio_videos_1_studio_video_related_url', 'field_5accf64ae0116'),
(1814, 251, 'studio_videos_1_studio_video_related_thumbnail', '81'),
(1815, 251, '_studio_videos_1_studio_video_related_thumbnail', 'field_5accf6cae0117'),
(1816, 251, 'studio_videos_1_studio_video_related_caption', 'Going through the archives.'),
(1817, 251, '_studio_videos_1_studio_video_related_caption', 'field_5accf704e0118'),
(1818, 251, 'studio_videos_2_studio_video_related_url', 'https://vimeo.com/249770248'),
(1819, 251, '_studio_videos_2_studio_video_related_url', 'field_5accf64ae0116'),
(1820, 251, 'studio_videos_2_studio_video_related_thumbnail', '82'),
(1821, 251, '_studio_videos_2_studio_video_related_thumbnail', 'field_5accf6cae0117'),
(1822, 251, 'studio_videos_2_studio_video_related_caption', 'Technique and process: ink to paper.'),
(1823, 251, '_studio_videos_2_studio_video_related_caption', 'field_5accf704e0118'),
(1824, 251, 'studio_main_video_caption', ''),
(1825, 251, '_studio_main_video_caption', 'field_5acd11915e5a0'),
(1826, 251, 'studio_related_videos_0_studio_related_video_url', 'https://vimeo.com/249770248'),
(1827, 251, '_studio_related_videos_0_studio_related_video_url', 'field_5accf64ae0116'),
(1828, 251, 'studio_related_videos_0_studio_related_video_thumbnail', '83'),
(1829, 251, '_studio_related_videos_0_studio_related_video_thumbnail', 'field_5accf6cae0117'),
(1830, 251, 'studio_related_videos_0_studio_related_video_caption', 'The therapy of drawing.'),
(1831, 251, '_studio_related_videos_0_studio_related_video_caption', 'field_5accf704e0118'),
(1832, 251, 'studio_related_videos_1_studio_related_video_url', 'https://vimeo.com/244749533'),
(1833, 251, '_studio_related_videos_1_studio_related_video_url', 'field_5accf64ae0116'),
(1834, 251, 'studio_related_videos_1_studio_related_video_thumbnail', '81'),
(1835, 251, '_studio_related_videos_1_studio_related_video_thumbnail', 'field_5accf6cae0117'),
(1836, 251, 'studio_related_videos_1_studio_related_video_caption', 'Going through the archives.'),
(1837, 251, '_studio_related_videos_1_studio_related_video_caption', 'field_5accf704e0118'),
(1838, 251, 'studio_related_videos_2_studio_related_video_url', 'https://vimeo.com/244749306'),
(1839, 251, '_studio_related_videos_2_studio_related_video_url', 'field_5accf64ae0116'),
(1840, 251, 'studio_related_videos_2_studio_related_video_thumbnail', '82'),
(1841, 251, '_studio_related_videos_2_studio_related_video_thumbnail', 'field_5accf6cae0117'),
(1842, 251, 'studio_related_videos_2_studio_related_video_caption', 'Technique and process: ink to paper.'),
(1843, 251, '_studio_related_videos_2_studio_related_video_caption', 'field_5accf704e0118'),
(1844, 251, 'studio_related_videos', '3'),
(1845, 251, '_studio_related_videos', 'field_5accf625e0115'),
(1846, 251, 'studi_visit_contact_shortcode', '[contact-form-7 id=\"78\" title=\"Contact form 1\"]'),
(1847, 251, '_studi_visit_contact_shortcode', 'field_5acfa23e6ce2f'),
(1848, 251, 'studio_visit_contact_shortcode', ''),
(1849, 251, '_studio_visit_contact_shortcode', 'field_5acfa23e6ce2f'),
(1850, 251, 'slideshow_0_slide_image', '60'),
(1851, 251, '_slideshow_0_slide_image', 'field_5ad95cc0219a7'),
(1852, 251, 'slideshow_0_slide_caption', 'Caption goes here'),
(1853, 251, '_slideshow_0_slide_caption', 'field_5ad95cd6219a8'),
(1854, 251, 'slideshow_1_slide_image', '58'),
(1855, 251, '_slideshow_1_slide_image', 'field_5ad95cc0219a7'),
(1856, 251, 'slideshow_1_slide_caption', 'Caption goes here'),
(1857, 251, '_slideshow_1_slide_caption', 'field_5ad95cd6219a8'),
(1858, 251, 'slideshow_2_slide_image', '59'),
(1859, 251, '_slideshow_2_slide_image', 'field_5ad95cc0219a7'),
(1860, 251, 'slideshow_2_slide_caption', 'Caption goes here'),
(1861, 251, '_slideshow_2_slide_caption', 'field_5ad95cd6219a8'),
(1862, 251, 'slideshow', '3'),
(1863, 251, '_slideshow', 'field_5accfebde011d'),
(1868, 252, 'studio_main_video', 'https://vimeo.com/245236016'),
(1869, 252, '_studio_main_video', 'field_5accb52e890ab'),
(1870, 252, 'studio_visit_description', 'Meet the artist and experience the studio in person. <br>Contact gallery representative Phyllis Van Orden to set<br> up an appointment.'),
(1871, 252, '_studio_visit_description', 'field_5accb5e2890ad'),
(1872, 252, 'studio_visit_cta_link', ''),
(1873, 252, '_studio_visit_cta_link', 'field_5accb604890af'),
(1874, 252, 'studio_visit_cta_text', 'Contact »'),
(1875, 252, '_studio_visit_cta_text', 'field_5accb5f3890ae'),
(1876, 252, 'studio_visit_headline', 'Schedule a Visit:'),
(1877, 252, '_studio_visit_headline', 'field_5accddbd0baff'),
(1878, 252, 'studio_videos', '3'),
(1879, 252, '_studio_videos', 'field_5accf625e0115'),
(1880, 252, 'studio_progress_header', 'In Progress'),
(1881, 252, '_studio_progress_header', 'field_5accfea1e011c'),
(1882, 252, 'studio_progress_background_image', '73'),
(1883, 252, '_studio_progress_background_image', 'field_5accfe88e011b'),
(1884, 252, 'studio_progress_slideshow_shortcode', ''),
(1885, 252, '_studio_progress_slideshow_shortcode', 'field_5accfebde011d'),
(1886, 252, 'studio_videos_0_studio_video_related_url', 'https://vimeo.com/244749533'),
(1887, 252, '_studio_videos_0_studio_video_related_url', 'field_5accf64ae0116'),
(1888, 252, 'studio_videos_0_studio_video_related_thumbnail', '83'),
(1889, 252, '_studio_videos_0_studio_video_related_thumbnail', 'field_5accf6cae0117'),
(1890, 252, 'studio_videos_0_studio_video_related_caption', 'The therapy of drawing.'),
(1891, 252, '_studio_videos_0_studio_video_related_caption', 'field_5accf704e0118'),
(1892, 252, 'studio_videos_1_studio_video_related_url', 'https://vimeo.com/244749306'),
(1893, 252, '_studio_videos_1_studio_video_related_url', 'field_5accf64ae0116'),
(1894, 252, 'studio_videos_1_studio_video_related_thumbnail', '81'),
(1895, 252, '_studio_videos_1_studio_video_related_thumbnail', 'field_5accf6cae0117'),
(1896, 252, 'studio_videos_1_studio_video_related_caption', 'Going through the archives.'),
(1897, 252, '_studio_videos_1_studio_video_related_caption', 'field_5accf704e0118'),
(1898, 252, 'studio_videos_2_studio_video_related_url', 'https://vimeo.com/249770248'),
(1899, 252, '_studio_videos_2_studio_video_related_url', 'field_5accf64ae0116'),
(1900, 252, 'studio_videos_2_studio_video_related_thumbnail', '82'),
(1901, 252, '_studio_videos_2_studio_video_related_thumbnail', 'field_5accf6cae0117'),
(1902, 252, 'studio_videos_2_studio_video_related_caption', 'Technique and process: ink to paper.'),
(1903, 252, '_studio_videos_2_studio_video_related_caption', 'field_5accf704e0118'),
(1904, 252, 'studio_main_video_caption', ''),
(1905, 252, '_studio_main_video_caption', 'field_5acd11915e5a0'),
(1906, 252, 'studio_related_videos_0_studio_related_video_url', 'https://vimeo.com/249770248'),
(1907, 252, '_studio_related_videos_0_studio_related_video_url', 'field_5accf64ae0116'),
(1908, 252, 'studio_related_videos_0_studio_related_video_thumbnail', '83'),
(1909, 252, '_studio_related_videos_0_studio_related_video_thumbnail', 'field_5accf6cae0117'),
(1910, 252, 'studio_related_videos_0_studio_related_video_caption', 'The therapy of drawing.'),
(1911, 252, '_studio_related_videos_0_studio_related_video_caption', 'field_5accf704e0118'),
(1912, 252, 'studio_related_videos_1_studio_related_video_url', 'https://vimeo.com/244749533'),
(1913, 252, '_studio_related_videos_1_studio_related_video_url', 'field_5accf64ae0116'),
(1914, 252, 'studio_related_videos_1_studio_related_video_thumbnail', '81'),
(1915, 252, '_studio_related_videos_1_studio_related_video_thumbnail', 'field_5accf6cae0117'),
(1916, 252, 'studio_related_videos_1_studio_related_video_caption', 'Going through the archives.'),
(1917, 252, '_studio_related_videos_1_studio_related_video_caption', 'field_5accf704e0118'),
(1918, 252, 'studio_related_videos_2_studio_related_video_url', 'https://vimeo.com/244749306'),
(1919, 252, '_studio_related_videos_2_studio_related_video_url', 'field_5accf64ae0116'),
(1920, 252, 'studio_related_videos_2_studio_related_video_thumbnail', '82'),
(1921, 252, '_studio_related_videos_2_studio_related_video_thumbnail', 'field_5accf6cae0117'),
(1922, 252, 'studio_related_videos_2_studio_related_video_caption', 'Technique and process: ink to paper.'),
(1923, 252, '_studio_related_videos_2_studio_related_video_caption', 'field_5accf704e0118'),
(1924, 252, 'studio_related_videos', '3'),
(1925, 252, '_studio_related_videos', 'field_5accf625e0115'),
(1926, 252, 'studi_visit_contact_shortcode', '[contact-form-7 id=\"78\" title=\"Contact form 1\"]'),
(1927, 252, '_studi_visit_contact_shortcode', 'field_5acfa23e6ce2f'),
(1928, 252, 'studio_visit_contact_shortcode', ''),
(1929, 252, '_studio_visit_contact_shortcode', 'field_5acfa23e6ce2f'),
(1930, 252, 'slideshow_0_slide_image', '60'),
(1931, 252, '_slideshow_0_slide_image', 'field_5ad95cc0219a7'),
(1932, 252, 'slideshow_0_slide_caption', 'Caption goes here'),
(1933, 252, '_slideshow_0_slide_caption', 'field_5ad95cd6219a8'),
(1934, 252, 'slideshow_1_slide_image', '58'),
(1935, 252, '_slideshow_1_slide_image', 'field_5ad95cc0219a7'),
(1936, 252, 'slideshow_1_slide_caption', 'Caption goes here'),
(1937, 252, '_slideshow_1_slide_caption', 'field_5ad95cd6219a8'),
(1938, 252, 'slideshow_2_slide_image', '59'),
(1939, 252, '_slideshow_2_slide_image', 'field_5ad95cc0219a7'),
(1940, 252, 'slideshow_2_slide_caption', 'Caption goes here'),
(1941, 252, '_slideshow_2_slide_caption', 'field_5ad95cd6219a8'),
(1942, 252, 'slideshow', '4'),
(1943, 252, '_slideshow', 'field_5accfebde011d'),
(1944, 252, 'slideshow_3_slide_image', '58'),
(1945, 252, '_slideshow_3_slide_image', 'field_5ad95cc0219a7'),
(1946, 252, 'slideshow_3_slide_caption', 'Caption goes here'),
(1947, 252, '_slideshow_3_slide_caption', 'field_5ad95cd6219a8'),
(1948, 253, 'studio_main_video', 'https://vimeo.com/245236016'),
(1949, 253, '_studio_main_video', 'field_5accb52e890ab'),
(1950, 253, 'studio_visit_description', 'Meet the artist and experience the studio in person. <br>Contact gallery representative Phyllis Van Orden to set<br> up an appointment.'),
(1951, 253, '_studio_visit_description', 'field_5accb5e2890ad'),
(1952, 253, 'studio_visit_cta_link', ''),
(1953, 253, '_studio_visit_cta_link', 'field_5accb604890af'),
(1954, 253, 'studio_visit_cta_text', 'Contact »'),
(1955, 253, '_studio_visit_cta_text', 'field_5accb5f3890ae'),
(1956, 253, 'studio_visit_headline', 'Schedule a Visit:'),
(1957, 253, '_studio_visit_headline', 'field_5accddbd0baff'),
(1958, 253, 'studio_videos', '3'),
(1959, 253, '_studio_videos', 'field_5accf625e0115'),
(1960, 253, 'studio_progress_header', 'In Progress'),
(1961, 253, '_studio_progress_header', 'field_5accfea1e011c'),
(1962, 253, 'studio_progress_background_image', '73'),
(1963, 253, '_studio_progress_background_image', 'field_5accfe88e011b'),
(1964, 253, 'studio_progress_slideshow_shortcode', ''),
(1965, 253, '_studio_progress_slideshow_shortcode', 'field_5accfebde011d'),
(1966, 253, 'studio_videos_0_studio_video_related_url', 'https://vimeo.com/244749533'),
(1967, 253, '_studio_videos_0_studio_video_related_url', 'field_5accf64ae0116'),
(1968, 253, 'studio_videos_0_studio_video_related_thumbnail', '83'),
(1969, 253, '_studio_videos_0_studio_video_related_thumbnail', 'field_5accf6cae0117'),
(1970, 253, 'studio_videos_0_studio_video_related_caption', 'The therapy of drawing.'),
(1971, 253, '_studio_videos_0_studio_video_related_caption', 'field_5accf704e0118'),
(1972, 253, 'studio_videos_1_studio_video_related_url', 'https://vimeo.com/244749306'),
(1973, 253, '_studio_videos_1_studio_video_related_url', 'field_5accf64ae0116'),
(1974, 253, 'studio_videos_1_studio_video_related_thumbnail', '81'),
(1975, 253, '_studio_videos_1_studio_video_related_thumbnail', 'field_5accf6cae0117'),
(1976, 253, 'studio_videos_1_studio_video_related_caption', 'Going through the archives.'),
(1977, 253, '_studio_videos_1_studio_video_related_caption', 'field_5accf704e0118'),
(1978, 253, 'studio_videos_2_studio_video_related_url', 'https://vimeo.com/249770248'),
(1979, 253, '_studio_videos_2_studio_video_related_url', 'field_5accf64ae0116'),
(1980, 253, 'studio_videos_2_studio_video_related_thumbnail', '82'),
(1981, 253, '_studio_videos_2_studio_video_related_thumbnail', 'field_5accf6cae0117'),
(1982, 253, 'studio_videos_2_studio_video_related_caption', 'Technique and process: ink to paper.'),
(1983, 253, '_studio_videos_2_studio_video_related_caption', 'field_5accf704e0118'),
(1984, 253, 'studio_main_video_caption', ''),
(1985, 253, '_studio_main_video_caption', 'field_5acd11915e5a0'),
(1986, 253, 'studio_related_videos_0_studio_related_video_url', 'https://vimeo.com/249770248'),
(1987, 253, '_studio_related_videos_0_studio_related_video_url', 'field_5accf64ae0116'),
(1988, 253, 'studio_related_videos_0_studio_related_video_thumbnail', '83'),
(1989, 253, '_studio_related_videos_0_studio_related_video_thumbnail', 'field_5accf6cae0117'),
(1990, 253, 'studio_related_videos_0_studio_related_video_caption', 'The therapy of drawing.'),
(1991, 253, '_studio_related_videos_0_studio_related_video_caption', 'field_5accf704e0118'),
(1992, 253, 'studio_related_videos_1_studio_related_video_url', 'https://vimeo.com/244749533'),
(1993, 253, '_studio_related_videos_1_studio_related_video_url', 'field_5accf64ae0116'),
(1994, 253, 'studio_related_videos_1_studio_related_video_thumbnail', '81'),
(1995, 253, '_studio_related_videos_1_studio_related_video_thumbnail', 'field_5accf6cae0117'),
(1996, 253, 'studio_related_videos_1_studio_related_video_caption', 'Going through the archives.'),
(1997, 253, '_studio_related_videos_1_studio_related_video_caption', 'field_5accf704e0118'),
(1998, 253, 'studio_related_videos_2_studio_related_video_url', 'https://vimeo.com/244749306'),
(1999, 253, '_studio_related_videos_2_studio_related_video_url', 'field_5accf64ae0116'),
(2000, 253, 'studio_related_videos_2_studio_related_video_thumbnail', '82'),
(2001, 253, '_studio_related_videos_2_studio_related_video_thumbnail', 'field_5accf6cae0117'),
(2002, 253, 'studio_related_videos_2_studio_related_video_caption', 'Technique and process: ink to paper.'),
(2003, 253, '_studio_related_videos_2_studio_related_video_caption', 'field_5accf704e0118'),
(2004, 253, 'studio_related_videos', '3'),
(2005, 253, '_studio_related_videos', 'field_5accf625e0115'),
(2006, 253, 'studi_visit_contact_shortcode', '[contact-form-7 id=\"78\" title=\"Contact form 1\"]'),
(2007, 253, '_studi_visit_contact_shortcode', 'field_5acfa23e6ce2f'),
(2008, 253, 'studio_visit_contact_shortcode', ''),
(2009, 253, '_studio_visit_contact_shortcode', 'field_5acfa23e6ce2f'),
(2010, 253, 'slideshow_0_slide_image', '60'),
(2011, 253, '_slideshow_0_slide_image', 'field_5ad95cc0219a7'),
(2012, 253, 'slideshow_0_slide_caption', 'Caption goes here'),
(2013, 253, '_slideshow_0_slide_caption', 'field_5ad95cd6219a8'),
(2014, 253, 'slideshow_1_slide_image', '58'),
(2015, 253, '_slideshow_1_slide_image', 'field_5ad95cc0219a7'),
(2016, 253, 'slideshow_1_slide_caption', 'Caption goes here'),
(2017, 253, '_slideshow_1_slide_caption', 'field_5ad95cd6219a8'),
(2018, 253, 'slideshow_2_slide_image', '59'),
(2019, 253, '_slideshow_2_slide_image', 'field_5ad95cc0219a7'),
(2020, 253, 'slideshow_2_slide_caption', 'Caption goes here'),
(2021, 253, '_slideshow_2_slide_caption', 'field_5ad95cd6219a8'),
(2022, 253, 'slideshow', '3'),
(2023, 253, '_slideshow', 'field_5accfebde011d'),
(2024, 52, 'slideshow_3_slide_image', '58'),
(2025, 52, '_slideshow_3_slide_image', 'field_5ad95cc0219a7'),
(2026, 52, 'slideshow_3_slide_caption', 'Caption goes here'),
(2027, 52, '_slideshow_3_slide_caption', 'field_5ad95cd6219a8'),
(2028, 254, 'studio_main_video', 'https://vimeo.com/245236016'),
(2029, 254, '_studio_main_video', 'field_5accb52e890ab'),
(2030, 254, 'studio_visit_description', 'Meet the artist and experience the studio in person. <br>Contact gallery representative Phyllis Van Orden to set<br> up an appointment.'),
(2031, 254, '_studio_visit_description', 'field_5accb5e2890ad'),
(2032, 254, 'studio_visit_cta_link', ''),
(2033, 254, '_studio_visit_cta_link', 'field_5accb604890af'),
(2034, 254, 'studio_visit_cta_text', 'Contact »'),
(2035, 254, '_studio_visit_cta_text', 'field_5accb5f3890ae'),
(2036, 254, 'studio_visit_headline', 'Schedule a Visit:'),
(2037, 254, '_studio_visit_headline', 'field_5accddbd0baff'),
(2038, 254, 'studio_videos', '3'),
(2039, 254, '_studio_videos', 'field_5accf625e0115'),
(2040, 254, 'studio_progress_header', 'In Progress'),
(2041, 254, '_studio_progress_header', 'field_5accfea1e011c'),
(2042, 254, 'studio_progress_background_image', '73'),
(2043, 254, '_studio_progress_background_image', 'field_5accfe88e011b'),
(2044, 254, 'studio_progress_slideshow_shortcode', ''),
(2045, 254, '_studio_progress_slideshow_shortcode', 'field_5accfebde011d'),
(2046, 254, 'studio_videos_0_studio_video_related_url', 'https://vimeo.com/244749533'),
(2047, 254, '_studio_videos_0_studio_video_related_url', 'field_5accf64ae0116'),
(2048, 254, 'studio_videos_0_studio_video_related_thumbnail', '83'),
(2049, 254, '_studio_videos_0_studio_video_related_thumbnail', 'field_5accf6cae0117'),
(2050, 254, 'studio_videos_0_studio_video_related_caption', 'The therapy of drawing.'),
(2051, 254, '_studio_videos_0_studio_video_related_caption', 'field_5accf704e0118'),
(2052, 254, 'studio_videos_1_studio_video_related_url', 'https://vimeo.com/244749306'),
(2053, 254, '_studio_videos_1_studio_video_related_url', 'field_5accf64ae0116'),
(2054, 254, 'studio_videos_1_studio_video_related_thumbnail', '81'),
(2055, 254, '_studio_videos_1_studio_video_related_thumbnail', 'field_5accf6cae0117'),
(2056, 254, 'studio_videos_1_studio_video_related_caption', 'Going through the archives.'),
(2057, 254, '_studio_videos_1_studio_video_related_caption', 'field_5accf704e0118'),
(2058, 254, 'studio_videos_2_studio_video_related_url', 'https://vimeo.com/249770248'),
(2059, 254, '_studio_videos_2_studio_video_related_url', 'field_5accf64ae0116'),
(2060, 254, 'studio_videos_2_studio_video_related_thumbnail', '82'),
(2061, 254, '_studio_videos_2_studio_video_related_thumbnail', 'field_5accf6cae0117'),
(2062, 254, 'studio_videos_2_studio_video_related_caption', 'Technique and process: ink to paper.'),
(2063, 254, '_studio_videos_2_studio_video_related_caption', 'field_5accf704e0118'),
(2064, 254, 'studio_main_video_caption', ''),
(2065, 254, '_studio_main_video_caption', 'field_5acd11915e5a0'),
(2066, 254, 'studio_related_videos_0_studio_related_video_url', 'https://vimeo.com/249770248'),
(2067, 254, '_studio_related_videos_0_studio_related_video_url', 'field_5accf64ae0116');
INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(2068, 254, 'studio_related_videos_0_studio_related_video_thumbnail', '83'),
(2069, 254, '_studio_related_videos_0_studio_related_video_thumbnail', 'field_5accf6cae0117'),
(2070, 254, 'studio_related_videos_0_studio_related_video_caption', 'The therapy of drawing.'),
(2071, 254, '_studio_related_videos_0_studio_related_video_caption', 'field_5accf704e0118'),
(2072, 254, 'studio_related_videos_1_studio_related_video_url', 'https://vimeo.com/244749533'),
(2073, 254, '_studio_related_videos_1_studio_related_video_url', 'field_5accf64ae0116'),
(2074, 254, 'studio_related_videos_1_studio_related_video_thumbnail', '81'),
(2075, 254, '_studio_related_videos_1_studio_related_video_thumbnail', 'field_5accf6cae0117'),
(2076, 254, 'studio_related_videos_1_studio_related_video_caption', 'Going through the archives.'),
(2077, 254, '_studio_related_videos_1_studio_related_video_caption', 'field_5accf704e0118'),
(2078, 254, 'studio_related_videos_2_studio_related_video_url', 'https://vimeo.com/244749306'),
(2079, 254, '_studio_related_videos_2_studio_related_video_url', 'field_5accf64ae0116'),
(2080, 254, 'studio_related_videos_2_studio_related_video_thumbnail', '82'),
(2081, 254, '_studio_related_videos_2_studio_related_video_thumbnail', 'field_5accf6cae0117'),
(2082, 254, 'studio_related_videos_2_studio_related_video_caption', 'Technique and process: ink to paper.'),
(2083, 254, '_studio_related_videos_2_studio_related_video_caption', 'field_5accf704e0118'),
(2084, 254, 'studio_related_videos', '3'),
(2085, 254, '_studio_related_videos', 'field_5accf625e0115'),
(2086, 254, 'studi_visit_contact_shortcode', '[contact-form-7 id=\"78\" title=\"Contact form 1\"]'),
(2087, 254, '_studi_visit_contact_shortcode', 'field_5acfa23e6ce2f'),
(2088, 254, 'studio_visit_contact_shortcode', ''),
(2089, 254, '_studio_visit_contact_shortcode', 'field_5acfa23e6ce2f'),
(2090, 254, 'slideshow_0_slide_image', '60'),
(2091, 254, '_slideshow_0_slide_image', 'field_5ad95cc0219a7'),
(2092, 254, 'slideshow_0_slide_caption', 'Caption goes here'),
(2093, 254, '_slideshow_0_slide_caption', 'field_5ad95cd6219a8'),
(2094, 254, 'slideshow_1_slide_image', '58'),
(2095, 254, '_slideshow_1_slide_image', 'field_5ad95cc0219a7'),
(2096, 254, 'slideshow_1_slide_caption', 'Caption goes here'),
(2097, 254, '_slideshow_1_slide_caption', 'field_5ad95cd6219a8'),
(2098, 254, 'slideshow_2_slide_image', '59'),
(2099, 254, '_slideshow_2_slide_image', 'field_5ad95cc0219a7'),
(2100, 254, 'slideshow_2_slide_caption', 'Caption goes here'),
(2101, 254, '_slideshow_2_slide_caption', 'field_5ad95cd6219a8'),
(2102, 254, 'slideshow', '4'),
(2103, 254, '_slideshow', 'field_5accfebde011d'),
(2104, 254, 'slideshow_3_slide_image', '58'),
(2105, 254, '_slideshow_3_slide_image', 'field_5ad95cc0219a7'),
(2106, 254, 'slideshow_3_slide_caption', 'Caption goes here'),
(2107, 254, '_slideshow_3_slide_caption', 'field_5ad95cd6219a8');

-- --------------------------------------------------------

--
-- Table structure for table `wp_posts`
--

DROP TABLE IF EXISTS `wp_posts`;
CREATE TABLE `wp_posts` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `post_author` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_posts`
--

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2018-04-06 20:47:38', '2018-04-06 20:47:38', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'trash', 'open', 'open', '', 'hello-world__trashed', '', '', '2018-04-17 12:56:19', '2018-04-17 16:56:19', '', 0, 'http://morrisnathanson.dev.cc/?p=1', 0, 'post', '', 1),
(2, 1, '2018-04-06 20:47:38', '2018-04-06 20:47:38', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href=\"http://morrisnathanson.dev.cc/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'trash', 'closed', 'open', '', 'sample-page__trashed', '', '', '2018-04-09 15:56:23', '2018-04-09 15:56:23', '', 0, 'http://morrisnathanson.dev.cc/?page_id=2', 0, 'page', '', 0),
(4, 1, '2018-04-06 20:58:10', '2018-04-06 20:58:10', '', 'Homepage', '', 'publish', 'closed', 'closed', '', 'acf_homepage', '', '', '2018-04-06 20:58:48', '2018-04-06 20:58:48', '', 0, 'http://morrisnathanson.dev.cc/?post_type=acf&#038;p=4', 0, 'acf', '', 0),
(5, 1, '2018-04-06 20:58:28', '2018-04-06 20:58:28', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2018-04-16 16:26:58', '2018-04-16 20:26:58', '', 0, 'http://morrisnathanson.dev.cc/?page_id=5', 0, 'page', '', 0),
(6, 1, '2018-04-06 20:58:28', '2018-04-06 20:58:28', '', 'Home', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2018-04-06 20:58:28', '2018-04-06 20:58:28', '', 5, 'http://morrisnathanson.dev.cc/2018/04/06/5-revision-v1/', 0, 'revision', '', 0),
(8, 1, '2018-04-09 11:55:26', '2018-04-09 11:55:26', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:4:\"page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:1:\"5\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:8:\"seamless\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";a:1:{i:0;s:11:\"the_content\";}s:11:\"description\";s:0:\"\";}', 'Homepage', 'homepage', 'publish', 'closed', 'closed', '', 'group_5acb54ae907a5', '', '', '2018-04-13 15:14:04', '2018-04-13 19:14:04', '', 0, 'http://morrisnathanson.dev.cc/?post_type=acf-field-group&#038;p=8', 0, 'acf-field-group', '', 0),
(9, 1, '2018-04-09 11:55:26', '2018-04-09 11:55:26', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Banner Image', 'home_banner_image', 'publish', 'closed', 'closed', '', 'field_5ac7df22549dc', '', '', '2018-04-09 16:59:14', '2018-04-09 16:59:14', '', 8, 'http://morrisnathanson.dev.cc/?post_type=acf-field&#038;p=9', 1, 'acf-field', '', 0),
(10, 1, '2018-04-09 14:53:50', '2018-04-09 14:53:50', 'a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:4:\"left\";s:8:\"endpoint\";i:0;}', 'Banner', 'banner', 'publish', 'closed', 'closed', '', 'field_5acb54d8e6860', '', '', '2018-04-09 14:53:50', '2018-04-09 14:53:50', '', 8, 'http://morrisnathanson.dev.cc/?post_type=acf-field&p=10', 0, 'acf-field', '', 0),
(11, 1, '2018-04-09 14:53:50', '2018-04-09 14:53:50', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Headline', 'home_banner_headline', 'publish', 'closed', 'closed', '', 'field_5acb54f2e6861', '', '', '2018-04-09 14:53:50', '2018-04-09 14:53:50', '', 8, 'http://morrisnathanson.dev.cc/?post_type=acf-field&p=11', 2, 'acf-field', '', 0),
(12, 1, '2018-04-09 14:53:50', '2018-04-09 14:53:50', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'CTA Text', 'home_banner_cta_text', 'publish', 'closed', 'closed', '', 'field_5acb5515e6862', '', '', '2018-04-09 14:53:50', '2018-04-09 14:53:50', '', 8, 'http://morrisnathanson.dev.cc/?post_type=acf-field&p=12', 3, 'acf-field', '', 0),
(13, 1, '2018-04-09 14:53:50', '2018-04-09 14:53:50', 'a:10:{s:4:\"type\";s:9:\"page_link\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"post_type\";a:0:{}s:8:\"taxonomy\";a:0:{}s:10:\"allow_null\";i:0;s:14:\"allow_archives\";i:1;s:8:\"multiple\";i:0;}', 'CTA Link', 'home_banner_cta_link', 'publish', 'closed', 'closed', '', 'field_5acb5532e6863', '', '', '2018-04-09 14:53:50', '2018-04-09 14:53:50', '', 8, 'http://morrisnathanson.dev.cc/?post_type=acf-field&p=13', 4, 'acf-field', '', 0),
(14, 1, '2018-04-09 14:53:50', '2018-04-09 14:53:50', 'a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'View the Work', 'view_the_work', 'publish', 'closed', 'closed', '', 'field_5acb55b8e6864', '', '', '2018-04-11 12:00:31', '2018-04-11 16:00:31', '', 8, 'http://morrisnathanson.dev.cc/?post_type=acf-field&#038;p=14', 8, 'acf-field', '', 0),
(15, 1, '2018-04-09 15:56:23', '2018-04-09 15:56:23', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href=\"http://morrisnathanson.dev.cc/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2018-04-09 15:56:23', '2018-04-09 15:56:23', '', 2, 'http://morrisnathanson.dev.cc/2018/04/09/2-revision-v1/', 0, 'revision', '', 0),
(16, 1, '2018-04-09 15:56:33', '2018-04-09 15:56:33', '', 'morris-nathanson-2018-retrospective-exhibition-providence-art-club', '', 'inherit', 'open', 'closed', '', 'morris-nathanson-2018-retrospective-exhibition-providence-art-club', '', '', '2018-04-09 15:56:33', '2018-04-09 15:56:33', '', 5, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/morris-nathanson-2018-retrospective-exhibition-providence-art-club.jpg', 0, 'attachment', 'image/jpeg', 0),
(17, 1, '2018-04-09 15:56:33', '2018-04-09 15:56:33', '', 'morris-nathanson-archive-composite', '', 'inherit', 'open', 'closed', '', 'morris-nathanson-archive-composite', '', '', '2018-04-09 16:59:22', '2018-04-09 16:59:22', '', 5, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/morris-nathanson-archive-composite.jpg', 0, 'attachment', 'image/jpeg', 0),
(18, 1, '2018-04-09 15:56:34', '2018-04-09 15:56:34', '', 'morris-nathanson-pell-grant-waterfire-arts-center', '', 'inherit', 'open', 'closed', '', 'morris-nathanson-pell-grant-waterfire-arts-center', '', '', '2018-04-09 15:56:34', '2018-04-09 15:56:34', '', 5, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/morris-nathanson-pell-grant-waterfire-arts-center.jpg', 0, 'attachment', 'image/jpeg', 0),
(19, 1, '2018-04-09 15:56:34', '2018-04-09 15:56:34', '', 'morris-nathanson-portrait-homepage-banner', '', 'inherit', 'open', 'closed', '', 'morris-nathanson-portrait-homepage-banner', '', '', '2018-04-09 15:56:37', '2018-04-09 15:56:37', '', 5, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/morris-nathanson-portrait-homepage-banner.jpg', 0, 'attachment', 'image/jpeg', 0),
(20, 1, '2018-04-09 15:56:34', '2018-04-09 15:56:34', '', 'morris-nathanson-private-viewing-commission', '', 'inherit', 'open', 'closed', '', 'morris-nathanson-private-viewing-commission', '', '', '2018-04-09 15:56:34', '2018-04-09 15:56:34', '', 5, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/morris-nathanson-private-viewing-commission.jpg', 0, 'attachment', 'image/jpeg', 0),
(21, 1, '2018-04-09 15:56:35', '2018-04-09 15:56:35', '', 'morris-nathanson-studio-quote', '', 'inherit', 'open', 'closed', '', 'morris-nathanson-studio-quote', '', '', '2018-04-10 08:29:04', '2018-04-10 12:29:04', '', 5, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/morris-nathanson-studio-quote.jpg', 0, 'attachment', 'image/jpeg', 0),
(22, 1, '2018-04-09 15:57:09', '2018-04-09 15:57:09', '', 'Home', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2018-04-09 15:57:09', '2018-04-09 15:57:09', '', 5, 'http://morrisnathanson.dev.cc/2018/04/09/5-revision-v1/', 0, 'revision', '', 0),
(23, 1, '2018-04-09 16:59:14', '2018-04-09 16:59:14', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Background Image', 'home_cta_background_image', 'publish', 'closed', 'closed', '', 'field_5acb90daf1058', '', '', '2018-04-11 12:00:31', '2018-04-11 16:00:31', '', 8, 'http://morrisnathanson.dev.cc/?post_type=acf-field&#038;p=23', 9, 'acf-field', '', 0),
(24, 1, '2018-04-09 16:59:14', '2018-04-09 16:59:14', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'CTA Text', 'home_cta_text', 'publish', 'closed', 'closed', '', 'field_5acb90c3f1057', '', '', '2018-04-11 12:00:31', '2018-04-11 16:00:31', '', 8, 'http://morrisnathanson.dev.cc/?post_type=acf-field&#038;p=24', 10, 'acf-field', '', 0),
(25, 1, '2018-04-09 16:59:14', '2018-04-09 16:59:14', 'a:10:{s:4:\"type\";s:9:\"page_link\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"post_type\";a:0:{}s:8:\"taxonomy\";a:0:{}s:10:\"allow_null\";i:0;s:14:\"allow_archives\";i:1;s:8:\"multiple\";i:0;}', 'CTA Link', 'home_cta_link', 'publish', 'closed', 'closed', '', 'field_5acb9114f1059', '', '', '2018-04-11 12:00:31', '2018-04-11 16:00:31', '', 8, 'http://morrisnathanson.dev.cc/?post_type=acf-field&#038;p=25', 11, 'acf-field', '', 0),
(26, 1, '2018-04-09 16:59:40', '2018-04-09 16:59:40', '', 'Home', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2018-04-09 16:59:40', '2018-04-09 16:59:40', '', 5, 'http://morrisnathanson.dev.cc/2018/04/09/5-revision-v1/', 0, 'revision', '', 0),
(29, 1, '2018-04-09 18:22:29', '2018-04-09 18:22:29', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:7:\"gallery\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";a:1:{i:0;s:11:\"the_content\";}s:11:\"description\";s:0:\"\";}', 'Gallery (Single Post)', 'gallery-single-post', 'trash', 'closed', 'closed', '', 'group_5acbaeaecfd92__trashed', '', '', '2018-04-13 14:33:58', '2018-04-13 18:33:58', '', 0, 'http://morrisnathanson.dev.cc/?post_type=acf-field-group&#038;p=29', 0, 'acf-field-group', '', 0),
(30, 1, '2018-04-09 18:22:29', '2018-04-09 18:22:29', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:72:\"Brief description of the piece. This section should have about 15 words.\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Details', 'gallery_piece_details', 'trash', 'closed', 'closed', '', 'field_5acbaeb6ce7fc__trashed', '', '', '2018-04-13 14:33:58', '2018-04-13 18:33:58', '', 29, 'http://morrisnathanson.dev.cc/?post_type=acf-field&#038;p=30', 0, 'acf-field', '', 0),
(31, 1, '2018-04-09 18:22:29', '2018-04-09 18:22:29', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Medium', 'gallery_piece_medium', 'trash', 'closed', 'closed', '', 'field_5acbaf04ce7fd__trashed', '', '', '2018-04-13 14:33:58', '2018-04-13 18:33:58', '', 29, 'http://morrisnathanson.dev.cc/?post_type=acf-field&#038;p=31', 1, 'acf-field', '', 0),
(32, 1, '2018-04-09 18:22:29', '2018-04-09 18:22:29', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Year', 'gallery_piece_year', 'trash', 'closed', 'closed', '', 'field_5acbaf11ce7fe__trashed', '', '', '2018-04-13 14:33:58', '2018-04-13 18:33:58', '', 29, 'http://morrisnathanson.dev.cc/?post_type=acf-field&#038;p=32', 2, 'acf-field', '', 0),
(33, 1, '2018-04-09 18:22:29', '2018-04-09 18:22:29', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:37:\"Dimensions in inches, e.g., 18\" x 12\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Size', 'gallery_piece_size', 'trash', 'closed', 'closed', '', 'field_5acbaf1cce7ff__trashed', '', '', '2018-04-13 14:33:58', '2018-04-13 18:33:58', '', 29, 'http://morrisnathanson.dev.cc/?post_type=acf-field&#038;p=33', 3, 'acf-field', '', 0),
(34, 1, '2018-04-09 19:11:03', '2018-04-09 19:11:03', '', 'Shop Prints', '', 'publish', 'closed', 'closed', '', 'shop', '', '', '2018-04-19 09:01:48', '2018-04-19 13:01:48', '', 0, 'http://morrisnathanson.dev.cc/shop/', 0, 'page', '', 0),
(35, 1, '2018-04-09 19:11:03', '2018-04-09 19:11:03', '[woocommerce_cart]', 'Cart', '', 'publish', 'closed', 'closed', '', 'cart', '', '', '2018-04-19 14:29:50', '2018-04-19 18:29:50', '', 0, 'http://morrisnathanson.dev.cc/cart/', 0, 'page', '', 0),
(36, 1, '2018-04-09 19:11:03', '2018-04-09 19:11:03', '[woocommerce_checkout]', 'Checkout', '', 'publish', 'closed', 'closed', '', 'checkout', '', '', '2018-04-19 14:30:21', '2018-04-19 18:30:21', '', 0, 'http://morrisnathanson.dev.cc/checkout/', 0, 'page', '', 0),
(37, 1, '2018-04-09 19:11:03', '2018-04-09 19:11:03', '[woocommerce_my_account]', 'My account', '', 'publish', 'closed', 'closed', '', 'my-account', '', '', '2018-04-19 11:07:37', '2018-04-19 15:07:37', '', 0, 'http://morrisnathanson.dev.cc/my-account/', 0, 'page', '', 0),
(38, 1, '2018-04-09 19:31:47', '2018-04-09 19:31:47', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec molestie erat at mi posuere sodales.\r\n', 'Bar Mitzvah on Japonica Street', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec molestie erat at mi posuere sodales.\r\n', 'publish', 'closed', 'closed', '', 'bar-mitzvah-on-japonica-street', '', '', '2018-04-18 15:07:47', '2018-04-18 19:07:47', '', 0, 'http://morrisnathanson.dev.cc/?post_type=gallery&#038;p=38', 0, 'gallery', '', 0),
(39, 1, '2018-04-09 15:56:09', '2018-04-09 19:56:09', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 'Product name goes here', 'Description', 'publish', 'closed', 'closed', '', 'bar-mitvah-on-japonica-street', '', '', '2018-04-19 13:31:08', '2018-04-19 17:31:08', '', 0, 'http://morrisnathanson.dev.cc/?post_type=product&#038;p=39', 0, 'product', '', 0),
(40, 1, '2018-04-09 16:13:03', '2018-04-09 20:13:03', '', 'morris-nathanson-painting-bar-mitzvah-on-japonica-street2', '', 'inherit', 'closed', 'closed', '', 'morris-nathanson-painting-bar-mitzvah-on-japonica-street2', '', '', '2018-04-09 16:13:03', '2018-04-09 20:13:03', '', 39, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/morris-nathanson-painting-bar-mitzvah-on-japonica-street2.jpg', 0, 'attachment', 'image/jpeg', 0),
(42, 1, '2018-04-09 16:32:18', '2018-04-09 20:32:18', 'a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Quote', 'quote', 'publish', 'closed', 'closed', '', 'field_5acbcd9da152d', '', '', '2018-04-11 12:00:31', '2018-04-11 16:00:31', '', 8, 'http://morrisnathanson.dev.cc/?post_type=acf-field&#038;p=42', 12, 'acf-field', '', 0),
(43, 1, '2018-04-09 16:32:18', '2018-04-09 20:32:18', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Background Image', 'home_quote_background_image', 'publish', 'closed', 'closed', '', 'field_5acbcda4a152e', '', '', '2018-04-11 12:00:31', '2018-04-11 16:00:31', '', 8, 'http://morrisnathanson.dev.cc/?post_type=acf-field&#038;p=43', 13, 'acf-field', '', 0),
(44, 1, '2018-04-09 16:32:18', '2018-04-09 20:32:18', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Quote Text', 'home_quote_text', 'publish', 'closed', 'closed', '', 'field_5acbcdb6a152f', '', '', '2018-04-11 12:00:31', '2018-04-11 16:00:31', '', 8, 'http://morrisnathanson.dev.cc/?post_type=acf-field&#038;p=44', 14, 'acf-field', '', 0),
(45, 1, '2018-04-10 08:29:15', '2018-04-10 12:29:15', '', 'Home', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2018-04-10 08:29:15', '2018-04-10 12:29:15', '', 5, 'http://morrisnathanson.dev.cc/5-revision-v1/', 0, 'revision', '', 0),
(46, 1, '2018-04-10 09:03:47', '2018-04-10 13:03:47', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:4:\"page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:2:\"52\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";a:1:{i:0;s:11:\"the_content\";}s:11:\"description\";s:0:\"\";}', 'In the Studio', 'in-the-studio', 'publish', 'closed', 'closed', '', 'group_5accb3a27dd40', '', '', '2018-04-19 23:22:13', '2018-04-20 03:22:13', '', 0, 'http://morrisnathanson.dev.cc/?post_type=acf-field-group&#038;p=46', 0, 'acf-field-group', '', 0),
(47, 1, '2018-04-10 09:03:47', '2018-04-10 13:03:47', 'a:7:{s:4:\"type\";s:6:\"oembed\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:5:\"width\";i:800;s:6:\"height\";i:450;}', 'Main Video', 'studio_main_video', 'publish', 'closed', 'closed', '', 'field_5accb52e890ab', '', '', '2018-04-10 14:13:52', '2018-04-10 18:13:52', '', 46, 'http://morrisnathanson.dev.cc/?post_type=acf-field&#038;p=47', 1, 'acf-field', '', 0),
(48, 1, '2018-04-10 09:03:47', '2018-04-10 13:03:47', 'a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:4:\"left\";s:8:\"endpoint\";i:0;}', 'Schedule a Visit', '', 'publish', 'closed', 'closed', '', 'field_5accb5ce890ac', '', '', '2018-04-10 15:33:52', '2018-04-10 19:33:52', '', 46, 'http://morrisnathanson.dev.cc/?post_type=acf-field&#038;p=48', 8, 'acf-field', '', 0),
(49, 1, '2018-04-10 09:03:47', '2018-04-10 13:03:47', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Description', 'studio_visit_description', 'publish', 'closed', 'closed', '', 'field_5accb5e2890ad', '', '', '2018-04-10 15:33:52', '2018-04-10 19:33:52', '', 46, 'http://morrisnathanson.dev.cc/?post_type=acf-field&#038;p=49', 10, 'acf-field', '', 0),
(51, 1, '2018-04-10 09:03:47', '2018-04-10 13:03:47', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Button Text', 'studio_visit_cta_text', 'publish', 'closed', 'closed', '', 'field_5accb5f3890ae', '', '', '2018-04-12 14:16:04', '2018-04-12 18:16:04', '', 46, 'http://morrisnathanson.dev.cc/?post_type=acf-field&#038;p=51', 11, 'acf-field', '', 0),
(52, 1, '2018-04-10 09:04:11', '2018-04-10 13:04:11', '', 'In the Studio', '', 'publish', 'closed', 'closed', '', 'in-the-studio', '', '', '2018-04-20 00:27:37', '2018-04-20 04:27:37', '', 0, 'http://morrisnathanson.dev.cc/?page_id=52', 0, 'page', '', 0),
(53, 1, '2018-04-10 09:04:11', '2018-04-10 13:04:11', '', 'In the Studio', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2018-04-10 09:04:11', '2018-04-10 13:04:11', '', 52, 'http://morrisnathanson.dev.cc/52-revision-v1/', 0, 'revision', '', 0),
(54, 1, '2018-04-10 09:05:04', '2018-04-10 13:05:04', '', 'In the Studio', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2018-04-10 09:05:04', '2018-04-10 13:05:04', '', 52, 'http://morrisnathanson.dev.cc/52-revision-v1/', 0, 'revision', '', 0),
(55, 1, '2018-04-10 13:05:31', '2018-04-10 17:05:31', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Headline', 'studio_visit_headline', 'publish', 'closed', 'closed', '', 'field_5accddbd0baff', '', '', '2018-04-10 15:33:52', '2018-04-10 19:33:52', '', 46, 'http://morrisnathanson.dev.cc/?post_type=acf-field&#038;p=55', 9, 'acf-field', '', 0),
(56, 1, '2018-04-10 13:10:33', '2018-04-10 17:10:33', '', 'In the Studio', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2018-04-10 13:10:33', '2018-04-10 17:10:33', '', 52, 'http://morrisnathanson.dev.cc/52-revision-v1/', 0, 'revision', '', 0),
(57, 1, '2018-04-10 14:04:58', '2018-04-10 18:04:58', '', 'New Slideshow', '', 'publish', 'closed', 'closed', '', 'new-slideshow', '', '', '2018-04-10 14:52:33', '2018-04-10 18:52:33', '', 0, 'http://morrisnathanson.dev.cc/?post_type=ml-slider&#038;p=57', 0, 'ml-slider', '', 0),
(58, 1, '2018-04-10 14:07:00', '2018-04-10 18:07:00', '', 'morris-nathanson-in-the-studio-artwork-in-progress', '', 'inherit', 'closed', 'closed', '', 'morris-nathanson-in-the-studio-artwork-in-progress', '', '', '2018-04-20 00:27:28', '2018-04-20 04:27:28', '', 52, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/morris-nathanson-in-the-studio-artwork-in-progress.jpg', 0, 'attachment', 'image/jpeg', 0),
(59, 1, '2018-04-10 14:07:01', '2018-04-10 18:07:01', '', 'morris-nathanson-in-the-studio-sitting-with-new-artwork', '', 'inherit', 'closed', 'closed', '', 'morris-nathanson-in-the-studio-sitting-with-new-artwork', '', '', '2018-04-19 23:23:38', '2018-04-20 03:23:38', '', 52, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/morris-nathanson-in-the-studio-sitting-with-new-artwork.jpg', 0, 'attachment', 'image/jpeg', 0),
(60, 1, '2018-04-10 14:07:02', '2018-04-10 18:07:02', '', 'morris-nathanson-in-the-studio-standing-with-new-artwork', '', 'inherit', 'closed', 'closed', '', 'morris-nathanson-in-the-studio-standing-with-new-artwork', '', '', '2018-04-19 23:23:38', '2018-04-20 03:23:38', '', 52, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/morris-nathanson-in-the-studio-standing-with-new-artwork.jpg', 0, 'attachment', 'image/jpeg', 0),
(61, 1, '2018-04-10 14:07:07', '2018-04-10 18:07:07', '', 'Slider 57 - image', 'Lorem ipsum dolor sit amet.', 'publish', 'closed', 'closed', '', 'slider-57-image', '', '', '2018-04-10 14:52:33', '2018-04-10 18:52:33', '', 0, 'http://morrisnathanson.dev.cc/?post_type=ml-slide&#038;p=61', 1, 'ml-slide', '', 0),
(62, 1, '2018-04-10 14:07:07', '2018-04-10 18:07:07', '', 'Slider 57 - image', 'Lorem ipsum dolor sit amet.', 'publish', 'closed', 'closed', '', 'slider-57-image-2', '', '', '2018-04-10 14:52:33', '2018-04-10 18:52:33', '', 0, 'http://morrisnathanson.dev.cc/?post_type=ml-slide&#038;p=62', 2, 'ml-slide', '', 0),
(63, 1, '2018-04-10 14:07:07', '2018-04-10 18:07:07', '', 'Slider 57 - image', 'Lorem ipsum dolor sit amet.', 'publish', 'closed', 'closed', '', 'slider-57-image-3', '', '', '2018-04-10 14:52:33', '2018-04-10 18:52:33', '', 0, 'http://morrisnathanson.dev.cc/?post_type=ml-slide&#038;p=63', 0, 'ml-slide', '', 0),
(64, 1, '2018-04-10 14:13:52', '2018-04-10 18:13:52', 'a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:4:\"left\";s:8:\"endpoint\";i:0;}', 'Videos', '', 'publish', 'closed', 'closed', '', 'field_5accf728e0119', '', '', '2018-04-10 14:13:52', '2018-04-10 18:13:52', '', 46, 'http://morrisnathanson.dev.cc/?post_type=acf-field&p=64', 0, 'acf-field', '', 0),
(65, 1, '2018-04-10 14:13:52', '2018-04-10 18:13:52', 'a:10:{s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:6:\"layout\";s:5:\"table\";s:12:\"button_label\";s:0:\"\";}', 'Related Videos', 'studio_related_videos', 'publish', 'closed', 'closed', '', 'field_5accf625e0115', '', '', '2018-04-10 16:05:19', '2018-04-10 20:05:19', '', 46, 'http://morrisnathanson.dev.cc/?post_type=acf-field&#038;p=65', 3, 'acf-field', '', 0),
(66, 1, '2018-04-10 14:13:52', '2018-04-10 18:13:52', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'URL', 'studio_related_video_url', 'publish', 'closed', 'closed', '', 'field_5accf64ae0116', '', '', '2018-04-10 16:05:19', '2018-04-10 20:05:19', '', 65, 'http://morrisnathanson.dev.cc/?post_type=acf-field&#038;p=66', 0, 'acf-field', '', 0),
(67, 1, '2018-04-10 14:13:52', '2018-04-10 18:13:52', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Thumbnail', 'studio_related_video_thumbnail', 'publish', 'closed', 'closed', '', 'field_5accf6cae0117', '', '', '2018-04-12 16:42:40', '2018-04-12 20:42:40', '', 65, 'http://morrisnathanson.dev.cc/?post_type=acf-field&#038;p=67', 1, 'acf-field', '', 0),
(68, 1, '2018-04-10 14:13:52', '2018-04-10 18:13:52', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Caption', 'studio_related_video_caption', 'publish', 'closed', 'closed', '', 'field_5accf704e0118', '', '', '2018-04-10 16:05:19', '2018-04-10 20:05:19', '', 65, 'http://morrisnathanson.dev.cc/?post_type=acf-field&#038;p=68', 2, 'acf-field', '', 0),
(69, 1, '2018-04-10 14:13:52', '2018-04-10 18:13:52', 'a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'In Progress', '', 'publish', 'closed', 'closed', '', 'field_5accf73de011a', '', '', '2018-04-10 15:33:51', '2018-04-10 19:33:51', '', 46, 'http://morrisnathanson.dev.cc/?post_type=acf-field&#038;p=69', 4, 'acf-field', '', 0),
(70, 1, '2018-04-10 14:13:52', '2018-04-10 18:13:52', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Section Header', 'studio_progress_header', 'publish', 'closed', 'closed', '', 'field_5accfea1e011c', '', '', '2018-04-10 15:33:51', '2018-04-10 19:33:51', '', 46, 'http://morrisnathanson.dev.cc/?post_type=acf-field&#038;p=70', 5, 'acf-field', '', 0),
(71, 1, '2018-04-10 14:13:52', '2018-04-10 18:13:52', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Background Image', 'studio_progress_background_image', 'publish', 'closed', 'closed', '', 'field_5accfe88e011b', '', '', '2018-04-10 15:33:51', '2018-04-10 19:33:51', '', 46, 'http://morrisnathanson.dev.cc/?post_type=acf-field&#038;p=71', 6, 'acf-field', '', 0),
(72, 1, '2018-04-10 14:13:52', '2018-04-10 18:13:52', 'a:10:{s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:6:\"layout\";s:3:\"row\";s:12:\"button_label\";s:9:\"Add Slide\";}', 'Slideshow', 'slideshow', 'publish', 'closed', 'closed', '', 'field_5accfebde011d', '', '', '2018-04-19 23:22:13', '2018-04-20 03:22:13', '', 46, 'http://morrisnathanson.dev.cc/?post_type=acf-field&#038;p=72', 7, 'acf-field', '', 0),
(73, 1, '2018-04-10 14:15:16', '2018-04-10 18:15:16', '', 'in-the-studio-grid-pattern-background', '', 'inherit', 'closed', 'closed', '', 'in-the-studio-grid-pattern-background', '', '', '2018-04-10 14:15:18', '2018-04-10 18:15:18', '', 52, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/in-the-studio-grid-pattern-background.jpg', 0, 'attachment', 'image/jpeg', 0),
(74, 1, '2018-04-10 14:15:21', '2018-04-10 18:15:21', '', 'In the Studio', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2018-04-10 14:15:21', '2018-04-10 18:15:21', '', 52, 'http://morrisnathanson.dev.cc/52-revision-v1/', 0, 'revision', '', 0),
(75, 1, '2018-04-10 14:59:29', '2018-04-10 18:59:29', '', 'In the Studio', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2018-04-10 14:59:29', '2018-04-10 18:59:29', '', 52, 'http://morrisnathanson.dev.cc/52-revision-v1/', 0, 'revision', '', 0),
(76, 1, '2018-04-10 15:03:35', '2018-04-10 19:03:35', ' ', '', '', 'publish', 'closed', 'closed', '', '76', '', '', '2018-04-18 09:47:40', '2018-04-18 13:47:40', '', 0, 'http://morrisnathanson.dev.cc/?p=76', 2, 'nav_menu_item', '', 0),
(78, 1, '2018-04-10 15:04:26', '2018-04-10 19:04:26', '<div class=\"contact-form\">\r\n	<div class=\"grid-x shrink\">\r\n		<div class=\"medium-12 cell\">\r\n			<h3 class=\"contact-header\">Contact</h3>\r\n			<p>Inquiries to gallery representative Phyllis Van Orden</p>\r\n		</div>\r\n\r\n		<div class=\"medium-12 cell\">\r\n			<label> [text* your-name] First, last name </label>\r\n		</div>\r\n\r\n		<div class=\"medium-12 cell\">\r\n			<label> [tel* your-number] Phone number </label>\r\n		</div>\r\n				\r\n		<div class=\"medium-12 cell\">\r\n			<label> [email* your-email] Email address </label>\r\n		</div>\r\n\r\n		<div class=\"medium-12 cell\">\r\n			<label> [textarea your-message] Type your message above </label>\r\n		</div>\r\n\r\n		<div class=\"medium-12 cell\">\r\n			[submit \"Submit »\"]\r\n		</div>\r\n	</div>\r\n</div>\n1\nMorris Nathanson Art – Studio Inquiry\n[your-name] <wordpress@morrisnathanson.dev.cc>\ndan@delindesign.com\nFrom: [your-name] <[your-email]>\r\nPhone number: [your-number]\r\n\r\nMessage Body:\r\n[your-message]\r\n\r\n-- \r\nThis e-mail was sent from a contact form on Morris Nathanson Art (http://morrisnathanson.dev.cc)\nReply-To: [your-email]\n\n\n\n\nMorris Nathanson Art \"[your-subject]\"\nMorris Nathanson Art <wordpress@morrisnathanson.dev.cc>\n[your-email]\nMessage Body:\r\n[your-message]\r\n\r\n-- \r\nThis e-mail was sent from a contact form on Morris Nathanson Art (http://morrisnathanson.dev.cc)\nReply-To: dan@delindesign.com\n\n\n\nThank you for your message. It has been sent.\nThere was an error trying to send your message. Please try again later.\nOne or more fields have an error. Please check and try again.\nThere was an error trying to send your message. Please try again later.\nYou must accept the terms and conditions before sending your message.\nThe field is required.\nThe field is too long.\nThe field is too short.\nThe date format is incorrect.\nThe date is before the earliest one allowed.\nThe date is after the latest one allowed.\nThere was an unknown error uploading the file.\nYou are not allowed to upload files of this type.\nThe file is too big.\nThere was an error uploading the file.\nThe number format is invalid.\nThe number is smaller than the minimum allowed.\nThe number is larger than the maximum allowed.\nThe answer to the quiz is incorrect.\nYour entered code is incorrect.\nThe e-mail address entered is invalid.\nThe URL is invalid.\nThe telephone number is invalid.', 'Contact form 1', '', 'publish', 'closed', 'closed', '', 'contact-form-1', '', '', '2018-04-13 10:30:14', '2018-04-13 14:30:14', '', 0, 'http://morrisnathanson.dev.cc/?post_type=wpcf7_contact_form&#038;p=78', 0, 'wpcf7_contact_form', '', 0),
(79, 1, '2018-04-10 15:31:28', '2018-04-10 19:31:28', '', 'In the Studio', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2018-04-10 15:31:28', '2018-04-10 19:31:28', '', 52, 'http://morrisnathanson.dev.cc/52-revision-v1/', 0, 'revision', '', 0),
(80, 1, '2018-04-10 15:33:51', '2018-04-10 19:33:51', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Main Video Caption', 'studio_main_video_caption', 'publish', 'closed', 'closed', '', 'field_5acd11915e5a0', '', '', '2018-04-10 15:34:02', '2018-04-10 19:34:02', '', 46, 'http://morrisnathanson.dev.cc/?post_type=acf-field&#038;p=80', 2, 'acf-field', '', 0),
(81, 1, '2018-04-10 15:58:03', '2018-04-10 19:58:03', '', 'morris-nathanson-archives-video-thumbnail', '', 'inherit', 'closed', 'closed', '', 'morris-nathanson-archives-video-thumbnail', '', '', '2018-04-10 16:06:09', '2018-04-10 20:06:09', '', 52, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/morris-nathanson-archives-video-thumbnail.jpg', 0, 'attachment', 'image/jpeg', 0),
(82, 1, '2018-04-10 15:58:04', '2018-04-10 19:58:04', '', 'morris-nathanson-technique-and-process-video-thumbnail', '', 'inherit', 'closed', 'closed', '', 'morris-nathanson-technique-and-process-video-thumbnail', '', '', '2018-04-10 16:06:21', '2018-04-10 20:06:21', '', 52, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/morris-nathanson-technique-and-process-video-thumbnail.jpg', 0, 'attachment', 'image/jpeg', 0),
(83, 1, '2018-04-10 15:58:04', '2018-04-10 19:58:04', '', 'morris-nathanson-therapy-of-drawing-video-thumbnail', '', 'inherit', 'closed', 'closed', '', 'morris-nathanson-therapy-of-drawing-video-thumbnail', '', '', '2018-04-10 16:06:12', '2018-04-10 20:06:12', '', 52, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/morris-nathanson-therapy-of-drawing-video-thumbnail.jpg', 0, 'attachment', 'image/jpeg', 0),
(84, 1, '2018-04-10 15:58:26', '2018-04-10 19:58:26', '', 'In the Studio', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2018-04-10 15:58:26', '2018-04-10 19:58:26', '', 52, 'http://morrisnathanson.dev.cc/52-revision-v1/', 0, 'revision', '', 0),
(85, 1, '2018-04-10 16:06:35', '2018-04-10 20:06:35', '', 'In the Studio', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2018-04-10 16:06:35', '2018-04-10 20:06:35', '', 52, 'http://morrisnathanson.dev.cc/52-revision-v1/', 0, 'revision', '', 0),
(87, 1, '2018-04-10 16:25:01', '2018-04-10 20:25:01', '', 'Providence Art Club Gallery Exhibition', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus ac odio facilisis, tempus ante vitae, pharetra lacus. In sit amet venenatis magna.\r\n\r\nMauris eget justo sit amet odio bibendum pellentesque sed in ligula. Aenean eleifend purus varius augue faucibus sodales. Proin porta, turpis at interdum pulvinar, velit lectus venenatis elit, sit amet iaculis massa augue.', 'publish', 'closed', 'closed', '', 'providence-art-club-gallery-exhibition', '', '', '2018-04-12 16:37:43', '2018-04-12 20:37:43', '', 0, 'http://morrisnathanson.dev.cc/?post_type=news-article&#038;p=87', 0, 'news-article', '', 0),
(88, 1, '2018-04-10 16:27:25', '2018-04-10 20:27:25', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:12:\"news-article\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";a:1:{i:0;s:11:\"the_content\";}s:11:\"description\";s:0:\"\";}', 'News Article (Single Post)', 'news-article-single-post', 'publish', 'closed', 'closed', '', 'group_5acd1da9059d2', '', '', '2018-04-13 07:41:11', '2018-04-13 11:41:11', '', 0, 'http://morrisnathanson.dev.cc/?post_type=acf-field-group&#038;p=88', 0, 'acf-field-group', '', 0),
(89, 1, '2018-04-10 16:27:25', '2018-04-10 20:27:25', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:21:\"Format: May 1st, 2018\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Date', 'news_article_date', 'publish', 'closed', 'closed', '', 'field_5acd1db05e352', '', '', '2018-04-10 16:28:34', '2018-04-10 20:28:34', '', 88, 'http://morrisnathanson.dev.cc/?post_type=acf-field&#038;p=89', 0, 'acf-field', '', 0),
(91, 1, '2018-04-10 16:27:25', '2018-04-10 20:27:25', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'URL', 'news_article_url', 'publish', 'closed', 'closed', '', 'field_5acd1e1b5e354', '', '', '2018-04-11 11:13:02', '2018-04-11 15:13:02', '', 88, 'http://morrisnathanson.dev.cc/?post_type=acf-field&#038;p=91', 1, 'acf-field', '', 0),
(92, 1, '2018-04-11 10:10:31', '2018-04-11 14:10:31', '[contact-form-7 id=\"78\" title=\"Contact form 1\"]', 'Contact', '', 'trash', 'closed', 'closed', '', 'contact__trashed', '', '', '2018-04-13 10:32:05', '2018-04-13 14:32:05', '', 0, 'http://morrisnathanson.dev.cc/?page_id=92', 0, 'page', '', 0),
(94, 1, '2018-04-11 10:10:31', '2018-04-11 14:10:31', '[contact-form-7 id=\"78\" title=\"Contact form 1\"]', 'Contact', '', 'inherit', 'closed', 'closed', '', '92-revision-v1', '', '', '2018-04-11 10:10:31', '2018-04-11 14:10:31', '', 92, 'http://morrisnathanson.dev.cc/92-revision-v1/', 0, 'revision', '', 0),
(96, 1, '2018-04-11 10:30:52', '2018-04-11 14:30:52', '', 'Press & Events', '', 'publish', 'closed', 'closed', '', 'press-events', '', '', '2018-04-11 10:30:52', '2018-04-11 14:30:52', '', 0, 'http://morrisnathanson.dev.cc/?page_id=96', 0, 'page', '', 0),
(97, 1, '2018-04-11 10:30:52', '2018-04-11 14:30:52', ' ', '', '', 'publish', 'closed', 'closed', '', '97', '', '', '2018-04-18 09:47:40', '2018-04-18 13:47:40', '', 0, 'http://morrisnathanson.dev.cc/97/', 3, 'nav_menu_item', '', 0),
(98, 1, '2018-04-11 10:30:52', '2018-04-11 14:30:52', '', 'Press & Events', '', 'inherit', 'closed', 'closed', '', '96-revision-v1', '', '', '2018-04-11 10:30:52', '2018-04-11 14:30:52', '', 96, 'http://morrisnathanson.dev.cc/96-revision-v1/', 0, 'revision', '', 0),
(99, 1, '2018-04-11 10:41:57', '2018-04-11 14:41:57', '', 'morris-nathanson-providence-art-club-retrospective-news-article', '', 'inherit', 'closed', 'closed', '', 'morris-nathanson-providence-art-club-retrospective-news-article', '', '', '2018-04-11 10:41:57', '2018-04-11 14:41:57', '', 87, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/morris-nathanson-providence-art-club-retrospective-news-article.jpg', 0, 'attachment', 'image/jpeg', 0),
(100, 1, '2018-04-11 11:29:46', '2018-04-11 15:29:46', '', 'Pell Grant Ceremony at Waterfire Arts Center', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus ac odio facilisis, tempus ante vitae, pharetra lacus. In sit amet venenatis magna.\r\n\r\nMauris eget justo sit amet odio bibendum pellentesque sed in ligula. Aenean eleifend purus varius augue faucibus sodales. Proin porta, turpis at interdum pulvinar, velit lectus venenatis elit, sit amet iaculis massa augue.', 'publish', 'closed', 'closed', '', 'pell-grant-ceremony-at-waterfire-arts-center', '', '', '2018-04-13 10:30:54', '2018-04-13 14:30:54', '', 0, 'http://morrisnathanson.dev.cc/?post_type=news-article&#038;p=100', 0, 'news-article', '', 0),
(101, 1, '2018-04-11 11:29:57', '2018-04-11 15:29:57', '', '2018-rhode-island-pell-grant-waterfire-arts-center', '', 'inherit', 'closed', 'closed', '', '2018-rhode-island-pell-grant-waterfire-arts-center', '', '', '2018-04-17 12:01:50', '2018-04-17 16:01:50', '', 100, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/2018-rhode-island-pell-grant-waterfire-arts-center.jpg', 0, 'attachment', 'image/jpeg', 0),
(102, 1, '2018-04-11 11:29:57', '2018-04-11 15:29:57', '', 'morris-nathanson-pawtucket-bridge-lighting-ceremony', '', 'inherit', 'closed', 'closed', '', 'morris-nathanson-pawtucket-bridge-lighting-ceremony', '', '', '2018-04-17 12:44:32', '2018-04-17 16:44:32', '', 100, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/morris-nathanson-pawtucket-bridge-lighting-ceremony.jpg', 0, 'attachment', 'image/jpeg', 0),
(103, 1, '2018-04-11 11:30:38', '2018-04-11 15:30:38', '', 'IlluMiNation: Morris Nathanson Bridge Lighting', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus ac odio facilisis, tempus ante vitae, pharetra lacus. In sit amet venenatis magna.\r\n\r\nMauris eget justo sit amet odio bibendum pellentesque sed in ligula. Aenean eleifend purus varius augue faucibus sodales. Proin porta, turpis at interdum pulvinar, velit lectus venenatis elit, sit amet iaculis massa augue.', 'publish', 'closed', 'closed', '', 'illumination-morris-nathanson-bridge-lighting', '', '', '2018-04-13 10:31:21', '2018-04-13 14:31:21', '', 0, 'http://morrisnathanson.dev.cc/?post_type=news-article&#038;p=103', 0, 'news-article', '', 0),
(104, 1, '2018-04-11 12:00:31', '2018-04-11 16:00:31', 'a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Featured Happenings', '', 'publish', 'closed', 'closed', '', 'field_5ace2eeb98fc8', '', '', '2018-04-11 12:00:31', '2018-04-11 16:00:31', '', 8, 'http://morrisnathanson.dev.cc/?post_type=acf-field&p=104', 5, 'acf-field', '', 0),
(105, 1, '2018-04-11 12:00:31', '2018-04-11 16:00:31', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Section Header', 'home_featured_section_header', 'publish', 'closed', 'closed', '', 'field_5ace2f1f98fca', '', '', '2018-04-11 12:00:31', '2018-04-11 16:00:31', '', 8, 'http://morrisnathanson.dev.cc/?post_type=acf-field&p=105', 6, 'acf-field', '', 0),
(106, 1, '2018-04-11 12:00:31', '2018-04-11 16:00:31', 'a:10:{s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";i:6;s:6:\"layout\";s:3:\"row\";s:12:\"button_label\";s:0:\"\";}', 'Article', 'home_featured', 'publish', 'closed', 'closed', '', 'field_5ace2f7e98fcb', '', '', '2018-04-13 15:14:04', '2018-04-13 19:14:04', '', 8, 'http://morrisnathanson.dev.cc/?post_type=acf-field&#038;p=106', 7, 'acf-field', '', 0);
INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(107, 1, '2018-04-11 12:00:31', '2018-04-11 16:00:31', 'a:11:{s:4:\"type\";s:11:\"post_object\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"post_type\";a:1:{i:0;s:12:\"news-article\";}s:8:\"taxonomy\";a:0:{}s:10:\"allow_null\";i:0;s:8:\"multiple\";i:0;s:13:\"return_format\";s:6:\"object\";s:2:\"ui\";i:1;}', 'Article', 'home_featured_article', 'publish', 'closed', 'closed', '', 'field_5ace2fa998fcc', '', '', '2018-04-11 12:20:51', '2018-04-11 16:20:51', '', 106, 'http://morrisnathanson.dev.cc/?post_type=acf-field&#038;p=107', 0, 'acf-field', '', 0),
(108, 1, '2018-04-11 12:00:57', '2018-04-11 16:00:57', '', 'Home', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2018-04-11 12:00:57', '2018-04-11 16:00:57', '', 5, 'http://morrisnathanson.dev.cc/5-revision-v1/', 0, 'revision', '', 0),
(112, 1, '2018-04-12 12:28:22', '2018-04-12 16:28:22', '', 'Stories', '', 'publish', 'closed', 'closed', '', 'stories', '', '', '2018-04-17 13:25:25', '2018-04-17 17:25:25', '', 0, 'http://morrisnathanson.dev.cc/?page_id=112', 0, 'page', '', 0),
(114, 1, '2018-04-12 12:28:22', '2018-04-12 16:28:22', '', 'Stories', '', 'inherit', 'closed', 'closed', '', '112-revision-v1', '', '', '2018-04-12 12:28:22', '2018-04-12 16:28:22', '', 112, 'http://morrisnathanson.dev.cc/112-revision-v1/', 0, 'revision', '', 0),
(116, 1, '2018-04-12 13:04:17', '2018-04-12 17:04:17', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:5:\"story\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";a:1:{i:0;s:11:\"the_content\";}s:11:\"description\";s:0:\"\";}', 'Story (Single Post)', 'story-single-post', 'publish', 'closed', 'closed', '', 'group_5acf9093e9df0', '', '', '2018-04-17 22:13:38', '2018-04-18 02:13:38', '', 0, 'http://morrisnathanson.dev.cc/?post_type=acf-field-group&#038;p=116', 0, 'acf-field-group', '', 0),
(117, 1, '2018-04-12 13:04:17', '2018-04-12 17:04:17', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Year/Decade', 'story_year', 'publish', 'closed', 'closed', '', 'field_5acf90b3e9f5b', '', '', '2018-04-12 13:04:17', '2018-04-12 17:04:17', '', 116, 'http://morrisnathanson.dev.cc/?post_type=acf-field&p=117', 0, 'acf-field', '', 0),
(118, 1, '2018-04-12 13:04:17', '2018-04-12 17:04:17', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Quote', 'story_quote', 'publish', 'closed', 'closed', '', 'field_5acf90dee9f5c', '', '', '2018-04-12 13:04:17', '2018-04-12 17:04:17', '', 116, 'http://morrisnathanson.dev.cc/?post_type=acf-field&p=118', 1, 'acf-field', '', 0),
(119, 1, '2018-04-12 13:04:17', '2018-04-12 17:04:17', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Map Image', 'story_map_image', 'publish', 'closed', 'closed', '', 'field_5acf9112e9f5e', '', '', '2018-04-17 22:13:38', '2018-04-18 02:13:38', '', 116, 'http://morrisnathanson.dev.cc/?post_type=acf-field&#038;p=119', 2, 'acf-field', '', 0),
(120, 1, '2018-04-12 13:04:17', '2018-04-12 17:04:17', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Intro Vertical Image', 'intro_vertical_image', 'publish', 'closed', 'closed', '', 'field_5acf9130e9f5f', '', '', '2018-04-17 22:13:38', '2018-04-18 02:13:38', '', 116, 'http://morrisnathanson.dev.cc/?post_type=acf-field&#038;p=120', 3, 'acf-field', '', 0),
(121, 1, '2018-04-12 13:04:17', '2018-04-12 17:04:17', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Horitonzal Image #1', 'horitonzal_image_1', 'publish', 'closed', 'closed', '', 'field_5acf9155e9f60', '', '', '2018-04-17 22:13:38', '2018-04-18 02:13:38', '', 116, 'http://morrisnathanson.dev.cc/?post_type=acf-field&#038;p=121', 4, 'acf-field', '', 0),
(122, 1, '2018-04-12 13:04:17', '2018-04-12 17:04:17', 'a:10:{s:4:\"type\";s:7:\"wysiwyg\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:4:\"tabs\";s:3:\"all\";s:7:\"toolbar\";s:4:\"full\";s:12:\"media_upload\";i:1;s:5:\"delay\";i:0;}', 'Content', 'story_content', 'publish', 'closed', 'closed', '', 'field_5acf916ae9f62', '', '', '2018-04-12 13:04:17', '2018-04-12 17:04:17', '', 116, 'http://morrisnathanson.dev.cc/?post_type=acf-field&p=122', 5, 'acf-field', '', 0),
(123, 1, '2018-04-12 13:04:17', '2018-04-12 17:04:17', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Horitonzal Image #2', 'horitonzal_image_2', 'publish', 'closed', 'closed', '', 'field_5acf9163e9f61', '', '', '2018-04-17 22:13:38', '2018-04-18 02:13:38', '', 116, 'http://morrisnathanson.dev.cc/?post_type=acf-field&#038;p=123', 6, 'acf-field', '', 0),
(124, 1, '2018-04-12 13:13:39', '2018-04-12 17:13:39', '', 'Riverfront Lofts / Assemblages', '', 'publish', 'closed', 'closed', '', 'riverfront-lofts-assemblages', '', '', '2018-04-12 13:13:39', '2018-04-12 17:13:39', '', 0, 'http://morrisnathanson.dev.cc/?post_type=stories&#038;p=124', 0, 'stories', '', 0),
(125, 1, '2018-04-12 13:46:27', '2018-04-12 17:46:27', '', 'In the Studio', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2018-04-12 13:46:27', '2018-04-12 17:46:27', '', 52, 'http://morrisnathanson.dev.cc/52-revision-v1/', 0, 'revision', '', 0),
(126, 1, '2018-04-12 14:14:59', '2018-04-12 18:14:59', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Square Image (for Press & Events Page)', 'news_article_square_image', 'publish', 'closed', 'closed', '', 'field_5acfa063547c1', '', '', '2018-04-12 17:02:17', '2018-04-12 21:02:17', '', 88, 'http://morrisnathanson.dev.cc/?post_type=acf-field&#038;p=126', 2, 'acf-field', '', 0),
(127, 1, '2018-04-12 14:14:59', '2018-04-12 18:14:59', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Vertical Image (for Homepage)', 'news_article_vertical_image', 'publish', 'closed', 'closed', '', 'field_5acfa087547c2', '', '', '2018-04-12 14:14:59', '2018-04-12 18:14:59', '', 88, 'http://morrisnathanson.dev.cc/?post_type=acf-field&p=127', 3, 'acf-field', '', 0),
(128, 1, '2018-04-12 14:16:04', '2018-04-12 18:16:04', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Contact Form Shortcode', 'studio_visit_contact_shortcode', 'publish', 'closed', 'closed', '', 'field_5acfa23e6ce2f', '', '', '2018-04-12 14:17:52', '2018-04-12 18:17:52', '', 46, 'http://morrisnathanson.dev.cc/?post_type=acf-field&#038;p=128', 12, 'acf-field', '', 0),
(129, 1, '2018-04-12 14:16:24', '2018-04-12 18:16:24', '', 'In the Studio', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2018-04-12 14:16:24', '2018-04-12 18:16:24', '', 52, 'http://morrisnathanson.dev.cc/52-revision-v1/', 0, 'revision', '', 0),
(130, 1, '2018-04-12 16:36:40', '2018-04-12 20:36:40', '', '2018-rhode-island-pell-grant-waterfire-arts-center2', '', 'inherit', 'closed', 'closed', '', '2018-rhode-island-pell-grant-waterfire-arts-center2', '', '', '2018-04-12 16:37:24', '2018-04-12 20:37:24', '', 103, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/2018-rhode-island-pell-grant-waterfire-arts-center2.jpg', 0, 'attachment', 'image/jpeg', 0),
(131, 1, '2018-04-12 16:36:40', '2018-04-12 20:36:40', '', '2018-rhode-island-pell-grant-waterfire-arts-center3', '', 'inherit', 'closed', 'closed', '', '2018-rhode-island-pell-grant-waterfire-arts-center3', '', '', '2018-04-12 16:37:20', '2018-04-12 20:37:20', '', 103, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/2018-rhode-island-pell-grant-waterfire-arts-center3.jpg', 0, 'attachment', 'image/jpeg', 0),
(132, 1, '2018-04-12 16:36:41', '2018-04-12 20:36:41', '', 'morris-nathanson-pawtucket-bridge-lighting-ceremony2', '', 'inherit', 'closed', 'closed', '', 'morris-nathanson-pawtucket-bridge-lighting-ceremony2', '', '', '2018-04-12 16:36:57', '2018-04-12 20:36:57', '', 103, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/morris-nathanson-pawtucket-bridge-lighting-ceremony2.jpg', 0, 'attachment', 'image/jpeg', 0),
(133, 1, '2018-04-12 16:36:42', '2018-04-12 20:36:42', '', 'morris-nathanson-pawtucket-bridge-lighting-ceremony3', '', 'inherit', 'closed', 'closed', '', 'morris-nathanson-pawtucket-bridge-lighting-ceremony3', '', '', '2018-04-17 12:45:54', '2018-04-17 16:45:54', '', 103, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/morris-nathanson-pawtucket-bridge-lighting-ceremony3.jpg', 0, 'attachment', 'image/jpeg', 0),
(134, 1, '2018-04-12 16:36:42', '2018-04-12 20:36:42', '', 'morris-nathanson-providence-art-club-retrospective-news-article2', '', 'inherit', 'closed', 'closed', '', 'morris-nathanson-providence-art-club-retrospective-news-article2', '', '', '2018-04-12 16:37:40', '2018-04-12 20:37:40', '', 103, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/morris-nathanson-providence-art-club-retrospective-news-article2.jpg', 0, 'attachment', 'image/jpeg', 0),
(135, 1, '2018-04-12 16:36:43', '2018-04-12 20:36:43', '', 'morris-nathanson-providence-art-club-retrospective-news-article3', '', 'inherit', 'closed', 'closed', '', 'morris-nathanson-providence-art-club-retrospective-news-article3', '', '', '2018-04-12 16:37:38', '2018-04-12 20:37:38', '', 103, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/morris-nathanson-providence-art-club-retrospective-news-article3.jpg', 0, 'attachment', 'image/jpeg', 0),
(136, 1, '2018-04-13 09:56:52', '2018-04-13 13:56:52', '', 'Home', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2018-04-13 09:56:52', '2018-04-13 13:56:52', '', 5, 'http://morrisnathanson.dev.cc/5-revision-v1/', 0, 'revision', '', 0),
(137, 1, '2018-04-16 11:26:04', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2018-04-16 11:26:04', '0000-00-00 00:00:00', '', 0, 'http://morrisnathanson.dev.cc/?p=137', 0, 'post', '', 0),
(138, 1, '2018-04-16 14:27:32', '0000-00-00 00:00:00', '', 'Contact', '', 'draft', 'closed', 'closed', '', '', '', '', '2018-04-16 14:27:32', '0000-00-00 00:00:00', '', 0, 'http://morrisnathanson.dev.cc/?p=138', 1, 'nav_menu_item', '', 0),
(139, 1, '2018-04-16 16:26:58', '2018-04-16 20:26:58', '', 'Home', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2018-04-16 16:26:58', '2018-04-16 20:26:58', '', 5, 'http://morrisnathanson.dev.cc/5-revision-v1/', 0, 'revision', '', 0),
(140, 1, '2018-04-17 09:58:51', '2018-04-17 13:58:51', '', 'Paintings', '', 'publish', 'closed', 'closed', '', 'paintings', '', '', '2018-04-17 10:23:19', '2018-04-17 14:23:19', '', 0, 'http://morrisnathanson.dev.cc/?p=140', 2, 'nav_menu_item', '', 0),
(141, 1, '2018-04-17 09:58:51', '2018-04-17 13:58:51', '', 'Drawings', '', 'publish', 'closed', 'closed', '', 'drawings', '', '', '2018-04-17 10:23:19', '2018-04-17 14:23:19', '', 0, 'http://morrisnathanson.dev.cc/?p=141', 3, 'nav_menu_item', '', 0),
(142, 1, '2018-04-17 09:58:51', '2018-04-17 13:58:51', '', 'Relief prints', '', 'publish', 'closed', 'closed', '', 'relief-prints', '', '', '2018-04-17 10:23:19', '2018-04-17 14:23:19', '', 0, 'http://morrisnathanson.dev.cc/?p=142', 4, 'nav_menu_item', '', 0),
(143, 1, '2018-04-17 09:58:51', '2018-04-17 13:58:51', '', 'Sketches', '', 'publish', 'closed', 'closed', '', 'sketches', '', '', '2018-04-17 10:23:19', '2018-04-17 14:23:19', '', 0, 'http://morrisnathanson.dev.cc/?p=143', 5, 'nav_menu_item', '', 0),
(144, 1, '2018-04-17 09:58:51', '2018-04-17 13:58:51', '', 'Assemblages', '', 'publish', 'closed', 'closed', '', 'assemblages', '', '', '2018-04-17 10:23:19', '2018-04-17 14:23:19', '', 0, 'http://morrisnathanson.dev.cc/?p=144', 6, 'nav_menu_item', '', 0),
(145, 1, '2018-04-17 10:23:19', '2018-04-17 14:23:19', '', 'Gallery', '', 'publish', 'closed', 'closed', '', 'gallery', '', '', '2018-04-17 10:23:19', '2018-04-17 14:23:19', '', 0, 'http://morrisnathanson.dev.cc/?p=145', 1, 'nav_menu_item', '', 0),
(146, 1, '2018-04-17 10:24:21', '2018-04-17 14:24:21', ' ', '', '', 'publish', 'closed', 'closed', '', '146', '', '', '2018-04-17 10:46:55', '2018-04-17 14:46:55', '', 0, 'http://morrisnathanson.dev.cc/?p=146', 1, 'nav_menu_item', '', 0),
(147, 1, '2018-04-17 10:24:21', '2018-04-17 14:24:21', '', 'Video Ops', '', 'publish', 'closed', 'closed', '', 'video-ops', '', '', '2018-04-17 10:46:55', '2018-04-17 14:46:55', '', 0, 'http://morrisnathanson.dev.cc/?p=147', 2, 'nav_menu_item', '', 0),
(148, 1, '2018-04-17 10:24:22', '2018-04-17 14:24:22', '', 'Work In Progress', '', 'publish', 'closed', 'closed', '', 'word-in-progress', '', '', '2018-04-17 10:46:55', '2018-04-17 14:46:55', '', 0, 'http://morrisnathanson.dev.cc/?p=148', 3, 'nav_menu_item', '', 0),
(149, 1, '2018-04-17 10:24:22', '2018-04-17 14:24:22', '', 'Schedule a Visit', '', 'publish', 'closed', 'closed', '', 'schedule-a-visit', '', '', '2018-04-17 10:46:55', '2018-04-17 14:46:55', '', 0, 'http://morrisnathanson.dev.cc/?p=149', 4, 'nav_menu_item', '', 0),
(150, 1, '2018-04-17 10:24:46', '2018-04-17 14:24:46', '', 'Press + Events', '', 'publish', 'closed', 'closed', '', 'press-events', '', '', '2018-04-17 10:25:19', '2018-04-17 14:25:19', '', 0, 'http://morrisnathanson.dev.cc/?p=150', 1, 'nav_menu_item', '', 0),
(151, 1, '2018-04-17 10:25:19', '2018-04-17 14:25:19', '', 'Upcoming Shows', '', 'publish', 'closed', 'closed', '', 'upcoming-shows', '', '', '2018-04-17 10:25:19', '2018-04-17 14:25:19', '', 0, 'http://morrisnathanson.dev.cc/?p=151', 2, 'nav_menu_item', '', 0),
(152, 1, '2018-04-17 10:25:19', '2018-04-17 14:25:19', '', 'News Archive', '', 'publish', 'closed', 'closed', '', 'news-archive', '', '', '2018-04-17 10:25:19', '2018-04-17 14:25:19', '', 0, 'http://morrisnathanson.dev.cc/?p=152', 3, 'nav_menu_item', '', 0),
(153, 1, '2018-04-17 10:25:39', '2018-04-17 14:25:39', ' ', '', '', 'publish', 'closed', 'closed', '', '153', '', '', '2018-04-17 10:25:44', '2018-04-17 14:25:44', '', 0, 'http://morrisnathanson.dev.cc/?p=153', 1, 'nav_menu_item', '', 0),
(154, 1, '2018-04-17 10:26:07', '2018-04-17 14:26:07', '', 'Shop Prints', '', 'publish', 'closed', 'closed', '', 'shop-prints', '', '', '2018-04-17 10:26:25', '2018-04-17 14:26:25', '', 0, 'http://morrisnathanson.dev.cc/?p=154', 1, 'nav_menu_item', '', 0),
(155, 1, '2018-04-17 10:26:25', '2018-04-17 14:26:25', '', 'Contact', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2018-04-17 10:26:25', '2018-04-17 14:26:25', '', 0, 'http://morrisnathanson.dev.cc/?p=155', 2, 'nav_menu_item', '', 0),
(156, 1, '2018-04-17 11:14:38', '2018-04-17 15:14:38', '', 'In the Studio', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2018-04-17 11:14:38', '2018-04-17 15:14:38', '', 52, 'http://morrisnathanson.dev.cc/52-revision-v1/', 0, 'revision', '', 0),
(157, 1, '2018-04-17 11:14:57', '2018-04-17 15:14:57', '', 'In the Studio', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2018-04-17 11:14:57', '2018-04-17 15:14:57', '', 52, 'http://morrisnathanson.dev.cc/52-revision-v1/', 0, 'revision', '', 0),
(158, 1, '2018-04-17 11:55:27', '2018-04-17 15:55:27', '', '“Providence Art Club Gallery Exhibition” is locked	 Providence Art Club Gallery Exhibition', '', 'trash', 'closed', 'closed', '', 'providence-art-club-gallery-exhibition-is-locked-providence-art-club-gallery-exhibition__trashed', '', '', '2018-04-17 12:06:00', '2018-04-17 16:06:00', '', 0, 'http://morrisnathanson.dev.cc/?post_type=news-article&#038;p=158', 0, 'news-article', '', 0),
(159, 1, '2018-04-17 12:44:34', '2018-04-17 16:44:34', '', 'New Event', 'Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum.\r\n\r\nLorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum.\r\n\r\n', 'publish', 'closed', 'closed', '', 'new-event', '', '', '2018-04-17 12:45:56', '2018-04-17 16:45:56', '', 0, 'http://morrisnathanson.dev.cc/?post_type=news-article&#038;p=159', 0, 'news-article', '', 0),
(160, 1, '2018-04-17 12:56:19', '2018-04-17 16:56:19', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2018-04-17 12:56:19', '2018-04-17 16:56:19', '', 1, 'http://morrisnathanson.dev.cc/1-revision-v1/', 0, 'revision', '', 0),
(161, 1, '2018-04-17 12:59:36', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-04-17 12:59:36', '0000-00-00 00:00:00', '', 0, 'http://morrisnathanson.dev.cc/?post_type=galleries&p=161', 0, 'galleries', '', 0),
(162, 1, '2018-04-17 12:59:56', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-04-17 12:59:56', '0000-00-00 00:00:00', '', 0, 'http://morrisnathanson.dev.cc/?post_type=galleries&p=162', 0, 'galleries', '', 0),
(163, 1, '2018-04-17 12:59:59', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-04-17 12:59:59', '0000-00-00 00:00:00', '', 0, 'http://morrisnathanson.dev.cc/?post_type=galleries&p=163', 0, 'galleries', '', 0),
(164, 1, '2018-04-17 13:01:14', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-04-17 13:01:14', '0000-00-00 00:00:00', '', 0, 'http://morrisnathanson.dev.cc/?post_type=galleries&p=164', 0, 'galleries', '', 0),
(166, 1, '2018-04-17 13:46:10', '2018-04-17 17:46:10', '', 'Riverfront Lofts /  Assemblages', '', 'publish', 'closed', 'closed', '', '166', '', '', '2018-04-19 14:36:01', '2018-04-19 18:36:01', '', 0, 'http://morrisnathanson.dev.cc/?post_type=story&#038;p=166', 0, 'story', '', 0),
(167, 1, '2018-04-17 15:09:58', '2018-04-17 19:09:58', '', 'Shop Prints', '', 'publish', 'closed', 'closed', '', 'shop-prints-2', '', '', '2018-04-18 09:47:40', '2018-04-18 13:47:40', '', 0, 'http://morrisnathanson.dev.cc/?p=167', 5, 'nav_menu_item', '', 0),
(168, 1, '2018-04-17 20:56:20', '2018-04-18 00:56:20', '', 'Image-1', '', 'inherit', 'closed', 'closed', '', 'image-1', '', '', '2018-04-17 20:56:37', '2018-04-18 00:56:37', '', 166, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/Image-1.png', 0, 'attachment', 'image/png', 0),
(169, 1, '2018-04-17 20:56:22', '2018-04-18 00:56:22', '', 'Image-2', '', 'inherit', 'closed', 'closed', '', 'image-2', '', '', '2018-04-18 08:56:58', '2018-04-18 12:56:58', '', 166, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/Image-2.png', 0, 'attachment', 'image/png', 0),
(170, 1, '2018-04-17 20:56:24', '2018-04-18 00:56:24', '', 'map', '', 'inherit', 'closed', 'closed', '', 'map', '', '', '2018-04-17 20:56:32', '2018-04-18 00:56:32', '', 166, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/map.png', 0, 'attachment', 'image/png', 0),
(171, 1, '2018-04-18 09:02:20', '2018-04-18 13:02:20', '', 'Morris Nathanson Design', '', 'publish', 'closed', 'closed', '', 'morris-nathanson-design', '', '', '2018-04-18 09:07:38', '2018-04-18 13:07:38', '', 0, 'http://morrisnathanson.dev.cc/?post_type=story&#038;p=171', 0, 'story', '', 0),
(172, 1, '2018-04-18 09:00:29', '2018-04-18 13:00:29', '', 'morris', '', 'inherit', 'closed', 'closed', '', 'morris', '', '', '2018-04-18 09:00:33', '2018-04-18 13:00:33', '', 171, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/morris.png', 0, 'attachment', 'image/png', 0),
(173, 1, '2018-04-18 09:01:47', '2018-04-18 13:01:47', '', 'morris-cover', '', 'inherit', 'closed', 'closed', '', 'morris-cover', '', '', '2018-04-18 09:02:03', '2018-04-18 13:02:03', '', 171, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/morris-cover.png', 0, 'attachment', 'image/png', 0),
(174, 1, '2018-04-18 09:01:59', '2018-04-18 13:01:59', '', 'morris-cover-2', '', 'inherit', 'closed', 'closed', '', 'morris-cover-2', '', '', '2018-04-18 09:02:13', '2018-04-18 13:02:13', '', 171, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/morris-cover-2.png', 0, 'attachment', 'image/png', 0),
(175, 1, '2018-04-18 09:07:33', '2018-04-18 13:07:33', '', 'morris-map', '', 'inherit', 'closed', 'closed', '', 'morris-map', '', '', '2018-04-18 09:07:36', '2018-04-18 13:07:36', '', 171, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/morris-map.png', 0, 'attachment', 'image/png', 0),
(176, 1, '2018-04-18 09:13:18', '2018-04-18 13:13:18', '', 'Atlantis Bahamas', '', 'publish', 'closed', 'closed', '', 'atlantis-bahamas', '', '', '2018-04-18 09:13:18', '2018-04-18 13:13:18', '', 0, 'http://morrisnathanson.dev.cc/?post_type=story&#038;p=176', 0, 'story', '', 0),
(177, 1, '2018-04-18 09:10:47', '2018-04-18 13:10:47', '', 'atlantis-cover-2', '', 'inherit', 'closed', 'closed', '', 'atlantis-cover-2', '', '', '2018-04-18 09:11:15', '2018-04-18 13:11:15', '', 176, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/atlantis-cover-2.png', 0, 'attachment', 'image/png', 0),
(178, 1, '2018-04-18 09:10:48', '2018-04-18 13:10:48', '', 'atlantis-cover', '', 'inherit', 'closed', 'closed', '', 'atlantis-cover', '', '', '2018-04-18 09:11:07', '2018-04-18 13:11:07', '', 176, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/atlantis-cover.png', 0, 'attachment', 'image/png', 0),
(179, 1, '2018-04-18 09:10:49', '2018-04-18 13:10:49', '', 'atlantis-map', '', 'inherit', 'closed', 'closed', '', 'atlantis-map', '', '', '2018-04-18 09:10:54', '2018-04-18 13:10:54', '', 176, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/atlantis-map.png', 0, 'attachment', 'image/png', 0),
(180, 1, '2018-04-18 09:10:49', '2018-04-18 13:10:49', '', 'atlantis', '', 'inherit', 'closed', 'closed', '', 'atlantis', '', '', '2018-04-18 09:10:59', '2018-04-18 13:10:59', '', 176, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/atlantis.png', 0, 'attachment', 'image/png', 0),
(181, 1, '2018-04-18 09:17:39', '2018-04-18 13:17:39', '', 'Euro Disney', '', 'publish', 'closed', 'closed', '', 'euro-disney', '', '', '2018-04-18 09:18:14', '2018-04-18 13:18:14', '', 0, 'http://morrisnathanson.dev.cc/?post_type=story&#038;p=181', 0, 'story', '', 0),
(182, 1, '2018-04-18 09:16:00', '2018-04-18 13:16:00', '', 'euro-disney-cover-2', '', 'inherit', 'closed', 'closed', '', 'euro-disney-cover-2', '', '', '2018-04-18 09:17:32', '2018-04-18 13:17:32', '', 181, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/euro-disney-cover-2.png', 0, 'attachment', 'image/png', 0),
(183, 1, '2018-04-18 09:16:01', '2018-04-18 13:16:01', '', 'euro-disney-cover', '', 'inherit', 'closed', 'closed', '', 'euro-disney-cover', '', '', '2018-04-18 09:16:23', '2018-04-18 13:16:23', '', 181, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/euro-disney-cover.png', 0, 'attachment', 'image/png', 0),
(184, 1, '2018-04-18 09:16:01', '2018-04-18 13:16:01', '', 'euro-disney-map', '', 'inherit', 'closed', 'closed', '', 'euro-disney-map', '', '', '2018-04-18 09:16:07', '2018-04-18 13:16:07', '', 181, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/euro-disney-map.png', 0, 'attachment', 'image/png', 0),
(185, 1, '2018-04-18 09:16:02', '2018-04-18 13:16:02', '', 'euro-disney', '', 'inherit', 'closed', 'closed', '', 'euro-disney', '', '', '2018-04-18 09:16:14', '2018-04-18 13:16:14', '', 181, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/euro-disney.png', 0, 'attachment', 'image/png', 0),
(186, 1, '2018-04-18 09:22:44', '2018-04-18 13:22:44', '', 'Soho Renaissance', '', 'publish', 'closed', 'closed', '', 'soho-renaissance', '', '', '2018-04-18 09:22:44', '2018-04-18 13:22:44', '', 0, 'http://morrisnathanson.dev.cc/?post_type=story&#038;p=186', 0, 'story', '', 0),
(187, 1, '2018-04-18 09:20:48', '2018-04-18 13:20:48', '', 'soho-cover-2', '', 'inherit', 'closed', 'closed', '', 'soho-cover-2', '', '', '2018-04-18 09:21:32', '2018-04-18 13:21:32', '', 186, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/soho-cover-2.png', 0, 'attachment', 'image/png', 0),
(188, 1, '2018-04-18 09:20:49', '2018-04-18 13:20:49', '', 'soho-cover', '', 'inherit', 'closed', 'closed', '', 'soho-cover', '', '', '2018-04-18 09:21:20', '2018-04-18 13:21:20', '', 186, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/soho-cover.png', 0, 'attachment', 'image/png', 0),
(189, 1, '2018-04-18 09:20:49', '2018-04-18 13:20:49', '', 'soho-map', '', 'inherit', 'closed', 'closed', '', 'soho-map', '', '', '2018-04-18 09:21:12', '2018-04-18 13:21:12', '', 186, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/soho-map.png', 0, 'attachment', 'image/png', 0),
(190, 1, '2018-04-18 09:20:50', '2018-04-18 13:20:50', '', 'soho', '', 'inherit', 'closed', 'closed', '', 'soho', '', '', '2018-04-18 09:21:03', '2018-04-18 13:21:03', '', 186, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/soho.png', 0, 'attachment', 'image/png', 0),
(191, 1, '2018-04-18 09:44:47', '2018-04-18 13:44:47', '', 'Gallery', '', 'publish', 'closed', 'closed', '', 'gallery-2', '', '', '2018-04-18 09:47:40', '2018-04-18 13:47:40', '', 0, 'http://morrisnathanson.dev.cc/?p=191', 1, 'nav_menu_item', '', 0),
(192, 1, '2018-04-18 09:47:30', '2018-04-18 13:47:30', '', 'Stories', '', 'publish', 'closed', 'closed', '', 'stories', '', '', '2018-04-18 09:47:40', '2018-04-18 13:47:40', '', 0, 'http://morrisnathanson.dev.cc/?p=192', 4, 'nav_menu_item', '', 0),
(193, 1, '2018-04-18 09:51:42', '2018-04-18 13:51:42', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:7:\"gallery\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Gallery (Single post)', 'gallery-single-post', 'publish', 'closed', 'closed', '', 'group_5ad74cc2a7511', '', '', '2018-04-18 15:06:03', '2018-04-18 19:06:03', '', 0, 'http://morrisnathanson.dev.cc/?post_type=acf-field-group&#038;p=193', 0, 'acf-field-group', '', 0),
(194, 1, '2018-04-18 09:51:42', '2018-04-18 13:51:42', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:6:\"Medium\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Gallery Medium', 'gallery_medium', 'publish', 'closed', 'closed', '', 'field_5ad74ce5bcc7b', '', '', '2018-04-18 12:17:00', '2018-04-18 16:17:00', '', 193, 'http://morrisnathanson.dev.cc/?post_type=acf-field&#038;p=194', 0, 'acf-field', '', 0),
(195, 1, '2018-04-18 09:51:42', '2018-04-18 13:51:42', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";i:2018;s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Gallery Year', 'gallery_year', 'publish', 'closed', 'closed', '', 'field_5ad74d51bcc7c', '', '', '2018-04-18 09:51:42', '2018-04-18 13:51:42', '', 193, 'http://morrisnathanson.dev.cc/?post_type=acf-field&p=195', 1, 'acf-field', '', 0),
(197, 1, '2018-04-18 10:26:53', '2018-04-18 14:26:53', '', 'Bar and Open Kitchen', '', 'publish', 'closed', 'closed', '', 'bar-and-open-kitchen', '', '', '2018-04-18 15:08:03', '2018-04-18 19:08:03', '', 0, 'http://morrisnathanson.dev.cc/?post_type=gallery&#038;p=197', 0, 'gallery', '', 0),
(198, 1, '2018-04-18 10:26:33', '2018-04-18 14:26:33', '', '2 bar-open-kitchen-510x689', '', 'inherit', 'closed', 'closed', '', '2-bar-open-kitchen-510x689', '', '', '2018-04-18 10:26:33', '2018-04-18 14:26:33', '', 197, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/2-bar-open-kitchen-510x689.png', 0, 'attachment', 'image/png', 0),
(200, 1, '2018-04-18 10:26:35', '2018-04-18 14:26:35', '', '4 birmingham_church-510x636', '', 'inherit', 'closed', 'closed', '', '4-birmingham_church-510x636', '', '', '2018-04-18 10:26:35', '2018-04-18 14:26:35', '', 197, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/4-birmingham_church-510x636.png', 0, 'attachment', 'image/png', 0),
(201, 1, '2018-04-18 10:26:35', '2018-04-18 14:26:35', '', '5 brush-510x690', '', 'inherit', 'closed', 'closed', '', '5-brush-510x690', '', '', '2018-04-18 10:26:35', '2018-04-18 14:26:35', '', 197, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/5-brush-510x690.png', 0, 'attachment', 'image/png', 0),
(202, 1, '2018-04-18 10:26:36', '2018-04-18 14:26:36', '', '6 clock-510x681', '', 'inherit', 'closed', 'closed', '', '6-clock-510x681', '', '', '2018-04-18 10:26:36', '2018-04-18 14:26:36', '', 197, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/6-clock-510x681.png', 0, 'attachment', 'image/png', 0),
(203, 1, '2018-04-18 10:26:37', '2018-04-18 14:26:37', '', '7 doctor-south-africa-510x426', '', 'inherit', 'closed', 'closed', '', '7-doctor-south-africa-510x426', '', '', '2018-04-18 10:26:37', '2018-04-18 14:26:37', '', 197, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/7-doctor-south-africa-510x426.png', 0, 'attachment', 'image/png', 0),
(204, 1, '2018-04-18 10:26:38', '2018-04-18 14:26:38', '', '8 hector-510x675', '', 'inherit', 'closed', 'closed', '', '8-hector-510x675', '', '', '2018-04-18 10:26:38', '2018-04-18 14:26:38', '', 197, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/8-hector-510x675.png', 0, 'attachment', 'image/png', 0),
(205, 1, '2018-04-18 10:26:39', '2018-04-18 14:26:39', '', '9 japonica-510x790', '', 'inherit', 'closed', 'closed', '', '9-japonica-510x790', '', '', '2018-04-18 10:26:39', '2018-04-18 14:26:39', '', 197, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/9-japonica-510x790.png', 0, 'attachment', 'image/png', 0),
(206, 1, '2018-04-18 10:26:39', '2018-04-18 14:26:39', '', '10 key-510x708', '', 'inherit', 'closed', 'closed', '', '10-key-510x708', '', '', '2018-04-18 10:26:39', '2018-04-18 14:26:39', '', 197, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/10-key-510x708.png', 0, 'attachment', 'image/png', 0),
(207, 1, '2018-04-18 10:26:40', '2018-04-18 14:26:40', '', '11 mother-angel-child-510x735', '', 'inherit', 'closed', 'closed', '', '11-mother-angel-child-510x735', '', '', '2018-04-18 10:26:40', '2018-04-18 14:26:40', '', 197, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/11-mother-angel-child-510x735.png', 0, 'attachment', 'image/png', 0),
(208, 1, '2018-04-18 10:26:41', '2018-04-18 14:26:41', '', '12 moon-beauty-510x425', '', 'inherit', 'closed', 'closed', '', '12-moon-beauty-510x425', '', '', '2018-04-18 10:26:41', '2018-04-18 14:26:41', '', 197, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/12-moon-beauty-510x425.png', 0, 'attachment', 'image/png', 0),
(209, 1, '2018-04-18 10:27:46', '2018-04-18 14:27:46', '', 'Clock', '', 'publish', 'closed', 'closed', '', 'clock', '', '', '2018-04-18 15:08:16', '2018-04-18 19:08:16', '', 0, 'http://morrisnathanson.dev.cc/?post_type=gallery&#038;p=209', 0, 'gallery', '', 0),
(210, 1, '2018-04-18 10:28:27', '2018-04-18 14:28:27', '', 'Birmingham Church', '', 'publish', 'closed', 'closed', '', 'birmingham-church', '', '', '2018-04-18 15:08:31', '2018-04-18 19:08:31', '', 0, 'http://morrisnathanson.dev.cc/?post_type=gallery&#038;p=210', 0, 'gallery', '', 0),
(211, 1, '2018-04-18 10:28:53', '2018-04-18 14:28:53', '', 'Brush', '', 'publish', 'closed', 'closed', '', 'brush', '', '', '2018-04-18 15:08:40', '2018-04-18 19:08:40', '', 0, 'http://morrisnathanson.dev.cc/?post_type=gallery&#038;p=211', 0, 'gallery', '', 0),
(212, 1, '2018-04-18 10:30:02', '2018-04-18 14:30:02', '', 'Assemblage - Glove Man', '', 'publish', 'closed', 'closed', '', 'assemblage-glove-man', '', '', '2018-04-18 15:08:48', '2018-04-18 19:08:48', '', 0, 'http://morrisnathanson.dev.cc/?post_type=gallery&#038;p=212', 0, 'gallery', '', 0),
(213, 1, '2018-04-18 10:29:55', '2018-04-18 14:29:55', '', '1 glove-man-510x715', '', 'inherit', 'closed', 'closed', '', '1-glove-man-510x715', '', '', '2018-04-18 10:29:55', '2018-04-18 14:29:55', '', 212, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/1-glove-man-510x715.png', 0, 'attachment', 'image/png', 0),
(214, 1, '2018-04-18 10:30:30', '2018-04-18 14:30:30', '', 'Doctor in South Africa', '', 'publish', 'closed', 'closed', '', 'doctor-in-south-africa', '', '', '2018-04-18 15:09:00', '2018-04-18 19:09:00', '', 0, 'http://morrisnathanson.dev.cc/?post_type=gallery&#038;p=214', 0, 'gallery', '', 0),
(215, 1, '2018-04-18 10:30:54', '2018-04-18 14:30:54', '', 'Hector', '', 'publish', 'closed', 'closed', '', 'hector', '', '', '2018-04-18 15:09:08', '2018-04-18 19:09:08', '', 0, 'http://morrisnathanson.dev.cc/?post_type=gallery&#038;p=215', 0, 'gallery', '', 0),
(216, 1, '2018-04-18 10:31:23', '2018-04-18 14:31:23', '', 'Japonica Street', '', 'publish', 'closed', 'closed', '', 'japonica-street', '', '', '2018-04-18 15:09:21', '2018-04-18 19:09:21', '', 0, 'http://morrisnathanson.dev.cc/?post_type=gallery&#038;p=216', 0, 'gallery', '', 0),
(217, 1, '2018-04-18 10:31:54', '2018-04-18 14:31:54', '', 'Key', '', 'publish', 'closed', 'closed', '', 'key', '', '', '2018-04-18 15:09:30', '2018-04-18 19:09:30', '', 0, 'http://morrisnathanson.dev.cc/?post_type=gallery&#038;p=217', 0, 'gallery', '', 0),
(218, 1, '2018-04-18 10:32:35', '2018-04-18 14:32:35', '', 'Madonna and Child', '', 'publish', 'closed', 'closed', '', 'madonna-and-child', '', '', '2018-04-18 15:09:37', '2018-04-18 19:09:37', '', 0, 'http://morrisnathanson.dev.cc/?post_type=gallery&#038;p=218', 0, 'gallery', '', 0),
(219, 1, '2018-04-18 10:32:58', '2018-04-18 14:32:58', '', 'Moon Beauty', '', 'publish', 'closed', 'closed', '', 'moon-beauty', '', '', '2018-04-18 15:09:45', '2018-04-18 19:09:45', '', 0, 'http://morrisnathanson.dev.cc/?post_type=gallery&#038;p=219', 0, 'gallery', '', 0),
(220, 1, '2018-04-18 12:49:12', '2018-04-18 16:49:12', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:11:\"18”x12”\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Gallery Size', 'gallery_size', 'publish', 'closed', 'closed', '', 'field_5ad776f9a7194', '', '', '2018-04-18 12:49:12', '2018-04-18 16:49:12', '', 193, 'http://morrisnathanson.dev.cc/?post_type=acf-field&p=220', 2, 'acf-field', '', 0),
(221, 1, '2018-04-18 13:34:18', '2018-04-18 17:34:18', '', 'bar-mitzva-on-japonica-510x628', '', 'inherit', 'closed', 'closed', '', 'bar-mitzva-on-japonica-510x628', '', '', '2018-04-18 13:34:18', '2018-04-18 17:34:18', '', 38, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/bar-mitzva-on-japonica-510x628.png', 0, 'attachment', 'image/png', 0),
(222, 1, '2018-04-18 14:01:41', '2018-04-18 18:01:41', '', 'DSC02390', '', 'inherit', 'closed', 'closed', '', 'dsc02390', '', '', '2018-04-18 14:01:41', '2018-04-18 18:01:41', '', 39, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/DSC02390.jpg', 0, 'attachment', 'image/jpeg', 0),
(223, 1, '2018-04-18 14:01:42', '2018-04-18 18:01:42', '', 'DSC02391', '', 'inherit', 'closed', 'closed', '', 'dsc02391', '', '', '2018-04-18 14:01:42', '2018-04-18 18:01:42', '', 39, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/DSC02391.jpg', 0, 'attachment', 'image/jpeg', 0),
(224, 1, '2018-04-18 14:01:43', '2018-04-18 18:01:43', '', 'DSC02392', '', 'inherit', 'closed', 'closed', '', 'dsc02392', '', '', '2018-04-18 14:01:43', '2018-04-18 18:01:43', '', 39, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/DSC02392.jpg', 0, 'attachment', 'image/jpeg', 0),
(225, 1, '2018-04-18 14:01:44', '2018-04-18 18:01:44', '', 'DSC02395', '', 'inherit', 'closed', 'closed', '', 'dsc02395', '', '', '2018-04-18 14:01:44', '2018-04-18 18:01:44', '', 39, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/DSC02395.jpg', 0, 'attachment', 'image/jpeg', 0),
(226, 1, '2018-04-18 14:01:44', '2018-04-18 18:01:44', '', 'DSC02396', '', 'inherit', 'closed', 'closed', '', 'dsc02396', '', '', '2018-04-18 14:01:44', '2018-04-18 18:01:44', '', 39, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/DSC02396.jpg', 0, 'attachment', 'image/jpeg', 0),
(227, 1, '2018-04-18 14:01:45', '2018-04-18 18:01:45', '', 'DSC02399', '', 'inherit', 'closed', 'closed', '', 'dsc02399', '', '', '2018-04-18 14:01:45', '2018-04-18 18:01:45', '', 39, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/DSC02399.jpg', 0, 'attachment', 'image/jpeg', 0),
(228, 1, '2018-04-18 14:01:46', '2018-04-18 18:01:46', '', 'DSC023911', '', 'inherit', 'closed', 'closed', '', 'dsc023911', '', '', '2018-04-18 14:01:46', '2018-04-18 18:01:46', '', 39, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/DSC023911.jpg', 0, 'attachment', 'image/jpeg', 0),
(230, 1, '2018-04-18 14:01:48', '2018-04-18 18:01:48', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 'Product Name', 'Lorem ipsum dolor sit amet.', 'inherit', 'closed', 'closed', '', '39-autosave-v1', '', '', '2018-04-18 14:01:48', '2018-04-18 18:01:48', '', 39, 'http://morrisnathanson.dev.cc/39-autosave-v1/', 0, 'revision', '', 0),
(232, 1, '2018-04-18 14:05:13', '2018-04-18 18:05:13', '', 'relief-print-1', '', 'inherit', 'closed', 'closed', '', 'relief-print-1', '', '', '2018-04-18 14:05:13', '2018-04-18 18:05:13', '', 39, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/relief-print-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(233, 1, '2018-04-18 14:05:13', '2018-04-18 18:05:13', '', 'relief-print-4', '', 'inherit', 'closed', 'closed', '', 'relief-print-4', '', '', '2018-04-18 14:05:13', '2018-04-18 18:05:13', '', 39, 'http://morrisnathanson.dev.cc/wp-content/uploads/2018/04/relief-print-4.jpg', 0, 'attachment', 'image/jpeg', 0),
(234, 1, '2018-04-18 14:06:34', '2018-04-18 18:06:34', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 'Product Name', 'Description', 'publish', 'closed', 'closed', '', 'product-name-1', '', '', '2018-04-19 12:27:11', '2018-04-19 16:27:11', '', 0, 'http://morrisnathanson.dev.cc/?post_type=product&#038;p=234', 0, 'product', '', 0),
(235, 1, '2018-04-18 14:08:00', '2018-04-18 18:08:00', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 'Product Name', 'Description', 'publish', 'closed', 'closed', '', 'product-name-2', '', '', '2018-04-19 12:27:19', '2018-04-19 16:27:19', '', 0, 'http://morrisnathanson.dev.cc/?post_type=product&#038;p=235', 0, 'product', '', 0),
(236, 1, '2018-04-18 14:08:36', '2018-04-18 18:08:36', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 'Product Name', 'Description', 'publish', 'closed', 'closed', '', 'product-name-3', '', '', '2018-04-19 12:27:26', '2018-04-19 16:27:26', '', 0, 'http://morrisnathanson.dev.cc/?post_type=product&#038;p=236', 0, 'product', '', 0),
(237, 1, '2018-04-18 14:09:08', '2018-04-18 18:09:08', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 'Product Name', 'Description', 'publish', 'closed', 'closed', '', 'product-name-4', '', '', '2018-04-19 12:27:34', '2018-04-19 16:27:34', '', 0, 'http://morrisnathanson.dev.cc/?post_type=product&#038;p=237', 0, 'product', '', 0),
(238, 1, '2018-04-18 14:09:41', '2018-04-18 18:09:41', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 'Product Name', 'Description', 'publish', 'closed', 'closed', '', 'product-name-5', '', '', '2018-04-19 12:27:40', '2018-04-19 16:27:40', '', 0, 'http://morrisnathanson.dev.cc/?post_type=product&#038;p=238', 0, 'product', '', 0),
(239, 1, '2018-04-18 14:10:09', '2018-04-18 18:10:09', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 'Product Name', 'Description', 'publish', 'closed', 'closed', '', 'product-name-6', '', '', '2018-04-19 12:27:47', '2018-04-19 16:27:47', '', 0, 'http://morrisnathanson.dev.cc/?post_type=product&#038;p=239', 0, 'product', '', 0),
(240, 1, '2018-04-18 14:10:41', '2018-04-18 18:10:41', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 'Product Name', 'Description', 'publish', 'closed', 'closed', '', 'product-name-7', '', '', '2018-04-19 12:27:54', '2018-04-19 16:27:54', '', 0, 'http://morrisnathanson.dev.cc/?post_type=product&#038;p=240', 0, 'product', '', 0),
(241, 1, '2018-04-18 14:11:16', '2018-04-18 18:11:16', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 'Product Name', 'Description', 'publish', 'closed', 'closed', '', 'product-name-8', '', '', '2018-04-19 12:26:27', '2018-04-19 16:26:27', '', 0, 'http://morrisnathanson.dev.cc/?post_type=product&#038;p=241', 0, 'product', '', 0),
(242, 1, '2018-04-18 15:06:03', '2018-04-18 19:06:03', 'a:13:{s:4:\"type\";s:6:\"select\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:7:\"choices\";a:2:{s:4:\"Sold\";s:4:\"Sold\";s:9:\"Available\";s:9:\"Available\";}s:13:\"default_value\";a:1:{i:0;s:9:\"Available\";}s:10:\"allow_null\";i:0;s:8:\"multiple\";i:0;s:2:\"ui\";i:0;s:4:\"ajax\";i:0;s:13:\"return_format\";s:5:\"value\";s:11:\"placeholder\";s:0:\"\";}', 'Gallery Status', 'gallery_status', 'publish', 'closed', 'closed', '', 'field_5ad796bd52c42', '', '', '2018-04-18 15:06:03', '2018-04-18 19:06:03', '', 193, 'http://morrisnathanson.dev.cc/?post_type=acf-field&p=242', 3, 'acf-field', '', 0),
(243, 1, '2018-04-19 09:01:48', '2018-04-19 13:01:48', '', 'Shop Prints', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-04-19 09:01:48', '2018-04-19 13:01:48', '', 34, 'http://morrisnathanson.dev.cc/34-revision-v1/', 0, 'revision', '', 0),
(244, 1, '2018-04-19 11:07:00', '2018-04-19 15:07:00', '[woocommerce_cart]', 'Cart', '', 'inherit', 'closed', 'closed', '', '35-revision-v1', '', '', '2018-04-19 11:07:00', '2018-04-19 15:07:00', '', 35, 'http://morrisnathanson.dev.cc/35-revision-v1/', 0, 'revision', '', 0),
(245, 1, '2018-04-19 11:07:19', '2018-04-19 15:07:19', '[woocommerce_checkout]', 'Checkout', '', 'inherit', 'closed', 'closed', '', '36-revision-v1', '', '', '2018-04-19 11:07:19', '2018-04-19 15:07:19', '', 36, 'http://morrisnathanson.dev.cc/36-revision-v1/', 0, 'revision', '', 0),
(246, 1, '2018-04-19 11:07:37', '2018-04-19 15:07:37', '[woocommerce_my_account]', 'My account', '', 'inherit', 'closed', 'closed', '', '37-revision-v1', '', '', '2018-04-19 11:07:37', '2018-04-19 15:07:37', '', 37, 'http://morrisnathanson.dev.cc/37-revision-v1/', 0, 'revision', '', 0),
(247, 1, '2018-04-19 13:01:04', '2018-04-19 17:01:04', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:7:\"product\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Product (Single Post)', 'product-single-post', 'publish', 'closed', 'closed', '', 'group_5ad8cb280d5c3', '', '', '2018-04-19 13:01:04', '2018-04-19 17:01:04', '', 0, 'http://morrisnathanson.dev.cc/?post_type=acf-field-group&#038;p=247', 0, 'acf-field-group', '', 0),
(248, 1, '2018-04-19 13:01:04', '2018-04-19 17:01:04', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:11:\"18”x12”\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Product Size', 'product_size', 'publish', 'closed', 'closed', '', 'field_5ad8cb36aa7af', '', '', '2018-04-19 13:01:04', '2018-04-19 17:01:04', '', 247, 'http://morrisnathanson.dev.cc/?post_type=acf-field&p=248', 0, 'acf-field', '', 0);
INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(249, 1, '2018-04-19 23:22:13', '2018-04-20 03:22:13', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Slide Image', 'slide_image', 'publish', 'closed', 'closed', '', 'field_5ad95cc0219a7', '', '', '2018-04-19 23:22:13', '2018-04-20 03:22:13', '', 72, 'http://morrisnathanson.dev.cc/?post_type=acf-field&p=249', 0, 'acf-field', '', 0),
(250, 1, '2018-04-19 23:22:13', '2018-04-20 03:22:13', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Slide Caption', 'slide_caption', 'publish', 'closed', 'closed', '', 'field_5ad95cd6219a8', '', '', '2018-04-19 23:22:13', '2018-04-20 03:22:13', '', 72, 'http://morrisnathanson.dev.cc/?post_type=acf-field&p=250', 1, 'acf-field', '', 0),
(251, 1, '2018-04-19 23:23:38', '2018-04-20 03:23:38', '', 'In the Studio', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2018-04-19 23:23:38', '2018-04-20 03:23:38', '', 52, 'http://morrisnathanson.dev.cc/52-revision-v1/', 0, 'revision', '', 0),
(252, 1, '2018-04-19 23:59:49', '2018-04-20 03:59:49', '', 'In the Studio', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2018-04-19 23:59:49', '2018-04-20 03:59:49', '', 52, 'http://morrisnathanson.dev.cc/52-revision-v1/', 0, 'revision', '', 0),
(253, 1, '2018-04-20 00:25:56', '2018-04-20 04:25:56', '', 'In the Studio', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2018-04-20 00:25:56', '2018-04-20 04:25:56', '', 52, 'http://morrisnathanson.dev.cc/52-revision-v1/', 0, 'revision', '', 0),
(254, 1, '2018-04-20 00:27:37', '2018-04-20 04:27:37', '', 'In the Studio', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2018-04-20 00:27:37', '2018-04-20 04:27:37', '', 52, 'http://morrisnathanson.dev.cc/52-revision-v1/', 0, 'revision', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_termmeta`
--

DROP TABLE IF EXISTS `wp_termmeta`;
CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_termmeta`
--

INSERT INTO `wp_termmeta` (`meta_id`, `term_id`, `meta_key`, `meta_value`) VALUES
(1, 15, 'product_count_product_cat', '3'),
(4, 23, 'order', '0'),
(10, 23, 'display_type', ''),
(11, 23, 'thumbnail_id', '0'),
(12, 23, 'product_count_product_cat', '6');

-- --------------------------------------------------------

--
-- Table structure for table `wp_terms`
--

DROP TABLE IF EXISTS `wp_terms`;
CREATE TABLE `wp_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_terms`
--

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'simple', 'simple', 0),
(3, 'grouped', 'grouped', 0),
(4, 'variable', 'variable', 0),
(5, 'external', 'external', 0),
(6, 'exclude-from-search', 'exclude-from-search', 0),
(7, 'exclude-from-catalog', 'exclude-from-catalog', 0),
(8, 'featured', 'featured', 0),
(9, 'outofstock', 'outofstock', 0),
(10, 'rated-1', 'rated-1', 0),
(11, 'rated-2', 'rated-2', 0),
(12, 'rated-3', 'rated-3', 0),
(13, 'rated-4', 'rated-4', 0),
(14, 'rated-5', 'rated-5', 0),
(15, 'Screen prints', 'screen-prints', 0),
(16, 'Paintings', 'paintings', 0),
(17, 'Drawings', 'drawings', 0),
(18, 'Relief prints', 'relief-prints', 0),
(19, 'Sketches', 'sketches', 0),
(20, 'Assemblages', 'assemblages', 0),
(23, 'Relief prints', 'relief-prints', 0),
(26, '57', '57', 0),
(27, 'Main Nav', 'main-nav', 0),
(28, 'Gallery', 'gallery', 0),
(29, 'In The Studio', 'in-the-studio', 0),
(30, 'Press + Events', 'press-events', 0),
(31, 'Stories', 'stories', 0),
(32, 'Shop Prints', 'shop-prints', 0),
(33, 'Paintings', 'paintings', 0),
(34, 'Drawings', 'drawings', 0),
(35, 'Relief prints', 'relief-prints', 0),
(36, 'Sketches', 'sketches', 0),
(37, 'Assemblages', 'assemblages', 0),
(38, '1970s', '1970s', 0),
(39, '1980s', '1980s', 0),
(40, '1990s', '1990s', 0),
(41, '2000s', '2000s', 0),
(42, '2010s', '2010s', 0),
(43, 'Assemblages', 'assemblages', 0),
(44, 'Sketches', 'sketches', 0),
(45, 'Relief prints', 'relief-prints', 0),
(46, 'Drawings', 'drawings', 0),
(47, 'Paintings', 'paintings', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_relationships`
--

DROP TABLE IF EXISTS `wp_term_relationships`;
CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `wp_term_relationships`
--

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(38, 16, 0),
(38, 47, 0),
(39, 2, 0),
(39, 23, 0),
(61, 26, 0),
(62, 26, 0),
(63, 26, 0),
(76, 27, 0),
(97, 27, 0),
(140, 28, 0),
(141, 28, 0),
(142, 28, 0),
(143, 28, 0),
(144, 28, 0),
(145, 28, 0),
(146, 29, 0),
(147, 29, 0),
(148, 29, 0),
(149, 29, 0),
(150, 30, 0),
(151, 30, 0),
(152, 30, 0),
(153, 31, 0),
(154, 32, 0),
(155, 32, 0),
(166, 42, 0),
(167, 27, 0),
(171, 41, 0),
(176, 40, 0),
(181, 40, 0),
(186, 38, 0),
(191, 27, 0),
(192, 27, 0),
(197, 44, 0),
(197, 46, 0),
(209, 43, 0),
(210, 47, 0),
(211, 43, 0),
(212, 43, 0),
(214, 46, 0),
(214, 47, 0),
(215, 43, 0),
(216, 44, 0),
(217, 43, 0),
(218, 46, 0),
(219, 47, 0),
(234, 2, 0),
(234, 15, 0),
(235, 2, 0),
(235, 23, 0),
(236, 2, 0),
(236, 23, 0),
(237, 2, 0),
(237, 15, 0),
(238, 2, 0),
(238, 9, 0),
(238, 23, 0),
(239, 2, 0),
(239, 23, 0),
(240, 2, 0),
(240, 23, 0),
(241, 2, 0),
(241, 9, 0),
(241, 15, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_taxonomy`
--

DROP TABLE IF EXISTS `wp_term_taxonomy`;
CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_term_taxonomy`
--

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 0),
(2, 2, 'product_type', '', 0, 9),
(3, 3, 'product_type', '', 0, 0),
(4, 4, 'product_type', '', 0, 0),
(5, 5, 'product_type', '', 0, 0),
(6, 6, 'product_visibility', '', 0, 0),
(7, 7, 'product_visibility', '', 0, 0),
(8, 8, 'product_visibility', '', 0, 0),
(9, 9, 'product_visibility', '', 0, 2),
(10, 10, 'product_visibility', '', 0, 0),
(11, 11, 'product_visibility', '', 0, 0),
(12, 12, 'product_visibility', '', 0, 0),
(13, 13, 'product_visibility', '', 0, 0),
(14, 14, 'product_visibility', '', 0, 0),
(15, 15, 'product_cat', '', 0, 3),
(16, 16, 'category', '', 0, 1),
(17, 17, 'category', '', 0, 0),
(18, 18, 'category', '', 0, 0),
(19, 19, 'category', '', 0, 0),
(20, 20, 'category', '', 0, 0),
(23, 23, 'product_cat', '', 0, 6),
(26, 26, 'ml-slider', '', 0, 3),
(27, 27, 'nav_menu', '', 0, 5),
(28, 28, 'nav_menu', '', 0, 6),
(29, 29, 'nav_menu', '', 0, 4),
(30, 30, 'nav_menu', '', 0, 3),
(31, 31, 'nav_menu', '', 0, 1),
(32, 32, 'nav_menu', '', 0, 2),
(33, 33, 'gallerry-category', '', 0, 0),
(34, 34, 'gallerry-category', '', 0, 0),
(35, 35, 'gallerry-category', '', 0, 0),
(36, 36, 'gallerry-category', '', 0, 0),
(37, 37, 'gallerry-category', '', 0, 0),
(38, 38, 'story-category', '', 0, 1),
(39, 39, 'story-category', '', 0, 0),
(40, 40, 'story-category', '', 0, 2),
(41, 41, 'story-category', '', 0, 1),
(42, 42, 'story-category', '', 0, 1),
(43, 43, 'gallery-category', '', 0, 5),
(44, 44, 'gallery-category', '', 0, 2),
(45, 45, 'gallery-category', '', 0, 0),
(46, 46, 'gallery-category', '', 0, 3),
(47, 47, 'gallery-category', '', 0, 4);

-- --------------------------------------------------------

--
-- Table structure for table `wp_usermeta`
--

DROP TABLE IF EXISTS `wp_usermeta`;
CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_usermeta`
--

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'false'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:\"administrator\";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'theme_editor_notice'),
(15, 1, 'show_welcome_panel', '0'),
(16, 1, 'session_tokens', 'a:6:{s:64:\"bffc85c86a66e9b9b94fe00253e103c34b40d8f0616422ff60d5cd2d516b6c16\";a:4:{s:10:\"expiration\";i:1524257270;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:117:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1 Safari/605.1.15\";s:5:\"login\";i:1523047670;}s:64:\"716711bd53290ea3682e709e23b0bd5fbb0a54315c847b30b37a0d2b37f228b9\";a:4:{s:10:\"expiration\";i:1524257300;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:82:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.12; rv:60.0) Gecko/20100101 Firefox/60.0\";s:5:\"login\";i:1523047700;}s:64:\"40a5fb1730f5e14a4137d28c644c3ccbe337a468cd89fb94b4e5949c6420924d\";a:4:{s:10:\"expiration\";i:1524858708;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:82:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.12; rv:60.0) Gecko/20100101 Firefox/60.0\";s:5:\"login\";i:1523649108;}s:64:\"dd5d7d0d944ed854270b65d3d55ea819285165bcb75852e5bd0fd091bd55ee31\";a:4:{s:10:\"expiration\";i:1525107494;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:121:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36\";s:5:\"login\";i:1523897894;}s:64:\"9ee4c9a4f024f5dcdd248088bc43fe7575dc981130f00d0a694ac8fb4028c7fe\";a:4:{s:10:\"expiration\";i:1524185196;s:2:\"ip\";s:12:\"192.168.50.1\";s:2:\"ua\";s:121:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36\";s:5:\"login\";i:1524012396;}s:64:\"9692860ba798cd543a51729c5e970c8c370e13c4b4a0a489d99eea92502a0469\";a:4:{s:10:\"expiration\";i:1524345284;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:121:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36\";s:5:\"login\";i:1524172484;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '137'),
(18, 1, 'community-events-location', 'a:1:{s:2:\"ip\";s:9:\"127.0.0.0\";}'),
(19, 1, 'wp_user-settings', 'libraryContent=browse&hidetb=0&editor=html'),
(20, 1, 'wp_user-settings-time', '1524162939'),
(21, 1, 'closedpostboxes_post', 'a:0:{}'),
(22, 1, 'metaboxhidden_post', 'a:7:{i:0;s:23:\"acf-group_5acb54ae907a5\";i:1;s:11:\"postexcerpt\";i:2;s:13:\"trackbacksdiv\";i:3;s:16:\"commentstatusdiv\";i:4;s:11:\"commentsdiv\";i:5;s:7:\"slugdiv\";i:6;s:9:\"authordiv\";}'),
(23, 1, '_woocommerce_persistent_cart_1', 'a:1:{s:4:\"cart\";a:1:{s:32:\"01161aaa0b6d1345dd8fe4e481144d84\";a:10:{s:3:\"key\";s:32:\"01161aaa0b6d1345dd8fe4e481144d84\";s:10:\"product_id\";i:236;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:30000;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:30000;s:8:\"line_tax\";i:0;}}}'),
(24, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}'),
(25, 1, 'metaboxhidden_nav-menus', 'a:6:{i:0;s:21:\"add-post-type-gallery\";i:1;s:21:\"add-post-type-product\";i:2;s:12:\"add-post_tag\";i:3;s:15:\"add-post_format\";i:4;s:15:\"add-product_cat\";i:5;s:15:\"add-product_tag\";}'),
(26, 1, 'acf_user_settings', 'a:0:{}'),
(27, 1, 'meta-box-order_news-article', 'a:4:{s:15:\"acf_after_title\";s:0:\"\";s:4:\"side\";s:51:\"submitdiv,categorydiv,tagsdiv-post_tag,postimagediv\";s:6:\"normal\";s:115:\"acf-group_5acbaeaecfd92,acf-group_5acb54ae907a5,acf-group_5accb3a27dd40,postexcerpt,acf-group_5acd1da9059d2,slugdiv\";s:8:\"advanced\";s:0:\"\";}'),
(28, 1, 'screen_layout_news-article', '2'),
(29, 1, 'nav_menu_recently_edited', '27'),
(30, 1, 'billing_first_name', ''),
(31, 1, 'billing_last_name', ''),
(32, 1, 'billing_company', ''),
(33, 1, 'billing_address_1', ''),
(34, 1, 'billing_address_2', ''),
(35, 1, 'billing_city', ''),
(36, 1, 'billing_postcode', ''),
(37, 1, 'billing_country', ''),
(38, 1, 'billing_state', ''),
(39, 1, 'billing_phone', ''),
(40, 1, 'billing_email', 'dan@delindesign.com'),
(41, 1, 'shipping_first_name', ''),
(42, 1, 'shipping_last_name', ''),
(43, 1, 'shipping_company', ''),
(44, 1, 'shipping_address_1', ''),
(45, 1, 'shipping_address_2', ''),
(46, 1, 'shipping_city', ''),
(47, 1, 'shipping_postcode', ''),
(48, 1, 'shipping_country', ''),
(49, 1, 'shipping_state', ''),
(50, 1, 'last_update', '1523902847'),
(51, 1, 'jetpack_tracks_anon_id', 'jetpack:4Xb6WgNu9AYZx91RE/QGs+HN'),
(52, 1, 'wpcf7_hide_welcome_panel_on', 'a:1:{i:0;s:3:\"5.0\";}');

-- --------------------------------------------------------

--
-- Table structure for table `wp_users`
--

DROP TABLE IF EXISTS `wp_users`;
CREATE TABLE `wp_users` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_users`
--

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$BbvYsWU05.fdhLbyWhlK3RGNQhkQBE0', 'admin', 'dan@delindesign.com', '', '2018-04-06 20:47:38', '', 0, 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_download_log`
--

DROP TABLE IF EXISTS `wp_wc_download_log`;
CREATE TABLE `wp_wc_download_log` (
  `download_log_id` bigint(20) UNSIGNED NOT NULL,
  `timestamp` datetime NOT NULL,
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `user_ip_address` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_webhooks`
--

DROP TABLE IF EXISTS `wp_wc_webhooks`;
CREATE TABLE `wp_wc_webhooks` (
  `webhook_id` bigint(20) UNSIGNED NOT NULL,
  `status` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `delivery_url` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `topic` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `api_version` smallint(4) NOT NULL,
  `failure_count` smallint(10) NOT NULL DEFAULT '0',
  `pending_delivery` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_api_keys`
--

DROP TABLE IF EXISTS `wp_woocommerce_api_keys`;
CREATE TABLE `wp_woocommerce_api_keys` (
  `key_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `description` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permissions` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `consumer_key` char(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `consumer_secret` char(43) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `nonces` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `truncated_key` char(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_access` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_attribute_taxonomies`
--

DROP TABLE IF EXISTS `wp_woocommerce_attribute_taxonomies`;
CREATE TABLE `wp_woocommerce_attribute_taxonomies` (
  `attribute_id` bigint(20) UNSIGNED NOT NULL,
  `attribute_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute_label` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attribute_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute_orderby` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute_public` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_downloadable_product_permissions`
--

DROP TABLE IF EXISTS `wp_woocommerce_downloadable_product_permissions`;
CREATE TABLE `wp_woocommerce_downloadable_product_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `download_id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `order_key` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_email` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `downloads_remaining` varchar(9) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `access_granted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access_expires` datetime DEFAULT NULL,
  `download_count` bigint(20) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_log`
--

DROP TABLE IF EXISTS `wp_woocommerce_log`;
CREATE TABLE `wp_woocommerce_log` (
  `log_id` bigint(20) UNSIGNED NOT NULL,
  `timestamp` datetime NOT NULL,
  `level` smallint(4) NOT NULL,
  `source` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `context` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_order_itemmeta`
--

DROP TABLE IF EXISTS `wp_woocommerce_order_itemmeta`;
CREATE TABLE `wp_woocommerce_order_itemmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `order_item_id` bigint(20) UNSIGNED NOT NULL,
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_order_items`
--

DROP TABLE IF EXISTS `wp_woocommerce_order_items`;
CREATE TABLE `wp_woocommerce_order_items` (
  `order_item_id` bigint(20) UNSIGNED NOT NULL,
  `order_item_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_item_type` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `order_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_payment_tokenmeta`
--

DROP TABLE IF EXISTS `wp_woocommerce_payment_tokenmeta`;
CREATE TABLE `wp_woocommerce_payment_tokenmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `payment_token_id` bigint(20) UNSIGNED NOT NULL,
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_payment_tokens`
--

DROP TABLE IF EXISTS `wp_woocommerce_payment_tokens`;
CREATE TABLE `wp_woocommerce_payment_tokens` (
  `token_id` bigint(20) UNSIGNED NOT NULL,
  `gateway_id` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `type` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_sessions`
--

DROP TABLE IF EXISTS `wp_woocommerce_sessions`;
CREATE TABLE `wp_woocommerce_sessions` (
  `session_id` bigint(20) UNSIGNED NOT NULL,
  `session_key` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_expiry` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_woocommerce_sessions`
--

INSERT INTO `wp_woocommerce_sessions` (`session_id`, `session_key`, `session_value`, `session_expiry`) VALUES
(36, '1', 'a:9:{s:4:\"cart\";s:361:\"a:1:{s:32:\"01161aaa0b6d1345dd8fe4e481144d84\";a:10:{s:3:\"key\";s:32:\"01161aaa0b6d1345dd8fe4e481144d84\";s:10:\"product_id\";i:236;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:30000;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:30000;s:8:\"line_tax\";i:0;}}\";s:11:\"cart_totals\";s:414:\"a:15:{s:8:\"subtotal\";s:8:\"30000.00\";s:12:\"subtotal_tax\";d:0;s:14:\"shipping_total\";s:4:\"0.00\";s:12:\"shipping_tax\";d:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";d:0;s:12:\"discount_tax\";d:0;s:19:\"cart_contents_total\";s:8:\"30000.00\";s:17:\"cart_contents_tax\";d:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";s:4:\"0.00\";s:7:\"fee_tax\";d:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";s:8:\"30000.00\";s:9:\"total_tax\";d:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:1428:\"a:4:{s:32:\"577ef1154f3240ad5b9b413aa7346a1e\";a:10:{s:3:\"key\";s:32:\"577ef1154f3240ad5b9b413aa7346a1e\";s:10:\"product_id\";i:235;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:2;s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:60000;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:60000;s:8:\"line_tax\";i:0;}s:32:\"555d6702c950ecb729a966504af0a635\";a:10:{s:3:\"key\";s:32:\"555d6702c950ecb729a966504af0a635\";s:10:\"product_id\";i:239;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:30000;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:30000;s:8:\"line_tax\";i:0;}s:32:\"d67d8ab4f4c10bf22aa353e27879133c\";a:10:{s:3:\"key\";s:32:\"d67d8ab4f4c10bf22aa353e27879133c\";s:10:\"product_id\";i:39;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:11;s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:330000;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:330000;s:8:\"line_tax\";i:0;}s:32:\"539fd53b59e3bb12d203f45a912eeaf2\";a:10:{s:3:\"key\";s:32:\"539fd53b59e3bb12d203f45a912eeaf2\";s:10:\"product_id\";i:237;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:30000;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:30000;s:8:\"line_tax\";i:0;}}\";s:8:\"customer\";s:738:\"a:26:{s:2:\"id\";s:1:\"1\";s:13:\"date_modified\";s:25:\"2018-04-16T14:20:47-04:00\";s:8:\"postcode\";s:0:\"\";s:4:\"city\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:5:\"state\";s:2:\"RI\";s:7:\"country\";s:2:\"US\";s:17:\"shipping_postcode\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:14:\"shipping_state\";s:2:\"RI\";s:16:\"shipping_country\";s:2:\"US\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:1:\"1\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:19:\"dan@delindesign.com\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";}\";s:10:\"wc_notices\";N;s:21:\"chosen_payment_method\";s:6:\"cheque\";}', 1524318395);

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_shipping_zones`
--

DROP TABLE IF EXISTS `wp_woocommerce_shipping_zones`;
CREATE TABLE `wp_woocommerce_shipping_zones` (
  `zone_id` bigint(20) UNSIGNED NOT NULL,
  `zone_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zone_order` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_woocommerce_shipping_zones`
--

INSERT INTO `wp_woocommerce_shipping_zones` (`zone_id`, `zone_name`, `zone_order`) VALUES
(1, 'United States (US)', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_shipping_zone_locations`
--

DROP TABLE IF EXISTS `wp_woocommerce_shipping_zone_locations`;
CREATE TABLE `wp_woocommerce_shipping_zone_locations` (
  `location_id` bigint(20) UNSIGNED NOT NULL,
  `zone_id` bigint(20) UNSIGNED NOT NULL,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_woocommerce_shipping_zone_locations`
--

INSERT INTO `wp_woocommerce_shipping_zone_locations` (`location_id`, `zone_id`, `location_code`, `location_type`) VALUES
(1, 1, 'US', 'country');

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_shipping_zone_methods`
--

DROP TABLE IF EXISTS `wp_woocommerce_shipping_zone_methods`;
CREATE TABLE `wp_woocommerce_shipping_zone_methods` (
  `zone_id` bigint(20) UNSIGNED NOT NULL,
  `instance_id` bigint(20) UNSIGNED NOT NULL,
  `method_id` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `method_order` bigint(20) UNSIGNED NOT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_tax_rates`
--

DROP TABLE IF EXISTS `wp_woocommerce_tax_rates`;
CREATE TABLE `wp_woocommerce_tax_rates` (
  `tax_rate_id` bigint(20) UNSIGNED NOT NULL,
  `tax_rate_country` varchar(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate_state` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate_priority` bigint(20) UNSIGNED NOT NULL,
  `tax_rate_compound` int(1) NOT NULL DEFAULT '0',
  `tax_rate_shipping` int(1) NOT NULL DEFAULT '1',
  `tax_rate_order` bigint(20) UNSIGNED NOT NULL,
  `tax_rate_class` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_tax_rate_locations`
--

DROP TABLE IF EXISTS `wp_woocommerce_tax_rate_locations`;
CREATE TABLE `wp_woocommerce_tax_rate_locations` (
  `location_id` bigint(20) UNSIGNED NOT NULL,
  `location_code` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tax_rate_id` bigint(20) UNSIGNED NOT NULL,
  `location_type` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_comments`
--
ALTER TABLE `wp_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10)),
  ADD KEY `woo_idx_comment_type` (`comment_type`);

--
-- Indexes for table `wp_duplicator_packages`
--
ALTER TABLE `wp_duplicator_packages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hash` (`hash`);

--
-- Indexes for table `wp_links`
--
ALTER TABLE `wp_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Indexes for table `wp_options`
--
ALTER TABLE `wp_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`);

--
-- Indexes for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_posts`
--
ALTER TABLE `wp_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Indexes for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_terms`
--
ALTER TABLE `wp_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Indexes for table `wp_term_relationships`
--
ALTER TABLE `wp_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indexes for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Indexes for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_users`
--
ALTER TABLE `wp_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- Indexes for table `wp_wc_download_log`
--
ALTER TABLE `wp_wc_download_log`
  ADD PRIMARY KEY (`download_log_id`),
  ADD KEY `permission_id` (`permission_id`),
  ADD KEY `timestamp` (`timestamp`);

--
-- Indexes for table `wp_wc_webhooks`
--
ALTER TABLE `wp_wc_webhooks`
  ADD PRIMARY KEY (`webhook_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `wp_woocommerce_api_keys`
--
ALTER TABLE `wp_woocommerce_api_keys`
  ADD PRIMARY KEY (`key_id`),
  ADD KEY `consumer_key` (`consumer_key`),
  ADD KEY `consumer_secret` (`consumer_secret`);

--
-- Indexes for table `wp_woocommerce_attribute_taxonomies`
--
ALTER TABLE `wp_woocommerce_attribute_taxonomies`
  ADD PRIMARY KEY (`attribute_id`),
  ADD KEY `attribute_name` (`attribute_name`(20));

--
-- Indexes for table `wp_woocommerce_downloadable_product_permissions`
--
ALTER TABLE `wp_woocommerce_downloadable_product_permissions`
  ADD PRIMARY KEY (`permission_id`),
  ADD KEY `download_order_key_product` (`product_id`,`order_id`,`order_key`(16),`download_id`),
  ADD KEY `download_order_product` (`download_id`,`order_id`,`product_id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `wp_woocommerce_log`
--
ALTER TABLE `wp_woocommerce_log`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `level` (`level`);

--
-- Indexes for table `wp_woocommerce_order_itemmeta`
--
ALTER TABLE `wp_woocommerce_order_itemmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `order_item_id` (`order_item_id`),
  ADD KEY `meta_key` (`meta_key`(32));

--
-- Indexes for table `wp_woocommerce_order_items`
--
ALTER TABLE `wp_woocommerce_order_items`
  ADD PRIMARY KEY (`order_item_id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `wp_woocommerce_payment_tokenmeta`
--
ALTER TABLE `wp_woocommerce_payment_tokenmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `payment_token_id` (`payment_token_id`),
  ADD KEY `meta_key` (`meta_key`(32));

--
-- Indexes for table `wp_woocommerce_payment_tokens`
--
ALTER TABLE `wp_woocommerce_payment_tokens`
  ADD PRIMARY KEY (`token_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `wp_woocommerce_sessions`
--
ALTER TABLE `wp_woocommerce_sessions`
  ADD PRIMARY KEY (`session_key`),
  ADD UNIQUE KEY `session_id` (`session_id`);

--
-- Indexes for table `wp_woocommerce_shipping_zones`
--
ALTER TABLE `wp_woocommerce_shipping_zones`
  ADD PRIMARY KEY (`zone_id`);

--
-- Indexes for table `wp_woocommerce_shipping_zone_locations`
--
ALTER TABLE `wp_woocommerce_shipping_zone_locations`
  ADD PRIMARY KEY (`location_id`),
  ADD KEY `location_id` (`location_id`),
  ADD KEY `location_type_code` (`location_type`(10),`location_code`(20));

--
-- Indexes for table `wp_woocommerce_shipping_zone_methods`
--
ALTER TABLE `wp_woocommerce_shipping_zone_methods`
  ADD PRIMARY KEY (`instance_id`);

--
-- Indexes for table `wp_woocommerce_tax_rates`
--
ALTER TABLE `wp_woocommerce_tax_rates`
  ADD PRIMARY KEY (`tax_rate_id`),
  ADD KEY `tax_rate_country` (`tax_rate_country`),
  ADD KEY `tax_rate_state` (`tax_rate_state`(2)),
  ADD KEY `tax_rate_class` (`tax_rate_class`(10)),
  ADD KEY `tax_rate_priority` (`tax_rate_priority`);

--
-- Indexes for table `wp_woocommerce_tax_rate_locations`
--
ALTER TABLE `wp_woocommerce_tax_rate_locations`
  ADD PRIMARY KEY (`location_id`),
  ADD KEY `tax_rate_id` (`tax_rate_id`),
  ADD KEY `location_type_code` (`location_type`(10),`location_code`(20));

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_comments`
--
ALTER TABLE `wp_comments`
  MODIFY `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wp_duplicator_packages`
--
ALTER TABLE `wp_duplicator_packages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wp_links`
--
ALTER TABLE `wp_links`
  MODIFY `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_options`
--
ALTER TABLE `wp_options`
  MODIFY `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1372;

--
-- AUTO_INCREMENT for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2108;

--
-- AUTO_INCREMENT for table `wp_posts`
--
ALTER TABLE `wp_posts`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=255;

--
-- AUTO_INCREMENT for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `wp_terms`
--
ALTER TABLE `wp_terms`
  MODIFY `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  MODIFY `umeta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `wp_users`
--
ALTER TABLE `wp_users`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wp_wc_download_log`
--
ALTER TABLE `wp_wc_download_log`
  MODIFY `download_log_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_wc_webhooks`
--
ALTER TABLE `wp_wc_webhooks`
  MODIFY `webhook_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_api_keys`
--
ALTER TABLE `wp_woocommerce_api_keys`
  MODIFY `key_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_attribute_taxonomies`
--
ALTER TABLE `wp_woocommerce_attribute_taxonomies`
  MODIFY `attribute_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_downloadable_product_permissions`
--
ALTER TABLE `wp_woocommerce_downloadable_product_permissions`
  MODIFY `permission_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_log`
--
ALTER TABLE `wp_woocommerce_log`
  MODIFY `log_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_order_itemmeta`
--
ALTER TABLE `wp_woocommerce_order_itemmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_order_items`
--
ALTER TABLE `wp_woocommerce_order_items`
  MODIFY `order_item_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_payment_tokenmeta`
--
ALTER TABLE `wp_woocommerce_payment_tokenmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_payment_tokens`
--
ALTER TABLE `wp_woocommerce_payment_tokens`
  MODIFY `token_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_sessions`
--
ALTER TABLE `wp_woocommerce_sessions`
  MODIFY `session_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `wp_woocommerce_shipping_zones`
--
ALTER TABLE `wp_woocommerce_shipping_zones`
  MODIFY `zone_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wp_woocommerce_shipping_zone_locations`
--
ALTER TABLE `wp_woocommerce_shipping_zone_locations`
  MODIFY `location_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wp_woocommerce_shipping_zone_methods`
--
ALTER TABLE `wp_woocommerce_shipping_zone_methods`
  MODIFY `instance_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_tax_rates`
--
ALTER TABLE `wp_woocommerce_tax_rates`
  MODIFY `tax_rate_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_tax_rate_locations`
--
ALTER TABLE `wp_woocommerce_tax_rate_locations`
  MODIFY `location_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
